<?php session_start();


if (isset($_POST['login'])) {
	include('includes/connection.php');
	$email = $_POST['email'];
	$password = $_POST['password'];
	
	$login_q = mysqli_query($con, "SELECT * FROM `students` WHERE `email`='$email' AND `password`='$password'");
	$result = mysqli_num_rows($login_q);
	
	$verify_sql = "SELECT * FROM `students` WHERE `email`='$email'";
	$verify_sql_R = mysqli_query($con, $verify_sql);
		
	$student_status = mysqli_fetch_assoc($verify_sql_R);
	$activation_status = $student_status['activation_status'];
	$password_status = $student_status['password_status'];
	$email_found = mysqli_num_rows($verify_sql_R);

	if ($email_found == 0) {
		echo "<div class='alert alert-danger'>Attention! Invalid Email or Password.</div>";
		die();
	}else if ($activation_status == 0) {
		echo "<div class='alert alert-danger'>Attention! Your account is not active. Please wait till your activation.</div>";
		die();
	}else if($password_status == -1){
		$update_password_status = "UPDATE `students` SET `password` = '$password', `password_status` = '1' WHERE `email` ='$email'";
		$update_password_status_r = mysqli_query($con, $update_password_status);
		$_SESSION['email'] = $email;
		echo "<div class='alert alert-success'>Valid Email with you password set as you typed. Redirecting <img src='images/loader.gif' alt='loading'></div>";
		?>
		<script type="text/JavaScript">
            setTimeout("location.href = 'student/index.php?msg=logged_in_p';", 3000);
        </script>
        <?php
		//header("Refresh: 5; URL=student/index.php?msg=logged_in");
		//header('Location: student/index.php?msg=logged_in');
		die();
	}else if ($result >0) {
		$_SESSION['email'] = $email;
		echo "<div class='alert alert-success'>Valid Login Details. Redirecting <img src='images/loader.gif' alt='loading'></div>";
		?>
		<script type="text/JavaScript">
            setTimeout("location.href = 'student/index.php?msg=logged_in';", 3000);
        </script>
        <?php
		//header("Refresh: 5; URL=student/index.php?msg=logged_in");
		//header('Location: student/index.php?msg=logged_in');
    	die();
    }else{
		echo "<div class='alert alert-danger'>Invalid Email Or Password. Try Again</div>";
    }
	
		
}
?>