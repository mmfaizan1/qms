<?php session_start();
include('student/session-set.php');
include('includes/connection.php');

if (isset($_POST['send_pass'])) {
	$s_email = $_POST['email'];
	$s_phone = $_POST['phone'];
	$verify_q = mysqli_query($con, "SELECT * FROM `students` WHERE `email`='$s_email' AND `activation_status`=1");
	$record_found = mysqli_num_rows($verify_q);
	if ($record_found == 1) {
		$s_details = mysqli_fetch_assoc($verify_q);
		
		$phone_number = $s_details['phone'];
		if ($phone_number == $s_phone) {
			$string = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$password = substr( str_shuffle( $string ), 0, 8 );
			$update_password = mysqli_query($con, "UPDATE `students` SET `password`='$password' WHERE `email`='$s_email'");
			if ($update_password) {
				// the message
				$msg = "Hello Dear, \n Your New Password is : '$password'. \n You can also Change Your Password If You Want.\n Have A Good Day.";
				// use wordwrap() if lines are longer than 70 characters
				$msg = wordwrap($msg,70);

				// send email
				$password_mail = mail($s_email,"Account Password Recovery.", $msg);
				if($password_mail){
					?>
						<script>window.location='forgot-password.php?Msg=sent'</script>
					<?php
				}else{
					?>
						<script>window.location='forgot-password.php?Msg=failure'</script>
					<?php
				}

			}
		}else{
			?>
			<script>window.location='forgot-password.php?Msg=incorrect'</script>
			<?php
		}
	}else{
		?>
		<script>window.location='forgot-password.php?Msg=incorrect'</script>
		<?php
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Quiz Management System</title>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.min.css">
	<link rel="stylesheet" href="css/et-line-font.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/style.css">
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500' rel='stylesheet' type='text/css'>
</head>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

<!-- preloader section -->
<div class="preloader">
	<div class="sk-spinner sk-spinner-circle">
       <div class="sk-circle1 sk-circle"></div>
       <div class="sk-circle2 sk-circle"></div>
       <div class="sk-circle3 sk-circle"></div>
       <div class="sk-circle4 sk-circle"></div>
       <div class="sk-circle5 sk-circle"></div>
       <div class="sk-circle6 sk-circle"></div>
       <div class="sk-circle7 sk-circle"></div>
       <div class="sk-circle8 sk-circle"></div>
       <div class="sk-circle9 sk-circle"></div>
       <div class="sk-circle10 sk-circle"></div>
       <div class="sk-circle11 sk-circle"></div>
       <div class="sk-circle12 sk-circle"></div>
    </div>
</div>
<!-- navigation section -->
<section class="navbar navbar-fixed-top custom-navbar" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="#" class="navbar-brand">QMS</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="index.php#initiate" class="smoothScroll">GO BACK</a></li>
				<li><a href="register.php" class="smoothScroll">REGISTER A NEW ACCOUNT</a></li>
			</ul>
		</div>
	</div>
</section>
<!-- home section -->
<section id="home">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<?php 
					if (isset($_GET['Msg'])) {
						if ($_GET['Msg']=='incorrect') {
							echo "<h1 class='text-center text-primary alert alert-danger'>Attention! Provided Details doesnot Match to any Record. Provide Correct Details</h1>";
						}else if ($_GET['Msg']=='sent') {
							echo "<h1 class='text-center text-primary alert alert-success'>Success! Your New Password has been sent to You Mail. <a href='index.php#initiate'>Login Now</a></h1>";
						}else if ($_GET['Msg']=='failure') {
							echo "<h1 class='text-center text-primary alert alert-danger'>Attention! Unable to perform Required Operation</h1>";
						}
					}
				?>
				<h1>Quiz Management System</h1>
				
				<hr>
				<a href="#reset" class="smoothScroll btn btn-default">Reset Password</a>
			</div>
		</div>
	</div>		
</section>
<div id="reset">
	<div class="container">
		<div class="col-md-6 col-sm-12">
			<h2 class="heading bold">Fill in the Correct details to get New Password</h2>
			<br>
			<form method="post" class="wow fadeInUp" data-wow-delay="0.6s">
				<div class="row">
					<div class="form-group col-md-12 col-sm-12">
						<input type="email" class="form-control" placeholder="Your Email" name="email" required id="email">
					</div>
					<div class="form-group col-md-12 col-sm-12">
						<input type="text" class="form-control" name="phone" required id="phone" title="Enter Phone Example: 03001234567" pattern="[0][3][0-9]{9}" placeholder="(Example: 0300 1234567)">
					</div>
					<div class="form-group col-md-12 col-sm-12">
						<input type="submit" class="form-control" value="Send Password" name="send_pass" id="send_pass">
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- footer section -->
<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<p>Copyright © QMS | <a href="#" target="_parent">Unstoppables</a></p>
			</div>
		</div>
	</div>
</footer>


<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/isotope.js"></script>
<script src="js/imagesloaded.min.js"></script>
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/jquery.backstretch.min.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/custom.js"></script>
<script>
	//tooltip
	$(document).ready(function(){
	    $('[data-toggle="tooltip"]').tooltip();   
	});
</script>
</body>
</html>