<?php session_start();
include('student/session-set.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Quiz Management System</title>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.min.css">
	<link rel="stylesheet" href="css/et-line-font.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/style.css">
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500' rel='stylesheet' type='text/css'>
</head>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

<!-- preloader section -->
<div class="preloader">
	<div class="sk-spinner sk-spinner-circle">
       <div class="sk-circle1 sk-circle"></div>
       <div class="sk-circle2 sk-circle"></div>
       <div class="sk-circle3 sk-circle"></div>
       <div class="sk-circle4 sk-circle"></div>
       <div class="sk-circle5 sk-circle"></div>
       <div class="sk-circle6 sk-circle"></div>
       <div class="sk-circle7 sk-circle"></div>
       <div class="sk-circle8 sk-circle"></div>
       <div class="sk-circle9 sk-circle"></div>
       <div class="sk-circle10 sk-circle"></div>
       <div class="sk-circle11 sk-circle"></div>
       <div class="sk-circle12 sk-circle"></div>
    </div>
</div>
<!-- navigation section -->
<section class="navbar navbar-fixed-top custom-navbar" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="#" class="navbar-brand">QMS</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#home" class="smoothScroll">HOME</a></li>
				<li><a href="#features" class="smoothScroll">FEATURES</a></li>
				<li><a href="#about" class="smoothScroll">ABOUT</a></li>
				<li><a href="#initiate" class="smoothScroll">INITIATE QUIZ</a></li>
				<li><a href="register.php" class="smoothScroll">REGISTER</a></li>
			</ul>
		</div>
	</div>
</section>
<!-- home section -->
<section id="home">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<?php 
					if (isset($_GET['msg'])) {
						if ($_GET['msg']=='login_to_continue') {
							echo "<h1 class='text-center text-primary alert alert-danger'>Please Login to continue <a href='#initiate'>Login Here</a></h1>";
						}
					}
				?>
				<h1>Quiz Management System</h1>
				
				<hr>
				<a href="#initiate" class="smoothScroll btn btn-default">Initiate Quiz</a>
			</div>
		</div>
	</div>		
</section>

<!-- work section -->
<section id="features">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<div class="section-title">
					<strong>01</strong>
					<h1 class="heading bold">FEATURES</h1>
					<hr>
				</div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
				<i class="fa fa-file-o medium-icon"></i>
					<h3>ONLINE QUIZ</h3>
					<hr>
					<p>The quiz will be generated and conducted online to minimize efforts of teachers and for saving time</p>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.9s">
				<i class="fa fa-plus-square medium-icon"></i>
					<h3>ADD QUESTIONS</h3>
					<hr>
					<p>While preparing quiz Teacher can add new questions or Teacher can add questions from previously added questions.</p>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.9s">
				<i class="fa fa-tasks medium-icon"></i>
					<h3>EASY MANAGEMENT</h3>
					<hr>
					<p>All of the tasks will be managed easily including course allocation to teachers, managing students, quizzes etc.</p>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="1s">
				<i class="fa fa-laptop medium-icon"></i>
					<h3>INTUITIVE USER INTERFACE</h3>
					<hr>
					<p>The intuitive user interface allows teachers and students to easily interact with the system and it will require a minimum or no training to interact with the system.</p>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="1s">
				<i class="fa fa-check-circle-o  medium-icon"></i>
					<h3>ONLINE ASSESSMENT</h3>
					<hr>
					<p>Quiz will be checked online.</p>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="1s">
				<i class="fa fa-bar-chart medium-icon"></i>
					<h3>Result Declaration Online</h3>
					<hr>
					<p>Result will be declared online after quiz will be checked by the system.</p>
			</div>
		</div>
	</div>
</section>

<!-- about section -->
<section id="about">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 text-center">
				<div class="section-title">
					<strong>02</strong>
					<h1 class="heading bold">ABOUT</h1>
					<hr>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<img src="images/about-img.jpg" class="img-responsive" alt="about img">
			</div>
			<div class="col-md-6 col-sm-12">
				<h3 class="bold">What is QMS?</h3>
				<p>The Quiz management system consists of attending quizzes online and checking the quizzes online. In this system, the teacher will set up the quiz paper and quiz schedule. The candidate solve quiz online and when the result should have to be declared, this will be decided by the teacher. The teacher arranges the quiz schedule and result declaration. He also arranges the quiz question papers and their answer. The admin will allocate courses to teacher. The demo exam will also be provided. The sample question and answers will also be provided for the help of the candidate to understand the flow of system.</p>
			</div>
		</div>
	</div>
</section>
<!-- team section -->

<section id="team">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<div class="section-title">
					<strong>03</strong>
					<h1 class="heading bold">TALENTED TEAM</h1>
					<hr>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 wow fadeIn" data-wow-delay="0.9s">
				<div class="team-wrapper">
					<img src="images/asif.jpg" class="img-responsive" alt="team img">
						<div class="team-des">
							<h4>Asif Ameer</h4>
							<h3>Project Supervisor</h3>
							<hr>
							<ul class="social-icon">
								<li><a href="#" class="fa fa-facebook wow fadeIn" data-wow-delay="0.3s"></a></li>
								<li><a href="#" class="fa fa-twitter wow fadeIn" data-wow-delay="0.6s"></a></li>
								<li><a href="#" class="fa fa-dribbble wow fadeIn" data-wow-delay="0.9s"></a></li>
							</ul>
						</div>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 wow fadeIn" data-wow-delay="1.3s">
				<div class="team-wrapper">
					<img src="images/waqas.jpg" class="img-responsive" alt="team img">
						<div class="team-des">
							<h4>Waqas Ahmed Khan</h4>
							<h3>Documentation Management</h3>
							<hr>
							<ul class="social-icon">
								<li><a href="#" class="fa fa-facebook wow fadeIn" data-wow-delay="0.3s"></a></li>
								<li><a href="#" class="fa fa-twitter wow fadeIn" data-wow-delay="0.6s"></a></li>
								<li><a href="#" class="fa fa-dribbble wow fadeIn" data-wow-delay="0.9s"></a></li>
							</ul>
						</div>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 wow fadeIn" data-wow-delay="1.6s">
				<div class="team-wrapper">
					<img src="images/azhar.jpg" class="img-responsive" alt="team img">
						<div class="team-des">
							<h4>Azhar Tajammal</h4>
							<h3>Documentation Management</h3>
							<hr>
							<ul class="social-icon">
								<li><a href="#" class="fa fa-facebook wow fadeIn" data-wow-delay="0.3s"></a></li>
								<li><a href="#" class="fa fa-twitter wow fadeIn" data-wow-delay="0.6s"></a></li>
								<li><a href="#" class="fa fa-dribbble wow fadeIn" data-wow-delay="0.9s"></a></li>
							</ul>
						</div>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 wow fadeIn" data-wow-delay="1.6s">
				<div class="team-wrapper">
					<img src="images/faizan.jpg" class="img-responsive" alt="team img">
						<div class="team-des">
							<h4>Faizan Zafar</h4>
							<h3>Developer</h3>
							<hr>
							<ul class="social-icon">
								<li><a href="#" class="fa fa-facebook wow fadeIn" data-wow-delay="0.3s"></a></li>
								<li><a href="#" class="fa fa-twitter wow fadeIn" data-wow-delay="0.6s"></a></li>
								<li><a href="#" class="fa fa-dribbble wow fadeIn" data-wow-delay="0.9s"></a></li>
							</ul>
						</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- initiate section -->
<section id="initiate">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 text-center">
				<div class="section-title">
					<strong>04</strong>
					<h1 class="heading bold">Initiate Quiz</h1>
					<hr>
				</div>
			</div>
			<div class="col-md-6 col-sm-12 initiate-info">
				<h2 class="heading bold">REGISTER</h2>
				<p>Don't Have an Account?</p>
				<a class="btn btn-default" href="register.php">Register Here!</a>
			</div>
			<div class="col-md-6 col-sm-12">
				<h2 class="heading bold">STUDENT LOGIN <span href="#" data-toggle="tooltip" title="If you were added by the admin. Then on the first login your password will be updated with the password which you will enter this time"><i class="fa fa-question-circle fa-2x"></i></span></h2>
				<div class="col-md-12 col-sm-12">
					<h3 class="text-center" id="status_message"></h3>
				</div>
				<form action="" method="post" class="wow fadeInUp" data-wow-delay="0.6s">
					<div class="row">
						<div class="form-group col-md-12 col-sm-12">
							<input type="email" class="form-control" placeholder="Email" name="email" required id="email">
						</div>
					</div>
					<div class="row">						
						<div class="form-group col-md-12 col-sm-12">
							<input type="password" class="form-control" placeholder="Password" name="password" required id="password">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-12 col-sm-12">
							<input type="button" class="form-control" value="login" name="login" id="login">
						</div>
					</div>
					<div class="row">
						<div class="form-group col-md-12 col-sm-12">	<h3>Forgot password? Reset Password <a href="forgot-password.php">Here!</a></h3>					
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>

<!-- footer section -->
<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<p>Copyright © QMS | <a href="#" target="_parent">Unstoppables</a></p>
			</div>
		</div>
	</div>
</footer>
<form action="">
	<input type="submit" name="mail" value="send">
</form>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/isotope.js"></script>
<script src="js/imagesloaded.min.js"></script>
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/jquery.backstretch.min.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/custom.js"></script>
<script>
	//tooltip
	$(document).ready(function(){
	    $('[data-toggle="tooltip"]').tooltip();   
	});
</script>
</body>
</html>