<?php 
include('includes/top.php');
include('includes/connection.php');
if (isset($_POST['add']) && !empty($_POST)) {
  
  $student_name = $_POST['student_name'];
  $student_email = $_POST['student_email'];
  $student_department = $_POST['student_department'];
  $degree = $_POST['degree'];
  $semester = $_POST['semester'];
  $session_year = $_POST['session_year'];
  $degree_level = $_POST['degree_level'];
  $rollno = $_POST['rollno'];
  $student_rollno = $session_year.'-'.$degree_level.'-'.$rollno;
  $phone = $_POST['phone'];  
  
  //fetch class
  $fetch_class_q = mysqli_query($con, "SELECT * FROM `class` WHERE `degree`='$degree' AND `semester`='$semester'");
  $is_class_found = mysqli_num_rows($fetch_class_q);
  $student_class=mysqli_fetch_assoc($fetch_class_q);
  $student_class_id = $student_class['class_id'];
  //validate email
  $duplicate_email_q = mysqli_query($con, "SELECT * FROM `students` WHERE `email`='$student_email'");
    //validate rollno
  $duplicate_rollno_q = mysqli_query($con, "SELECT * FROM `students` WHERE `rollno`='$student_rollno'");

  if (empty($student_name) OR empty($student_email) OR empty($student_department) OR empty($degree) OR empty($semester) OR empty($session_year) OR empty($degree_level) OR empty($rollno) OR empty($phone)) {
    ?>
      <script>
        window.location = 'add-student.php?Msg=empty';
      </script>
    <?php
  }else if (mysqli_num_rows($duplicate_email_q) > 0) {
    ?>
      <script>
        window.location = 'add-student.php?Msg=mexists';
      </script>
    <?php
    die();
  }else if (mysqli_num_rows($duplicate_rollno_q) > 0) {
    ?>
      <script>
        window.location = 'add-student.php?Msg=rexists';
      </script>
    <?php
    die();
  }else{
    //if activation status is "-1" then student will set Password first time he/she logs in
    if($is_class_found > 0){  
      $insert_student_q = mysqli_query($con, "INSERT INTO `students` (`name`, `rollno`, `class`, `email`, `phone`, `password`,`activation_status`,`password_status`) VALUES ('$student_name','$student_rollno','$student_class_id','$student_email','$phone','','1','-1')");
      if ($insert_student_q) {
        ?>
        <script>
          window.location = 'add-student.php?Msg=added';
        </script>
        <?php
      }else{
        ?>
        <script>
          window.location = 'add-student.php?Msg=failure';
        </script>
        <?php
      }
    }else{
      ?>
        <script>
          window.location = 'add-student.php?Msg=class_not_found';
        </script>
      <?php
    }
  }
}
//populate departments
$departments_q = mysqli_query($con, "SELECT * FROM `departments`");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Students
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'empty') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Please Fill In all the required  Fields</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'mexists') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Email already Exists.</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'rexists') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Roll Number already Exists.</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'added') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Success! Student Added Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'class_not_found') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! The class in which You are trying to add student doesnot exists</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add a Student</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label>Name</label>
                  <input type="text" name="student_name" class="form-control" placeholder="Enter Name" required>
                </div>
                <div class="form-group">
                  <label>Email address</label>
                  <input type="email" name="student_email" class="form-control" placeholder="Enter email" title="Example: example@gmail.com" pattern="(?!_)[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,63}$" required>
                </div>
                <div class="form-group">
                    <label>Department</label>
                    <select class="form-control select2" name="student_department" id="student_department" style="width: 100%;" required>
                      <option value="">Select Department</option>
                      <?php while($departments = mysqli_fetch_assoc($departments_q)){ ?>  
                        <!-- <option selected>CS&IT</option> -->
                        <option value="<?php echo $departments['department_id'];?>" ><?php echo $departments['department_name']; ?></option>
                      <?php } ?>
                    </select>
                  <!-- /.form-group -->
                </div>
                <div class="form-group">
                    <label>Degree</label>
                    <select name="degree" class="form-control department_degree" id="department_degree" required>
                      <option>Select Department to proceed</option>
                    </select>
                  <!-- /.form-group -->
                </div>
                <div class="form-group">
                    <label>Semester</label>
                    <select name="semester" id="semester" class="form-control" required>
                      <option value="">Select Degree to Proceed</option>
                    </select>
                  <!-- /.form-group -->
                </div>
                <div class="form-group">
                  <label>RollNo</label>
                </div>
                <div class="form-group">
                  <div class="col-sm-2">
                    <label>Year</label>
                    <input type="text" id="session_year" name="session_year" class="form-control" placeholder="eg: 14" pattern="[0-9]{2,2}" title="Atleast two Digits" required>
                  </div>
                  <div class="col-sm-4">
                    <label>Degree Level</label>
                    <input type="text" id="degree_level" name="degree_level" class="form-control" placeholder="uglc or glc" readonly required>
                  </div>
                  <div class="col-sm-6">
                    <label>Rollno</label>
                    <input type="text" id="rollno" name="rollno" class="form-control" placeholder="eg: 502" pattern="[0-9]{3,}" title="Enter valid Rollno in Digits" required>
                  </div>
                </div>
                <div class="form-group">
                  <label>Phone</label>
                  <input type="text" name="phone" class="form-control" placeholder="Enter Phone Number (Example: 03001234567)" title="Example: 03001234567" pattern="[0][3][0-9]{9}" required>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" value="add" name="add" class="btn btn-primary">Add Student</button>
              </div>
            </form>
          </div>
          <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>