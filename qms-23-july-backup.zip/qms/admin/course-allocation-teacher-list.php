<?php 
include('includes/top.php');
include('includes/connection.php');
if (isset($_GET['action'])) {
  if ($_GET['action'] == 'deallocate') {
    $allocation_id = $_GET['allocation_id'];

    //Notification
    $fetch_details = mysqli_query($con, "SELECT * FROM `course_allocation` JOIN `courses` ON `course_allocation`.`allocated_course_id`=`courses`.`course_id` JOIN `teachers` ON `course_allocation`.`course_teacher_id`=`teachers`.`teacher_id` WHERE `course_allocation`.`course_allocation_id`='$allocation_id'");
    $teacher_details = mysqli_fetch_assoc($fetch_details);
    $teacher_id = $teacher_details['teacher_id'];
    $teacher_name = $teacher_details['name'];
    $course_code = $teacher_details['course_code'];
    $course_name = $teacher_details['course'];    

    //Deallocate q
    $deallocate_q = mysqli_query($con, "DELETE FROM `course_allocation` WHERE `course_allocation_id`='$allocation_id'");

    //Notify Query
    $notify_q = mysqli_query($con, "INSERT INTO `notifications` (`title`, `description`, `time`, `notification_by`,`notification_for`,`severity`,`id`) VALUES ('Course Deallocation','Welcome Dear $teacher_name. You have been Deallocated a course $course_code - $course_name.', now(), 'admin','teacher','3','$teacher_id')");

    if ($deallocate_q && $notify_q) {
      ?>
      <script>window.location='course-allocation-teacher-list.php?Msg=deallocated';</script>
      <?php
    }else{
      ?>
      <script>window.location='course-allocation-teacher-list.php?Msg=failure';</script>
      <?php
    }
  }
}
$departments_q = mysqli_query($con, "SELECT * FROM `departments`");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Courses
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'deallocated') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Course Deallocated Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">
      <div class="box">
            <div class="box-header">
              <h3 class="box-title">Teacher Courses</h3>
              <a href="allocate-course-to-teacher.php" class="btn btn-primary pull-right btn-lg">Allocate a new course</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form method="post">
                <div class="form-group">
                  <label>Select Department</label>
                  <select name="departments" id="teacher_department" class="form-control teacher_department">
                    <option value="">Select Department</option>
                    <?php
                    while($department = mysqli_fetch_assoc($departments_q)){
                      ?>
                      <option value="<?php echo $department['department_id'];?>"><?php echo $department['department_name'];?></option>
                      <?php
                    }
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Select Teacher</label>
                  <select name="teacher" id="department_teacher" class="form-control department_teacher">
                    <option value="">Select Department to Proceed</option>
                    
                  </select>
                </div>
              </form>
              <div id="result-data">
                <h3 class="text-danger text-center">Select department and teacher to proceed</h3>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>