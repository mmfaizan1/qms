<?php 
include('includes/top.php');
include('includes/connection.php');

$departments_q = mysqli_query($con, "SELECT * FROM `departments`");

if (isset($_POST['add']) && !empty($_POST)) {
  $department = $_POST['departments'];
  $code = $_POST['code'];
  $course_name = $_POST['course_name'];
  
  //validate course code and course name
  $validate_q = mysqli_query($con, "SELECT * FROM `courses` WHERE `course_code`='$code'");
  $is_course_exists = mysqli_num_rows($validate_q);

  if (empty($department) || empty($code) || empty($course_name)) {
    ?>
    <script>window.location='add-course.php?Msg=empty';</script>
    <?php
  }else if($is_course_exists > 0){
    $course_db = mysqli_fetch_assoc($validate_q);
    $db_course_code = $course_db['course_code'];
    if($db_course_code == $code){
      ?>
      <script>window.location='add-course.php?Msg=exists';</script>
      <?php
    }
  }else{
    $insert_course_q = mysqli_query($con, "INSERT INTO `courses` (`course`,`course_code`,`department`) VALUES ('$course_name','$code','$department')");
    if ($insert_course_q) {
      ?>
      <script>window.location='add-course.php?Msg=added';</script>
      <?php
    }else{
      ?>
      <script>window.location='add-course.php?Msg=failure';</script>
      <?php
    }
  }
}

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Courses
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'empty') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Please Fill In all the required  Fields</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'exists') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Course already Exists.</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'added') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Success! Course Added Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Unable to perform required operation</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>

    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add a Course</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label>Course Code</label>
                  <input type="text" name="code" class="form-control" placeholder="Enter Course Code" required>
                </div>
                <div class="form-group">
                  <label>Course Name</label>
                  <input type="text" name="course_name" class="form-control" placeholder="Enter Course Name" required>
                </div>
                <div class="form-group">
                  <label>Select Department</label>
                  <select name="departments" id="student_department" class="form-control course_department" required>
                    <option value="">Select Department</option>
                    <?php
                    while($department = mysqli_fetch_assoc($departments_q)){
                      ?>
                      <option value="<?php echo $department['department_id'];?>"><?php echo $department['department_name'];?></option>
                      <?php
                    }
                    ?>
                  </select>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" name="add" value="add" class="btn btn-primary">Add Degree</button>
              </div>
            </form>
          </div>
          <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include('includes/footer.php');?>