<?php 
include('includes/top.php');
include('includes/connection.php');

if (isset($_POST['allocate'])) {
  $department = $_POST['department'];
  $course = $_POST['course'];
  $teacher = $_POST['teacher'];

  //course name and code for notification
  $course_details = mysqli_query($con, "SELECT * FROM `courses` WHERE `course_id` = '$course'");
  $course_detail = mysqli_fetch_assoc($course_details);
  $course_name = $course_detail['course'];
  $course_code = $course_detail['course_code'];

  //validate data
  $validate_q = mysqli_query($con, "SELECT * FROM `course_allocation` WHERE `allocated_course_id`='$course' AND `course_teacher_id`='$teacher'");
  $is_course_already_allocated = mysqli_num_rows($validate_q);
  if (empty($department) || empty($course) || empty($teacher)) {
    ?>
    <script>window.location='allocate-course-to-teacher.php?Msg=empty';</script>
    <?php
  }else if($is_course_already_allocated > 0){
    ?>
    <script>window.location='allocate-course-to-teacher.php?Msg=exists';</script>
    <?php
  }else{
    $allocate_q = mysqli_query($con, "INSERT INTO `course_allocation` (`allocated_course_id`,`course_teacher_id`) VALUES ('$course','$teacher')");
    
    //Notify Query
    $notify_q = mysqli_query($con, "INSERT INTO `notifications` (`title`, `description`, `time`, `notification_by`,`notification_for`,`severity`,`id`) VALUES ('Course Allocation','Welcome Dear Teacher. You have been allocated with a new course $course_code - $course_name.', now(), 'admin','teacher','1','$teacher')");
    if ($allocate_q && $notify_q) {
      ?>
      <script>window.location='allocate-course-to-teacher.php?Msg=allocated';</script>
      <?php
    }else{
      ?>
      <script>window.location='allocate-course-to-teacher.php?Msg=failure';</script>
      <?php
    }
  }

}

$departments_q = mysqli_query($con, "SELECT * FROM `departments`");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Courses
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'empty') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Fill in all the required fields</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'exists') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! This course is already allocated to this teacher</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'allocated') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Success! Course Allocated Successfully</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>    
    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Allocate a Course to Teacher</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
              <div class="box-body">
                <form method="post">
                  <div class="form-group">
                    <label>Select Department</label>
                    <select class="form-control allocation-department" name="department" required>
                      <option value="">Select Department</option>  
                      <?php 
                      $i = 1;
                      while($department_details = mysqli_fetch_assoc($departments_q)){
                      ?>
                      <option value="<?php echo $department_details['department_id']?>"><?php echo $department_details['department_name']; ?></option>
                      <?php 
                      } 
                      ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Course</label>
                    <select name="course" id="department_course" class="form-control department_course" required>
                      <option value="">Select Department to Proceed</option>
                      
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Allocate To</label>
                    <select name="teacher" id="department_teacher" class="form-control department_teacher" required>
                      <option value="">Select Department to Proceed</option>
                      
                    </select>
                  </div>
                  <button type="submit" name="allocate" value="allocate" class="btn btn-primary">Allocate Course</button>
                </form>
              </div>
              <!-- /.box-body -->
          </div>
          <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php include('includes/footer.php');?>