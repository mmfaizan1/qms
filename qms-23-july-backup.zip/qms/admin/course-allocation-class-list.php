<?php 


include('includes/top.php');
include('includes/connection.php');
if (isset($_GET['action'])) {
  if ($_GET['action'] == 'deallocate') {
    $allocation_id = $_GET['allocation_id'];
    
    //Notification
    $fetch_details = mysqli_query($con, "SELECT * FROM `class_courses` JOIN `courses` ON `class_courses`.`course_id`=`courses`.`course_id` WHERE `class_courses`.`class_course_id`='$allocation_id'");
    $class_details = mysqli_fetch_assoc($fetch_details);
    $class_id = $class_details['course_class_id'];
    $course_code = $class_details['course_code'];
    $course_name = $class_details['course'];

    //Deallocate query
    $deallocate_q = mysqli_query($con, "DELETE FROM `class_courses` WHERE `class_course_id`='$allocation_id'");

    //Notify Query
    $notify_q = mysqli_query($con, "INSERT INTO `notifications` (`title`, `description`, `time`, `notification_by`,`notification_for`,`severity`,`id`) VALUES ('Course Deallocation','Welcome Dear Student. Your class have been Deallocated a course $course_code - $course_name.', now(), 'admin','class','3','$class_id')");

    if ($deallocate_q) {
      ?>
      <script>window.location='course-allocation-class-list.php?Msg=deallocated';</script>
      <?php
    }else{
      ?>
      <script>window.location='course-allocation-class-list.php?Msg=failure';</script>
      <?php
    }
  }
}

$departments_q = mysqli_query($con, "SELECT * FROM `departments`");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Courses
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'deallocated') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Course Deallocated Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">
      <div class="box">
            <div class="box-header">
              <h3 class="box-title">Courses Allocated To Classes</h3>
              <a href="allocate-course-to-class.php" class="btn btn-primary pull-right btn-lg">Allocate a new course</a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form method="post">
                <div class="form-group">
                  <label>Select Department</label>
                  <select name="departments" id="student_department" class="form-control allocation_department">
                    <option value="">Select Department</option>
                    <?php
                    while($department = mysqli_fetch_assoc($departments_q)){
                      ?>
                      <option value="<?php echo $department['department_id'];?>"><?php echo $department['department_name'];?></option>
                      <?php
                    }
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Select Degree</label>
                  <select name="degree" id="department_degree" class="form-control allocation_degree">
                    <option value="">Select Department to proceed</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Select Semester</label>
                  <select name="semester" id="semester" class="allocation_semester form-control">
                    <option value="">Select Department and degree to proceed</option>
                  </select>
                </div>
              </form>
              <div id="result-data">
                <h3 class="text-center text-danger">Select Department, Degree and Semester to Proceed</h3>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>