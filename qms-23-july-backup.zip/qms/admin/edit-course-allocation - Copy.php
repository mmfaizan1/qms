<?php 
include('includes/top.php');
include('includes/connection.php');
$course_id = $_GET['course_id'];
$degree_id = $_GET['degree_id'];
$department_id = $_GET['department_id'];
$semester = $_GET['semester'];

//Fetch class_id
$class_q = mysqli_query($con, "SELECT * FROM `class` WHERE `degree`='$degree_id' AND `semester`='$semester'");
$class_detail = mysqli_fetch_assoc($class_q); 
$class_id = $class_detail['class_id'];

//SELECT * FROM `class_courses` JOIN `courses` ON `class_courses`.`course_id`=`courses`.`course_id` JOIN `class` ON `class_courses`.`course_class_id`=`class`.`class_id` JOIN `degree` ON `class`.`degree`=`degree`.`degree_id` JOIN `departments` ON `degree`.`department_id`=`departments`.`department_id` WHERE `courses`.`department`=1 AND `class_courses`.`course_class_id`=1

$populate_fields_q = mysqli_query($con, "SELECT * FROM `class_courses` JOIN `courses` ON `class_courses`.`course_id`=`courses`.`course_id` JOIN `class` ON `class_courses`.`course_class_id`=`class`.`class_id` JOIN `degree` ON `class`.`degree`=`degree`.`degree_id` JOIN `departments` ON `degree`.`department_id`=`departments`.`department_id` WHERE `courses`.`department`='$department_id' AND `class_courses`.`course_class_id`='$class_id'");
$course_details = mysqli_fetch_assoc($populate_fields_q);
$departments_q = mysqli_query($con, "SELECT * FROM `departments`");


if (isset($_POST['update']) && !empty($_POST)) {
  $department = $_POST['departments'];
  $degree = $_POST['degree'];
  $semester = $_POST['semester'];
  $code = $_POST['code'];
  $course_name = $_POST['course_name'];
  if (empty($department) || empty($degree) || empty($semester) || empty($code) || empty($course_name)) {
    # code...
  }
}

?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Courses
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'empty') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Fill in all the required fields</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Edit a Course</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <form method="post">
            <div class="form-group">
              <label>Select Department</label>
              <select name="departments" id="student_department" class="form-control course_department" required>
                <option value="">Select Department</option>
                <?php
                while($department = mysqli_fetch_assoc($departments_q)){
                  ?>
                  <option value="<?php echo $department['department_id'];?>" <?php echo (($department['department_id']==$department_id)?'selected':''); ?>><?php echo $department['department_name'];?></option>
                  <?php
                }
                ?>
              </select>
            </div>
            <div class="form-group">
              <label>Select Degree</label>
              <select name="degree" id="department_degree" class="form-control course_degree" required>
                <option value="">Select Department to proceed</option>
                <option value="<?php echo $course_details['degree_id'];?>" selected><?php echo $course_details['degree_name'];  ?></option>
              </select>
            </div>
            <div class="form-group">
              <label>Select Semester</label>
              <select name="semester" id="semester" class="course_semester form-control" required>
                <option value="">Select Department and degree to proceed</option>
                <option value="<?php echo $semester;?>" selected><?php echo $semester; ?></option>
              </select>
            </div>
            <div class="form-group">
              <label>Course Code</label>
              <input type="text" name="code" class="form-control" value="<?php echo $course_details['course_code'];?>" required>
            </div>
            <div class="form-group">
              <label>Course Name</label>
              <input type="text" name="course_name" class="form-control" value="<?php echo $course_details['course'];?>" required>
            </div>
            <div class="form-group">
              <button type="submit" name="update" value="update" class="btn btn-success">Update</button>
            </div>
          </form>
        </div>
        <!-- /.box-body -->
          
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>