<?php 
include('includes/top.php');
include('includes/connection.php');
//Approve Teacher
if(isset($_GET['action'])){
  if ($_GET['action'] == 'approve') {
    $teacher_id = $_GET['teacher_id'];
    $teacher_details = mysqli_query($con, "SELECT * FROM `teachers` WHERE `teacher_id`='$teacher_id'");
    $teacher = mysqli_fetch_assoc($teacher_details);
    $teacher_name = $teacher['name'];
    $teacher_email = $teacher['email']; 
    $approve_teacher_q = mysqli_query($con, "UPDATE `teachers` SET activation_status=1 WHERE `teacher_id`='$teacher_id'");
    $notify_q = mysqli_query($con, "INSERT INTO `notifications` (`title`, `description`, `time`, `notification_by`,`notification_for`,`severity`,`id`) VALUES ('Account Activation','Welcome Dear $teacher_name. Your account with email $teacher_email is now active.', now(), 'admin','teacher','1','$teacher_id')");
    if($approve_teacher_q && $notify_q){
      ?>
      <script>
        window.location = 'teacher-requests.php?Msg=approved';
      </script>
      <?php
    }else{
      ?>
      <script>
        window.location = 'teacher-requests.php?Msg=failure';
      </script>
      <?php
    }
  }
}
//Delete Teacher
if(isset($_GET['action'])){
  if ($_GET['action'] == 'delete') {
    $teacher_id = $_GET['teacher_id'];
    $delete_teacher_q = mysqli_query($con, "DELETE FROM `teachers` WHERE `teacher_id`='$teacher_id'");
    if($delete_teacher_q){
      ?>
      <script>
        window.location = 'teacher-requests.php?Msg=deleted';
      </script>
      <?php
    }else{
      ?>
      <script>
        window.location = 'teacher-requests.php?Msg=failure';
      </script>
      <?php
    }
  }
}

//pagination code
$records_per_page = 10;
if (isset($_GET['page']) AND !empty($_GET['page'])) {
  $page_number = $_GET['page'];
}else{
  $page_number = 1;
}

$start_from = ($page_number - 1) * $records_per_page;

$pending_teachers = mysqli_query($con, "SELECT * FROM `teachers` JOIN `departments` ON `teachers`.`department`=`departments`.`department_id` WHERE `teachers`.`activation_status`=0 ORDER BY `departments`.`department_id` LIMIT $start_from, $records_per_page");
$total_requests = mysqli_num_rows($pending_teachers);
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Teachers
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'deleted') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Teacher Deleted Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'approved') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Teacher Approved Successfully</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">
      <div class="box">
            <div class="box-header">
              <h3 class="box-title">Pending Teachers</h3>
            </div>
            <!-- /.box-header -->
            <?php if ($total_requests > 0) { ?>
              <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>id</th>
                      <th>Teacher Name</th>
                      <th>Teacher Department</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Approve</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $i = 1;
                    while($teachers_info = mysqli_fetch_assoc($pending_teachers)){
                    ?>
                      <tr>
                        <td><?php echo $i;?></td>
                        <td><?php echo $teachers_info['name']; ?></td>
                        <td><?php echo $teachers_info['department_name']; ?></td>
                        <td><?php echo $teachers_info['email']; ?></td>
                        <td><?php echo $teachers_info['phone']; ?></td>
                        <td>
                          <a href="teacher-requests.php?action=approve&teacher_id=<?php echo $teachers_info['teacher_id'];?>" title="Approve"><i class="fa fa-check-square-o fa-2x text-success"></i></a>
                        </td>
                        <td>  
                          <a href="teacher-requests.php?action=delete&teacher_id=<?php echo $teachers_info['teacher_id'];?>" title="Delete"><i class="fa fa-trash-o fa-2x text-danger"></i></a>
                        </td>
                      </tr>
                    <?php
                      $i++;
                    }
                    ?>
                  </tbody>
                  <tfoot>
                    <tr>
                      <th>id</th>
                      <th>Teacher Name</th>
                      <th>Teacher Department</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Approve</th>
                      <th>Delete</th>
                    </tr>
                  </tfoot>
                </table>
                <?php
                //pagination links
                $pagination_links_q =mysqli_query($con, "SELECT COUNT(*) AS total FROM `teachers` JOIN `departments` ON `teachers`.`department`=`departments`.`department_id` WHERE `teachers`.`activation_status`=0");
                $total = mysqli_fetch_assoc($pagination_links_q); 
                $total = $total['total'];
                $pages = ceil($total / $records_per_page);
                ?>
                <h4>Showing <?php echo $total_requests; ?> Records on this page</h4>
                <ul class="pagination">
                  <?php
                    for($i=1; $i<=$pages; $i++){
                      ?>
                      <!-- Highlighting active links -->
                      <li class="<?php echo (isset($_GET["page"])) && $_GET['page']== $i ? 'active':''; ?>">
                        <a href="teacher-requests.php?page=<?php echo $i;?>">
                          <?php echo $i; ?>
                        </a>
                      </li>
                      <?php
                    }
                  ?>
                </ul>
              </div>
              <!-- /.box-body -->
            <?php
            }else{
              echo "<div class='row'><h3 class='text-danger text-center'>No Pending Request</h3></rows>";
            }
            ?>
          </div>
          <!-- /.box -->  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>