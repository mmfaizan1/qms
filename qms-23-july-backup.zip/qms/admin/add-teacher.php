<?php 
include('includes/top.php');
include('includes/connection.php');

if (isset($_POST['add'])) {
  $teacher_name = $_POST['teacher_name'];
  $teacher_email = $_POST['teacher_email'];
  $teacher_department = $_POST['teacher_department'];
  $teacher_phone = $_POST['teacher_phone'];

  //validate email
  $duplicate_email_q = mysqli_query($con, "SELECT * FROM `teachers` WHERE `email`='$teacher_email'");
  if (mysqli_num_rows($duplicate_email_q) > 0) {
    ?>
      <script>
        window.location = 'add-teacher.php?Msg=exists';
      </script>
    <?php
    die();
  }else if(empty($teacher_name) || empty($teacher_email) || empty($teacher_department) || empty($teacher_phone)){
    ?>
      <script>
        window.location = 'add-teacher.php?Msg=empty';
      </script>
    <?php
    die();
  }else {
    //if activation status is "-1" then teacher will set Password first time he/she logs in
    $insert_teacher_q = mysqli_query($con, "INSERT INTO `teachers` (`name`,`email`,`department`,`phone`, `password`, `activation_status`,`password_status`) VALUES ('$teacher_name', '$teacher_email', '$teacher_department','$teacher_phone', '', '1','-1')");
    if ($insert_teacher_q) {
      ?>
      <script>
        window.location = 'add-teacher.php?Msg=added';
      </script>
      <?php
    }else{
      ?>
      <script>
        window.location = 'add-teacher.php?Msg=failure';
      </script>
      <?php
    }
  }
}

//populate departments
$departments_q = mysqli_query($con, "SELECT * FROM `departments`");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Teachers
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'empty') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Please Fill In all the required  Fields</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'exists') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Email already Taken.</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'added') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Success! Teacher Added Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Unable to perform required operation</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add a Teacher</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label>Name</label>
                  <input type="text" name="teacher_name" class="form-control" placeholder="Enter Name" required>
                </div>
                <div class="form-group">
                  <label>Email address</label>
                  <input type="text" name="teacher_email" class="form-control" title="Example: example@gmail.com" pattern="(?!_)[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,63}$" placeholder="Enter email" title="" required>
                </div>
                <div class="form-group">
                    <label>Department</label>
                    <select class="form-control select2" name="teacher_department" style="width: 100%;" required>
                      <option value="">Select Department</option>
                      <?php while($departments = mysqli_fetch_assoc($departments_q)){ ?>  
                        <!-- <option selected>CS&IT</option> -->
                        <option value="<?php echo $departments['department_id'];?>" ><?php echo $departments['department_name']; ?></option>
                      <?php } ?>
                    </select>
                  <!-- /.form-group -->
                </div>
                <div class="form-group">
                  <label>Phone</label>
                  <input type="text" class="form-control" title="Enter Phone Example: 03001234567" pattern="[0][3][0-9]{9}" placeholder="(Example: 0300 1234567)" name="teacher_phone" required>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" value="add" name="add" class="btn btn-primary">Add Teacher</button>
              </div>
            </form>
          </div>
          <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>