<?php 
include('includes/top.php');
include('includes/connection.php');
if(isset($_GET['action'])){
  if ($_GET['action'] == 'delete') {
    $student_id = $_GET['student_id'];
    $delete_student_q = mysqli_query($con, "DELETE FROM `students` WHERE `student_id`='$student_id'");
    if($delete_student_q){
      ?>
      <script>
        window.location = 'students.php?Msg=deleted';
      </script>
      <?php
    }else{
      ?>
      <script>
        window.location = 'students.php?Msg=failure';
      </script>
      <?php
    }
  }
}


$departments_q = mysqli_query($con, "SELECT * FROM `departments`");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Students
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'deleted') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Student Deleted Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'updated') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Student Updated Successfully</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">
      <div class="box">
            <div class="box-header">
              <h3 class="box-title">Students List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form method="post">
                <div class="form-group">
                  <label>Select Department</label>
                  <select class="form-control department">
                    <option value="">Select Department</option>  
                    <?php 
                    $i = 1;
                    while($department_details = mysqli_fetch_assoc($departments_q)){
                    ?>
                    <option value="<?php echo $department_details['department_id']?>"><?php echo $department_details['department_name']; ?></option>
                    <?php 
                    } 
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Select Degree</label>
                  <select id="student_degree" class="form-control">
                    <option value="">Select Degree</option>  
                    
                  </select>
                </div>
                <div class="form-group">
                  <label>Select Semester</label>
                  <select id="semester" class="form-control semester">
                    <option value="">Select Semester</option>  
                    
                  </select>
                </div>
              </form>
              <div id="result-data">
                <h3 class="text-danger text-center">
                  Select department to view Students list
                </h3>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>