<?php 
include('includes/top.php');
include('includes/connection.php');


//Approve student
if(isset($_GET['action'])){
  if ($_GET['action'] == 'approve') {
    $student_id = $_GET['student_id'];
    
    $student_details = mysqli_query($con, "SELECT * FROM `students` WHERE `student_id`='$student_id'");
    $student = mysqli_fetch_assoc($student_details);
    $student_name = $student['name'];
    $student_email = $student['email'];
    $student_rollno = $student['rollno'];
    $approve_student_q = mysqli_query($con, "UPDATE `students` SET activation_status=1 WHERE `student_id`='$student_id'");
    $notify_q = mysqli_query($con, "INSERT INTO `notifications` (`title`, `description`, `time`, `notification_by`,`notification_for`,`severity`,`id`) VALUES ('Account Activation','Welcome Dear $student_name. Your account with rollno $student_rollno and email $student_email is now active.', now(), 'admin','student','1','$student_id')");
    if($approve_student_q && $notify_q){
      ?>
      <script>
        window.location = 'student-requests.php?Msg=approved';
      </script>
      <?php
    }else{
      ?>
      <script>
        window.location = 'student-requests.php?Msg=failure';
      </script>
      <?php
    }
  }
}
//Delete Student
if(isset($_GET['action'])){
  if ($_GET['action'] == 'delete') {
    $student_id = $_GET['student_id'];
    $delete_student_q = mysqli_query($con, "DELETE FROM `students` WHERE `student_id`='$student_id'");
    if($delete_student_q){
      ?>
      <script>
        window.location = 'student-requests.php?Msg=deleted';
      </script>
      <?php
    }else{
      ?>
      <script>
        window.location = 'student-requests.php?Msg=failure';
      </script>
      <?php
    }
  }
}

//pagination code
$records_per_page = 10;
if (isset($_GET['page']) AND !empty($_GET['page'])) {
  $page_number = $_GET['page'];
}else{
  $page_number = 1;
}

$start_from = ($page_number - 1) * $records_per_page;

$pending_students = mysqli_query($con, "SELECT * FROM `students` JOIN `class` ON `students`.`class`=`class`.`class_id` JOIN `degree` ON `class`.`degree`=`degree`.`degree_id` JOIN `departments` ON `degree`.`department_id`=`departments`.`department_id` WHERE `students`.`activation_status`=0 ORDER BY `departments`.`department_id` ASC LIMIT $start_from, $records_per_page");
$total_requests = mysqli_num_rows($pending_students);
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Students
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'deleted') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Student Deleted Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'approved') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Student Approved Successfully</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Pending Students</h3>
            </div>
            <!-- /.box-header -->
            <?php if ($total_requests>0){ ?>
              <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>id</th>
                      <th>Student Name</th>
                      <th>RollNo</th>
                      <th>Degree</th>
                      <th>Semester</th>
                      <th>Department</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Approve</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $i=1;
                    while($student_info = mysqli_fetch_assoc($pending_students)){ ?>  
                      <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $student_info['name']; ?></td>
                        <td><?php echo $student_info['rollno']; ?></td>
                        <td><?php echo $student_info['degree_name']; ?></td>
                        <td><?php echo $student_info['semester']; ?></td>
                        <td><?php echo $student_info['department_name']; ?></td>
                        <td><?php echo $student_info['email']; ?></td>
                        <td><?php echo $student_info['phone']; ?></td>
                        <td>
                          <a href="student-requests.php?action=approve&student_id=<?php echo $student_info['student_id'];?>" title="Approve"><i class="fa fa-check-square-o fa-2x text-success"></i></a>
                        </td>
                        <td>  
                          <a href="student-requests.php?action=delete&student_id=<?php echo $student_info['student_id'];?>" title="Delete"><i class="fa fa-trash-o fa-2x text-danger"></i></a>
                        </td>
                      </tr>
                    <?php
                    }
                    ?>
                  </tbody>
                  <tfoot>
                    <tr>
                      <th>id</th>
                      <th>Student Name</th>
                      <th>RollNo</th>
                      <th>Degree</th>
                      <th>Semester</th>
                      <th>Department</th>
                      <th>Email</th>
                      <th>Phone</th>
                      <th>Approve</th>
                      <th>Delete</th>
                    </tr>
                  </tfoot>
                </table>
                <?php
                //pagination links
                $pagination_links_q =mysqli_query($con, "SELECT COUNT(*) AS total FROM `students` JOIN `class` ON `students`.`class`=`class`.`class_id` JOIN `degree` ON `class`.`degree`=`degree`.`degree_id` JOIN `departments` ON `degree`.`department_id`=`departments`.`department_id` WHERE `students`.`activation_status`=0");
                $total = mysqli_fetch_assoc($pagination_links_q); 
                $total = $total['total'];
                $pages = ceil($total / $records_per_page);
                ?>
                <h4>Showing <?php echo $total_requests; ?> Records on this page</h4>
                <ul class="pagination">
                  <?php
                    for($i=1; $i<=$pages; $i++){
                      ?>
                      <!-- Highlighting active links -->
                      <li class="<?php echo (isset($_GET["page"])) && $_GET['page']== $i ? 'active':''; ?>">
                        <a href="student-requests.php?page=<?php echo $i;?>">
                          <?php echo $i; ?>
                        </a>
                      </li>
                      <?php
                    }
                  ?>
                </ul>
              </div>
              <!-- /.box-body -->
            <?php 
            }else{
              echo "<div class='row'><h3 class='text-danger text-center'>No Pending Requests</h3></rows>";
            }

            ?>
          </div>
          <!-- /.box -->  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>