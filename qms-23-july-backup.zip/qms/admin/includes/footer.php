  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Made with <i class="fa fa-heart text-red"></i> by <a href="#">Unstoppables</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2018 <a href="#">QMS</a>.</strong> All rights reserved.
  </footer>
  <!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

<!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. -->
<!-- Custom JS -->
<script src="dist/js/custom.js"></script>

<!-- JS PDF Libraries -->

</body>
</html>