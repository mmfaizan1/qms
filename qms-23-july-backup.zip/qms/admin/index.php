<?php
include('includes/top.php');
include('includes/connection.php');

$teachers_requests_q = mysqli_query($con, "SELECT * FROM `teachers` WHERE `activation_status`=0");
$teachers_requests = mysqli_num_rows($teachers_requests_q);

$student_requests_q = mysqli_query($con, "SELECT * FROM `students` WHERE `activation_status`=0");
$student_requests = mysqli_num_rows($student_requests_q);
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'logged_in') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Welcome Admin. You are logged in successfully</h3>
                </div>
                <?php
              }else if($_GET['Msg'] == 'already_logged_in'){
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! You are already logged in. You cannot go back.</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-users"></i></span>

            <div class="info-box-content">
              <a href="teacher-requests.php">  
                <span class="info-box-text">Teachers Pending <br> Approval</span>
                <span class="info-box-number"><?php echo $teachers_requests; ?></span>
              </a>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-users"></i></span>

            <div class="info-box-content">
              <a href="student-requests.php">  
                <span class="info-box-text">Students Pending <br> Approval</span>
                <span class="info-box-number"><?php echo $student_requests; ?></span>
              </a>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>