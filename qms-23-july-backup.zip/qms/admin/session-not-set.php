<?php



if (!isset($_SESSION['email'])) {
	?><script>window.location='login.php?Msg=login_to_continue'</script><?php
}
?>