<?php 
include('includes/top.php');

include('includes/connection.php');

$class_id = $_GET['class_id'];
$student_id = $_GET['student_id'];

$populate_fields_q = mysqli_query($con, "SELECT * FROM `students` JOIN `class` ON `students`.`class` = `class`.`class_id` JOIN `degree` ON `class`.`degree`=`degree`.`degree_id` JOIN `departments` ON `degree`.`department_id`=`departments`.`department_id` WHERE `students`.`student_id`='$student_id'");

$student_data = mysqli_fetch_assoc($populate_fields_q);

$student_name = $student_data['name'];
$student_email = $student_data['email'];
$student_department_id = $student_data['department_id'];
$student_department_name = $student_data['department_name'];
$student_degree_id = $student_data['degree_id'];
$student_degree_name = $student_data['degree_name'];
$student_semester = $student_data['semester'];
$student_phone = $student_data['phone'];
$rollno = $student_data['rollno'];

$rollno = explode("-", $rollno);
$year = $rollno[0];
$prefix = $rollno[1];
$number = $rollno[2];


if (isset($_POST['update']) && !empty($_POST)) {
  
  echo $s_name = $_POST['student_name'];
  echo $s_email = $_POST['student_email'];
  echo $s_department = $_POST['student_department'];
  echo $s_degree = $_POST['degree'];
  echo $s_semester = $_POST['semester'];
  echo $session_year = $_POST['session_year'];
  echo $degree_level = $_POST['degree_level'];
  echo $s_rollno = $_POST['rollno'];
  echo $student_rollno = $session_year.'-'.$degree_level.'-'.$s_rollno;
  echo $s_phone = $_POST['phone'];
  //fetch class
  $fetch_class_q = mysqli_query($con, "SELECT * FROM `class` WHERE `degree`='$s_degree' AND `semester`='$s_semester'");
  $is_class_found = mysqli_num_rows($fetch_class_q);
  $student_class=mysqli_fetch_assoc($fetch_class_q);
  echo $student_class_id = $student_class['class_id'];
  if (empty($s_name) OR empty($s_email) OR empty($s_department) OR empty($s_degree) OR empty($s_semester) OR empty($session_year) OR empty($degree_level) OR empty($student_rollno) OR empty($s_phone)) {
    ?>
      <script>
        window.location = 'edit-student.php?action=edit&student_id=<?php echo $student_id;?>&class_id=<?php echo $class_id;?>&Msg=empty';
      </script>
    <?php
  }else{
    if($is_class_found > 0){  
      $insert_student_q = mysqli_query($con, "UPDATE `students` SET `name` = '$s_name', `rollno` = '$student_rollno', `email` = 's_email', `phone` = '$s_phone' WHERE `student_id` = '$student_id'");
      if ($insert_student_q) {
        ?>
        <script>
          window.location = 'students.php?Msg=updated';
        </script>
        <?php
      }else{
        ?>
        <script>
          window.location = 'students.php?Msg=failure';
        </script>
        <?php
      }
    }else{
      ?>
        <script>
          window.location = 'edit-student.php?action=edit&student_id=<?php echo $student_id;?>&class_id=<?php echo $class_id;?>&Msg=class_not_found';
        </script>
      <?php
    }
  }
}


//populate departments
$departments_q = mysqli_query($con, "SELECT * FROM `departments`");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Students
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'empty') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Please Fill In all the required  Fields</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'class_not_found') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! The class in which You are trying to add student doesnot exists</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>

    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Student</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">
                <input type="hidden" class="degree_id" value="<?php echo $student_degree_id;?>">
                <div class="form-group">
                  <label>Name</label>
                  <input type="text" name="student_name" class="form-control" placeholder="Enter Name" value="<?php echo $student_name;?>" required>
                </div>
                <div class="form-group">
                  <label>Email address</label>
                  <input type="email" name="student_email" class="form-control" placeholder="Enter email" value="<?php echo $student_email;?>" required>
                </div>
                <div class="form-group">
                    <label>Department</label>
                    <select class="form-control select2 department" name="student_department" id="student_department" style="width: 100%;" required>
                      <option value="">Select Department</option>
                      <?php while($departments = mysqli_fetch_assoc($departments_q)){ ?>  
                        <!-- <option selected>CS&IT</option> -->
                        <option value="<?php echo $departments['department_id'];?>" <?php if($student_department_id == $departments['department_id']){ echo 'selected';}else{echo '';}?> ><?php echo $departments['department_name']; ?></option>
                      <?php } ?>
                    </select>
                  <!-- /.form-group -->
                </div>
                <div class="form-group">
                    <label>Degree</label>
                    <select name="degree" class="form-control department_degree" id="department_degree" required>
                      <option>Select Department to proceed</option>
                      <option value="<?php echo $student_degree_id;?>" selected><?php echo $student_degree_name; ?></option>
                    </select>
                  <!-- /.form-group -->
                </div>
                <div class="form-group">
                    <label>Semester</label>
                    <select name="semester" id="semester" class="form-control" required>
                      <option value="">Select Degree to Proceed</option>
                      <option value="<?php echo $student_semester;?>" selected><?php echo $student_semester; ?></option>
                    </select>
                  <!-- /.form-group -->
                </div>
                <div class="form-group">
                  <label>RollNo</label>
                </div>
                <div class="form-group">
                  <div class="col-sm-2">
                    <label>Year</label>
                    <input type="text" id="session_year" name="session_year" class="form-control" placeholder="eg: 14" pattern="[0-9]{2,2}" title="Atleast two Digits" value="<?php echo $year;?>" required>
                  </div>
                  <div class="col-sm-4">
                    <label>Degree Level</label>
                    <input type="text" id="degree_level" name="degree_level" class="form-control" placeholder="uglc or glc" value="<?php echo $prefix;?>" readonly required>
                  </div>
                  <div class="col-sm-6">
                    <label>Rollno</label>
                    <input type="text" id="rollno" name="rollno" class="form-control" placeholder="eg: 502" pattern="[0-9]{3,}" title="Enter valid Rollno in Digits" required value="<?php echo $number;?>">
                  </div>
                </div>
                <div class="form-group">
                  <label>Phone</label>
                  <input type="text" name="phone" class="form-control" placeholder="Enter Phone Number (Example: 03001234567)" pattern="[0-9]{11}" title="Example: 03001234567" required value="<?php echo $student_phone;?>">
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" value="update" name="update" class="btn btn-primary">Update Student</button>
              </div>
            </form>
          </div>
          <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>