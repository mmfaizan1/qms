<?php



if (isset($_SESSION['email'])) {
	?><script>window.location='index.php?Msg=already_logged_in'</script><?php
}
?>