<?php 
include('includes/top.php');
include('includes/connection.php');

if (isset($_GET['action'])) {
  if ($_GET['action'] == 'delete') {
    $course_id = $_GET['course_id'];
    $delete_q = mysqli_query($con, "DELETE FROM `courses` WHERE `course_id`='$course_id'");
    if($delete_q){
      ?>
      <script>window.location='courses.php?Msg=deleted'</script>
      <?php
    }else{
      ?>
      <script>window.location='courses.php?Msg=failure'</script>
      <?php
    }
  }
}
$departments_q = mysqli_query($con, "SELECT * FROM `departments`");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Courses
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'deleted') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Course Deleted Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'updated') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Course Updated Successfully</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">
      <div class="box">
            <div class="box-header">
              <h3 class="box-title">Courses List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form method="post">
                <div class="form-group">
                  <label>Select Department</label>
                  <select name="departments" id="student_department" class="form-control course_department">
                    <option value="">Select Department</option>
                    <?php
                    while($department = mysqli_fetch_assoc($departments_q)){
                      ?>
                      <option value="<?php echo $department['department_id'];?>"><?php echo $department['department_name'];?></option>
                      <?php
                    }
                    ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Select Degree</label>
                  <select name="degree" id="department_degree" class="form-control course_degree">
                    <option value="">Select Department to proceed</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Select Semester</label>
                  <select name="semester" id="semester" class="course_semester form-control">
                    <option value="">Select Department and degree to proceed</option>
                  </select>
                </div>
              </form>
              <div id="result-data">
                <h3 class="text-danger text-center">Select department, degree and semester to proceed</h3>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>