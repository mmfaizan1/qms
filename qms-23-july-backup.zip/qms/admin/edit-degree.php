<?php include('includes/top.php');

include('includes/connection.php');

$dept_id = $_GET['department_id'];
$degree_id = $_GET['degree_id'];

if (isset($_POST['update'])) {
  $department_id = $_POST['department'];
  $degree_name = $_POST['degree'];
  if (empty($department_id) || empty($degree_name)) {
     ?>
      <script>
        window.location = 'edit-degree.php?department_id=<?php echo $dept_id;?>&degree_id=<?php echo $degree_id;?>&Msg=empty';
      </script>
     <?php
  }else{
    $update_degree_q = mysqli_query($con, "UPDATE `degree` SET `department_id`='$department_id', `degree_name`='$degree_name' WHERE `degree_id`='$degree_id'");
    if ($update_degree_q) {
      ?>
      <script>
        window.location = 'degrees.php?Msg=updated';
      </script>
      <?php
    }
  } 
}


//populate degree Q
$department_data_q = mysqli_query($con, "SELECT * FROM `departments`");

$degree_name_q = mysqli_query($con, "SELECT * FROM `degree` WHERE `degree_id`='$degree_id'");
$degree_name = mysqli_fetch_assoc($degree_name_q); 
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Degrees
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'empty') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Please Fill In all the Required Fields</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Degree Details</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">
                <div class="form-group">
                    <label>Department</label>
                    <select class="form-control select2" style="width: 100%;" name="department" required>
                      <option value="">Select Department</option>
                      <?php
                      while ($departments = mysqli_fetch_assoc($department_data_q)) {
                        ?>
                        <option value="<?php echo $departments['department_id'];?>" <?php
                            if($departments['department_id'] == $dept_id){
                              echo "selected";
                            }else{
                              echo "";
                            }
                            ?>
                        >
                            <?php echo $departments['department_name']; ?>  
                          </option>
                        <?php
                      }
                      ?>
                    </select>
                </div>
                <div class="form-group">
                  <label>Degree Name</label>
                  <input type="text" name="degree" class="form-control" placeholder="Enter Degree Name" value="<?php echo $degree_name['degree_name']; ?>" required>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" value="update" name="update" class="btn btn-primary">Update Degree Details</button>
                <a href="degrees.php" type="submit" class="btn btn-default">Cancel</a>
              </div>
            </form>
          </div>
          <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>