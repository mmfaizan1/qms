<?php 
include('includes/top.php');
include('includes/connection.php');


if(isset($_GET['action'])){
  if ($_GET['action'] == 'delete') {
    $degree_id = $_GET['degree_id'];
    $delete_degree_q = mysqli_query($con, "DELETE FROM `degree` WHERE `degree_id`='$degree_id'");
    if($delete_degree_q){
      ?>
      <script>
        window.location = 'degrees.php?Msg=deleted';
      </script>
      <?php
    }else{
      ?>
      <script>
        window.location = 'degrees.php?Msg=failure';
      </script>
      <?php
    }
  }
}
//pagination code
$records_per_page = 5;
if (isset($_GET['page']) AND !empty($_GET['page'])) {
  $page_number = $_GET['page'];
}else{
  $page_number = 1;
}

$start_from = ($page_number - 1) * $records_per_page;
$degrees_q = mysqli_query($con, "SELECT * FROM `degree` JOIN `departments` ON `degree`.`department_id`=`departments`.`department_id` ORDER BY `departments`.`department_id`,`degree`.`degree_id` ASC LIMIT $start_from, $records_per_page");
$total_degrees = mysqli_num_rows($degrees_q);
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Degrees
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'deleted') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Degree Deleted Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'updated') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Degree Updated Successfully</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">
      <div class="box">
            <div class="box-header">
              <h3 class="box-title">Degrees List</h3>
            </div>
            <!-- /.box-header -->
            <?php if($total_degrees > 0){ ?>
              <div class="box-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>id</th>
                      <th>Department Name</th>
                      <th>Degree</th>
                      <th>Edit</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $i = 1;
                    while($degree_details = mysqli_fetch_assoc($degrees_q)){ ?>
                      <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $degree_details['department_name']; ?></td>
                        <td><?php echo $degree_details['degree_name']; ?></td>
                        <td>
                          <a href="edit-degree.php?department_id=<?php echo $degree_details['department_id'];?>&degree_id=<?php echo $degree_details['degree_id'];?>" title="Edit"><i class="text-warning fa fa-pencil-square-o fa-lg fa-2x"></i></a>
                        </td>
                        <td>  
                          <a href="degrees.php?action=delete&degree_id=<?php echo $degree_details['degree_id'];?>" title="Delete"><i class="text-danger fa fa-trash-o fa-lg fa-2x"></i></a>
                        </td>
                      </tr>
                    <?php $i++; }?>
                  </tbody>
                  <tfoot>
                    <tr>
                      <th>id</th>
                      <th>Department Name</th>
                      <th>Degree</th>
                      <th>Edit</th>
                      <th>Delete</th>
                    </tr>
                  </tfoot>
                </table>
              <?php
              //pagination links
              $pagination_links_q =mysqli_query($con, "SELECT COUNT(*) AS total FROM `degree`");
              $total = mysqli_fetch_assoc($pagination_links_q); 
              $total = $total['total'];
              $pages = ceil($total / $records_per_page);
              ?>
              <h4>Showing <?php echo $total_degrees; ?> Records on this page</h4>
              <ul class="pagination">
                <?php
                  for($i=1; $i<=$pages; $i++){
                    ?>
                    <!-- Highlighting active links -->
                    <li class="<?php echo (isset($_GET["page"])) && $_GET['page']== $i ? 'active':''; ?>">
                      <a href="degrees.php?page=<?php echo $i;?>">
                        <?php echo $i; ?>
                      </a>
                    </li>
                    <?php
                  }
                ?>
              </ul>
                </div>
              <?php
              }else{
                echo "<div class='row'><h3 class='text-danger text-center'>Nothing to display</h3></rows>";
              }
              ?>
                <!-- /.box-body -->
            </div>
          <!-- /.box -->  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>