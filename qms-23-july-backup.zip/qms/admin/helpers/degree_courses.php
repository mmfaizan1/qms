<?php
include('../includes/connection.php');



$department_id = $_POST['department_id'];

$course_q = mysqli_query($con, "SELECT * FROM `courses` WHERE `courses`.`department`='$department_id'");
$total_courses = mysqli_num_rows($course_q);
if($total_courses>0){
?>
	<table id="example1" class="table table-bordered table-striped col-sm-12">
	    <thead>
	      <tr>
	        <th>id</th>
	        <th>Course Code</th>
	        <th>Course Name</th>
	        <th>Edit</th>
	        <th>Delete</th>
	      </tr>
	    </thead>
	    <tbody>
		    <?php 
		    $i = 1;
		    while($course_details = mysqli_fetch_assoc($course_q)){ ?>  
		      <tr>
		        <td><?php echo $i; ?></td>
		        <td><?php echo $course_details['course_code']; ?></td>
		        <td><?php echo $course_details['course']; ?></td>
		        <td><a href="edit-course.php?action=edit&course_id=<?php echo $course_details['course_id'];?>&department_id=<?php echo $department_id;?>" title="Edit"><i class="text-warning fa fa-pencil-square-o fa-2x"></i></a></td>
		        <td>
		          <a href="courses.php?action=delete&course_id=<?php echo $course_details['course_id'];?>" title="Delete"><i class="text-danger fa fa-trash-o fa-2x"></i></a>
		        </td>
		      </tr>
		    <?php 
		    $i++;
			} ?>
	    </tbody>
	    <tfoot>
	      <tr>
	        <th>id</th>
	        <th>Course Code</th>
	        <th>Course Name</th>
	        <th>Edit</th>
	        <th>Delete</th>
	      </tr>
	    </tfoot>
	</table>
<?php 
}else{
	echo "<h3 class='text-danger text-center'>No Courses Added related to this Search</h3>";
} 

?>