<?php
include('../includes/connection.php');


$degree_id = $_POST['degree_id'];
$semester = $_POST['semester'];

$class = $degree_id.$semester;


$students_sql = mysqli_query($con, "SELECT * FROM `students` JOIN `class` ON `students`.`class`=`class`.`class_id` WHERE `class`.`degree`='$degree_id' AND `class`.`semester`='$semester' AND `students`.`activation_status`=1 ORDER BY `students`.`rollno` ASC");
$total_students = mysqli_num_rows($students_sql);

if ($total_students > 0) {
	?>
  <table id="example1" class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>id</th>
        <th>Student Name</th>
        <th>Rollno</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Edit Students</th>
        <th>Delete Students</th>
      </tr>
    </thead>
    <tbody>
      <?php  
      $i = 1;
      while($students = mysqli_fetch_assoc($students_sql)){ ?>
	      <tr>
	        <td><?php echo $i; ?></td>
	        <td><?php echo $students['name']; ?></td>
	        <td><?php echo $students['rollno']; ?></td>
	        <td><?php echo $students['email']; ?></td>
	        <td><?php echo $students['phone']; ?></td>
	        <td>
	            <a href="edit-student.php?action=edit&student_id=<?php echo $students['student_id'];?>&class_id=<?php echo $students['class'];?>" title="Edit Student"><i class="text-warning fa fa-pencil-square-o fa-lg fa-2x"></i></a>
	          </td>
	          <td>
	            <a href="students.php?action=delete&student_id=<?php echo $students['student_id'];?>" title="Delete Student"><i class="text-danger fa fa-trash-o fa-lg fa-2x"></i></a>
	          </td>
	      </tr>
	    <?php $i++; } ?>
    </tbody>
    <tfoot>
      <tr>
        <th>id</th>
        <th>Student Name</th>
        <th>Rollno</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Edit Student</th>
        <th>Delete Student</th>
      </tr>
    </tfoot>
  </table>	
	<?php
}else{
	echo "<h3 class='text-danger text-center'>Nothing to Display</h3>";
}
?>