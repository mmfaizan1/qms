<?php
include('../includes/connection.php');

$department_id = $_POST['department_id'];
$teachers_sql = mysqli_query($con, "SELECT * FROM `teachers` WHERE `department`='$department_id' AND `activation_status`=1");
$total_teachers = mysqli_num_rows($teachers_sql);

if ($total_teachers > 0) {
	?>
	<option value="">Select Teacher</option>
	<?php
	while($teachers = mysqli_fetch_assoc($teachers_sql)){
		?>
		<option value="<?php echo $teachers['teacher_id'];?>"><?php echo $teachers['name']; ?></option>
		<?php
	}
}else{
	echo "<option value=''>No teacher in this Department</option>";
}
?>