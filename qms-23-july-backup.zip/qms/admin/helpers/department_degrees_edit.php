<?php
include('../includes/connection.php');
 
$department_id = $_POST['department_id'];
$degree_id = $_POST['degree_id'];
$department_degree_q = mysqli_query($con, "SELECT * FROM `degree` WHERE `department_id`='$department_id'");
$total_degrees = mysqli_num_rows($department_degree_q);

if ($total_degrees > 0) {
	?>
	<option value="">Select Degree</option>
	<?php
	while($degrees = mysqli_fetch_assoc($department_degree_q)){
		?>
		<option value="<?php echo $degrees['degree_id'];?>" <?php if($degree_id==$degrees['degree_id']){echo 'selected';}else{echo '';}?>><?php echo $degrees['degree_name']; ?></option>
		<?php
	}
}else{
	echo "<option>No degree added for this Department</option>";
}
?>
