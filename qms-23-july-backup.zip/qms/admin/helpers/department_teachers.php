<?php
include('../includes/connection.php');
 
$department_id = $_POST['department_id'];
$teachers_sql = mysqli_query($con, "SELECT * FROM `teachers` WHERE `department`='$department_id' AND `activation_status`=1");
$total_teachers = mysqli_num_rows($teachers_sql);
?>

<?php
if ($total_teachers > 0 ){ ?>
  <table id="example1" class="table table-bordered table-striped">
    <thead>
      <tr>
        <th>id</th>
        <th>Teacher Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Edit Teacher</th>
        <th>Delete Teacher</th>
      </tr>
    </thead>
    <tbody>
      <?php  
      $i = 1;
      while($teacher = mysqli_fetch_assoc($teachers_sql)){
      ?>  
        <tr>
          <td><?php echo $i; ?></td>
          <td><?php echo $teacher['name']; ?></td>
          <td><?php echo $teacher['email']; ?></td>
          <td><?php echo $teacher['phone']; ?></td>
          <td>
            <a href="edit-teacher.php?action=edit&teacher_id=<?php echo $teacher['teacher_id'];?>&department_id=<?php echo $department_id;?>" title="Edit Teacher"><i class="text-warning fa fa-pencil-square-o fa-lg fa-2x"></i></a>
          </td>
          <td>
            <a href="teachers.php?action=delete&teacher_id=<?php echo $teacher['teacher_id'];?>" title="Delete Teacher"><i class="text-danger fa fa-trash-o fa-lg fa-2x"></i></a>
          </td>
        </tr>
      <?php
      $i++;
      } 
      ?>
    </tbody>
    <tfoot>
      <tr>
        <th>id</th>
        <th>Teacher Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Edit Teacher</th>
        <th>Delete Teacher</th>
      </tr>
    </tfoot>
  </table>
<?php 
}else{
  echo "<h3 class='text-danger text-center'>No records to show.</h3>";
}
?>