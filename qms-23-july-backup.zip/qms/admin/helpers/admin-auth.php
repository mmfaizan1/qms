<?php session_start();


if (isset($_POST['login'])) {
	include('../includes/connection.php');
	$email = $_POST['email'];
	$password = $_POST['password'];
	$verify_sql = "SELECT * FROM `admin` WHERE `email`='$email' AND `password`='$password'";
	$verify_sql_R = mysqli_query($con, $verify_sql);
	$result = mysqli_num_rows($verify_sql_R);
	if ($result > 0) {
		$_SESSION['email'] = $email;
		echo "<div class='alert alert-success'>Valid Login Details. Redirecting <img src='dist/img/loader.gif' alt='loading'></div>";
		?>
		<script type="text/JavaScript">
            setTimeout("location.href = 'index.php?Msg=logged_in';", 3000);
        </script>
        <?php
	}else{
		echo "<div class='alert alert-danger'>Invalid Username Or Password. Try Again</div>";		
	}
}
?>