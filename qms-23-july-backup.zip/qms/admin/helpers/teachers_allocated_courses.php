<?php
include('../includes/connection.php');

$department_id = $_POST['department_id'];
$teacher_id = $_POST['teacher_id'];

$teacher_courses_q = mysqli_query($con, "SELECT * FROM `course_allocation` JOIN `courses` ON `course_allocation`.`allocated_course_id`=`courses`.`course_id` JOIN `teachers` ON `course_allocation`.`course_teacher_id`=`teachers`.`teacher_id` WHERE `course_teacher_id`='$teacher_id'");
$total_courses_allocated = mysqli_num_rows($teacher_courses_q);

if($total_courses_allocated > 0){
	?>
	<table id="example1" class="table table-bordered table-striped">
	    <thead>
	      <tr>
	        <th>id</th>
	        <th>Course Code</th>
	        <th>Course Name</th>
	        <th>Deallocate Course</th>
	      </tr>
	    </thead>
	    <tbody>
	    <?php
	    $i = 1;
	    while ($courses = mysqli_fetch_assoc($teacher_courses_q)) {
			?>
			<tr>
		        <td><?php echo $i; ?></td>
		        <td><?php echo $courses['course_code'];?></td>
		        <td><?php echo $courses['course'];?></td>
		        <td>
		          <a href="course-allocation-teacher-list.php?action=deallocate&allocation_id=<?php echo $courses['course_allocation_id'];?>" title="Deallocate Course" class="text-danger"><i class="fa fa-close fa-2x"></i></a>
		        </td>
		    </tr>
			<?php
		$i++;
		}

	    ?>
	    </tbody>
	    <tfoot>
		    <tr>
		        <th>id</th>
		        <th>Course Code</th>
		        <th>Course Name</th>
		        <th>Deallocate Course</th>
		    </tr>
	    </tfoot>
	</table>
	<?php
}else{
	echo "<h3 class='text-center text-danger'>No Course Allocated to this Teacher</h3>";
}
?>