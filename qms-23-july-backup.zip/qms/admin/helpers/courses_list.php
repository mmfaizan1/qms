<?php
include('../includes/connection.php');

$department_id = $_POST['department_id'];
$courses_sql = mysqli_query($con, "SELECT * FROM `courses` WHERE `department`='$department_id'");
$total_courses = mysqli_num_rows($courses_sql);

if ($total_courses > 0) {
	?>
	<option value="">Select Course</option>
	<?php
	while($courses = mysqli_fetch_assoc($courses_sql)){
		?>
		<option value="<?php echo $courses['course_id'];?>"><?php echo $courses['course_code'].' - '.$courses['course']; ?></option>
		<?php
	}
}else{
	echo "<option value=''>No Course in this Department</option>";
}
?>