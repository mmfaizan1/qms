<?php


// function pagination($row_count){
// 	$pagination_buttons = 5;
// 	$page_number = (isset($_GET['page']) AND !empty($_GET['page']))? $_GET['page']:1;
// 	$per_page_records = 5;
// 	$rows = $row_count;
// 	$last_page = ceil($rows/$per_page_records); //round up

// 	$pagination = '';
// 	$pagination .= '<nav aria-label="">';
//     $pagination .= '<ul class="pagination">';


//     if ($page_number < 1) {
//     	$page_number = 1;
//     }else if($page_number > $last_page){
//     	$page_number = $last_page;
//     }
//     echo '<h3>Showing Page:'.$page_number.' / '. $last_page .'</h3>';
//     $half = floor($pagination_buttons/2); //round down
//     if ($page_number < $pagination_buttons AND ($last_page == $pagination_buttons OR $last_page>$pagination_buttons)) {
//     	for($i=1; $i<$pagination_buttons; $i++){
//     		if ($i==$page_number) {
//                 $pagination .= '<li class="active"><a href="departments.php?page='.$i.'">'.$i.'<span class="sr-only">(current)</span></a></li>';

//     		}else{
//     			$pagination .= '<li><a href="departments.php?page='.$i.'">'.$i.'</a></li>';

//     		}
//     	}
//     	if ($last_page > $pagination_buttons) {
//     		$pagination .= '<li><a href="departments.php?page='.($pagination_buttons+1).'">&raquo;</a></li>';
//     	}
//     }else if($page_number >= $pagination_buttons AND $last_page > $pagination_buttons){
//     	if (($page_number + $half) >= $last_page) {
//     		$pagination .= '<li><a href="departments.php?page='.($pagination_buttons - $pagination_buttons).'">&laquo;</a></li>';
// 	    	for($i = ($last_page - $pagination_buttons)+1; $i<=$last_page; $i++){
// 	    		if ($i==$page_number) {
// 	                $pagination .= '<li class="active"><a href="departments.php?page='.$i.'">'.$i.'<span class="sr-only">(current)</span></a></li>';

// 	    		}else{
// 	    			$pagination .= '<li><a href="departments.php?page='.$i.'">'.$i.'</a></li>';

// 	    		}	
// 	    	}
//     	}
//     }else if(($page_number + $half) < $last_page){
//     	$pagination .= '<li><a href="departments.php?page='.(($page_number - $half) - 1).'">&laquo;</a></li>';
//     	for($i = ($page_number - $half); $i<=($page_number+$half); $i++){
//     		if ($i==$page_number) {
//                 $pagination .= '<li class="active"><a href="departments.php?page='.$i.'">'.$i.'<span class="sr-only">(current)</span></a></li>';

//     		}else{
//     			$pagination .= '<li><a href="departments.php?page='.$i.'">'.$i.'</a></li>';

//     		}	
//     	}
//     	$pagination .= '<li><a href="departments.php?page='.(($page_number + $half) + 1).'">&raquo;</a></li>';
//     }
//     $pagination .= '</nav></ul>';
//     echo $pagination;
// }
?>