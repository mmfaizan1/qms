<?php
include('../includes/connection.php');

$department_id = $_POST['department_id'];
$course_degree = $_POST['course_degree'];
$course_semester = $_POST['course_semester'];

//Fetch class_id
$class_q = mysqli_query($con, "SELECT * FROM `class` WHERE `degree`='$course_degree' AND `semester`='$course_semester'");
$class_detail = mysqli_fetch_assoc($class_q); 
$class_id = $class_detail['class_id'];

$courses_q = mysqli_query($con, "SELECT * FROM `class_courses` JOIN `courses` ON `class_courses`.`course_id`=`courses`.`course_id` JOIN `class` ON `class_courses`.`course_class_id`=`class`.`class_id` JOIN `degree` ON `class`.`degree`=`degree`.`degree_id` JOIN `departments` ON `degree`.`department_id`=`departments`.`department_id` WHERE `courses`.`department`='$department_id' AND `class_courses`.`course_class_id`='$class_id'");

$total_courses = mysqli_num_rows($courses_q);

if ($total_courses > 0) {
?>

	<table id="example1" class="table table-bordered table-striped">
	    <thead>
	      <tr>
	        <th>id</th>
	        <th>Course Code</th>
	        <th>Course Name</th>
	        <th>Deallocate Course</th>
	      </tr>
	    </thead>
	    <tbody>
	    	<?php  
	    	$i=1;
	    	while ($courses = mysqli_fetch_assoc($courses_q)){
	    	?>
		      <tr>
		        <td><?php echo $i; ?></td>
		        <td><?php echo $courses['course_code']; ?></td>
		        <td><?php echo $courses['course']; ?></td>
		        <td>
		          <a href="course-allocation-class-list.php?action=deallocate&allocation_id=<?php echo $courses['class_course_id'];?>" title="Deallocate Course" class="text-danger"><i class="fa fa-close fa-2x"></i></a>
		        </td>
		      </tr>
		    <?php 
		    $i++;
			}
		    ?>
	    </tbody>
	    <tfoot>
	      <tr>
	        <tr>
	        <th>id</th>
	        <th>Course Code</th>
	        <th>Course Name</th>
	        <th>Deallocate Course</th>
	      </tr>
	      </tr>
	    </tfoot>
	</table>
<?php
}else{
	echo "<h3 class='text-center text-danger'>No Courses allocated to this class</h3>";
}
?>