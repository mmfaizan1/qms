<?php session_start();
include('session-set.php');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin | QMS</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/skin-blue.min.css">

    <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'logged_out') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">You are logged Out Successfully</h3>
                </div>
                <?php
              }else if($_GET['Msg'] == 'login_to_continue'){
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Please Login to Proceed.</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <div class="margin-top" style="margin-top: 100px;"></div>
    <div class="container">  
        <div class="col-xs-2 hidden-xs"></div>
        <div class="col-sm-8">
            <h1 class="text-center">Admin Login</h1>
            <div class="col-md-12 col-sm-12">
                <h3 class="text-center" id="status_message"></h3>
            </div>
            <form>
                <div class="form-group">
                    <label for="">Email address</label>
                    <input type="email" name="email" id="email" class="form-control" placeholder="Email">
                </div>
                <div class="form-group">
                    <label for="">Password</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                </div>
                <div class="form-group">  
                    <button type="button" id="login" value="login" class="btn btn-primary form-control">Login</button>
                </div>
            </form>
        </div>
    </div>
<hr>
  <!-- Main Footer -->
  <footer>
    <div class="container">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
          <h3>Made with <i class="fa fa-heart text-red"></i> by Unstoppables</h3>
        </div>
        <!-- Default to the left -->
        <h3><strong>Copyright &copy; 2018 <a href="#">QMS</a>.</strong> All rights reserved.</h3>
    </div>
  </footer>
  <!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>

<!-- Custom JS -->
<script src="dist/js/custom.js"></script>
<!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. -->
</body>
</html>