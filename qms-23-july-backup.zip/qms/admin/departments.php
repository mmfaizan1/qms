<?php include('includes/top.php');
include('includes/connection.php');

if(isset($_GET['action'])){
  if ($_GET['action'] == 'delete') {
    $dept_id = $_GET['department_id'];
    $delete_dept_q = mysqli_query($con, "DELETE FROM `departments` WHERE `department_id`='$dept_id'");
    if($delete_dept_q){
      ?>
      <script>
        window.location = 'departments.php?Msg=deleted';
      </script>
      <?php
    }else{
      ?>
      <script>
        window.location = 'departments.php?Msg=failure';
      </script>
      <?php
    }
  }
}
//pagination code
$records_per_page = 5;
if (isset($_GET['page']) AND !empty($_GET['page'])) {
  $page_number = $_GET['page'];
}else{
  $page_number = 1;
}

$start_from = ($page_number - 1) * $records_per_page;
$departments_q = mysqli_query($con, "SELECT * FROM `departments` LIMIT $start_from, $records_per_page");
$total_departments = mysqli_num_rows($departments_q);
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Departments
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'deleted') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Department Deleted Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'updated') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Department Updated Successfully</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>

    <!-- Main content -->
    <section class="content container-fluid">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">Departments List</h3>
        </div>
        <!-- /.box-header -->
        <?php if($total_departments > 0){ ?>
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Department Name</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $i = 1;
                while($departments = mysqli_fetch_assoc($departments_q)):
                ?>
                  <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $departments['department_name']; ?></td>
                    <td>
                      <a href="edit-department.php?department_id=<?php echo $departments['department_id'];?>" title="Edit"><i class="text-warning fa fa-pencil-square-o fa-lg fa-2x"></i></a>
                    </td>
                    <td>  
                      <a href="departments.php?action=delete&department_id=<?php echo $departments['department_id'];?>" title="Delete"><i class="text-danger fa fa-trash-o fa-lg fa-2x"></i></a>
                    </td>
                  </tr>
                <?php
                $i++;
                endwhile;
                ?>
              </tbody>
              <tfoot>
                <tr>
                  <th>#</th>
                  <th>Department Name</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
              </tfoot>
            </table>
            <?php
            //pagination links
            $pagination_links_q =mysqli_query($con, "SELECT COUNT(*) AS total FROM `departments`");
            $total = mysqli_fetch_assoc($pagination_links_q); 
            $total = $total['total'];
            $pages = ceil($total / $records_per_page);
            ?>
            <h4>Showing <?php echo $total_departments; ?> Records on this page</h4>
            <ul class="pagination">
              <?php
                for($i=1; $i<=$pages; $i++){
                  ?>
                  <!-- Highlighting active links -->
                  <li class="<?php echo (isset($_GET["page"])) && $_GET['page']== $i ? 'active':''; ?>">
                    <a href="departments.php?page=<?php echo $i;?>">
                      <?php echo $i; ?>
                    </a>
                  </li>
                  <?php
                }
              ?>
            </ul>
          </div>
          <!-- /.box-body -->
      </div>
      <?php 
      }else{
        echo "<div class='row'><h3 class='text-danger text-center'>No Departments Exists. Add one to view.</h3></rows>";
      }
      ?>
      <!-- /.box -->  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php 
include('includes/footer.php');
?>