<?php include('includes/top.php');
include('includes/connection.php');

$dept_id = $_GET['department_id'];

if (isset($_POST['update'])) {
  $department_name = $_POST['department_name'];

  if (empty($department_name)) {
     ?>
      <script>
        window.location = 'edit-department.php?department_id=<?php echo $dept_id;?>&Msg=empty_name';
      </script>
     <?php
  }else{
    $update_department_q = mysqli_query($con, "UPDATE `departments` SET `department_name`='$department_name' WHERE `department_id`='$dept_id'");
    if ($update_department_q) {
      ?>
      <script>
        window.location = 'departments.php?Msg=updated';
      </script>
      <?php
    }
  } 
}

$department_data_q = mysqli_query($con, "SELECT * FROM `departments` WHERE `department_id`='$dept_id'");
$department_data = mysqli_fetch_assoc($department_data_q);
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Departments
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'empty_name') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Please Fill In all the Required Fields</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>

    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Edit department</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label>Department Name</label>
                  <input type="text" class="form-control" name="department_name" placeholder="Enter Department Name" value="<?php echo $department_data['department_name'];?>" required>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" value="update" class="btn btn-primary" name="update">Update Departments</button>
                <a href="departments.php" type="submit" class="btn btn-default">Cancel</a>
              </div>
            </form>
          </div>
          <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>