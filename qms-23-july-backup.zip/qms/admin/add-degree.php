<?php include('includes/top.php');

include('includes/connection.php');

if (isset($_POST['add'])) {
  $department_id = $_POST['department'];
  $degree_name = $_POST['degree'];
  $duplicate_degree = mysqli_query($con, "SELECT * FROM `degree` WHERE `department_id`='$department_id' AND `degree_name`='$degree_name'");
  if(mysqli_num_rows($duplicate_degree) > 0 ){
    ?>
      <script>
        window.location = 'add-degree.php?Msg=exists';
      </script>
     <?php
  }else if (empty($department_id) || empty($degree_name)) {
     ?>
      <script>
        window.location = 'add-degree.php?Msg=empty';
      </script>
     <?php
  }else{
    $add_degree_q = mysqli_query($con, "INSERT INTO `degree` (`department_id`,`degree_name`) VALUES ('$department_id','$degree_name')");
    if ($add_degree_q) {
      ?>
      <script>
        window.location = 'add-degree.php?Msg=added';
      </script>
      <?php
    }
  }
}

$department_data_q = mysqli_query($con, "SELECT * FROM `departments`");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Degrees
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if($_GET['Msg'] == 'added'){
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Success! Degree Added Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'empty') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Please Fill in all the Required fields</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'exists') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Degree Already Exists. Please Choose Another Degree Name against this Department</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add a degree</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">
                <div class="form-group">
                    <label>Department</label>
                    <select class="form-control select2" style="width: 100%;" name="department" required>
                      <option value="">Select Department</option>
                      <?php
                      while ($departments = mysqli_fetch_assoc($department_data_q)) {
                        ?>
                        <option value="<?php echo $departments['department_id'];?>">
                            <?php echo $departments['department_name']; ?>  
                        </option>
                        <?php
                      }
                      ?>
                    </select>
                </div>
                <div class="form-group">
                  <label>Degree Name</label>
                  <input type="text" class="form-control" placeholder="Enter Degree Name" name="degree" required>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" value="add" name="add" class="btn btn-primary">Add Degree</button>
                <a href="degrees.php" type="submit" class="btn btn-default">Cancel</a>

              </div>
            </form>
          </div>
          <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>