<?php 
include('includes/top.php');

include('includes/connection.php');

$department_id = $_GET['department_id'];
$teacher_id = $_GET['teacher_id'];

if (isset($_POST['update'])) {
  $teacher_name = $_POST['teacher_name'];
  $teacher_email = $_POST['teacher_email'];
  $teacher_department = $_POST['teacher_department'];
  $teacher_phone = $_POST['teacher_phone'];

  if (empty($teacher_name) || empty($teacher_email) || empty($teacher_department) || empty($teacher_phone)) {
     ?>
      <script>
        window.location = 'edit-teacher.php?action=edit&teacher_id=<?php echo $teacher_id;?>&department_id=<?php echo $department_id;?>&Msg=empty';
      </script>
     <?php
  }else{
    $update_teacher_q = mysqli_query($con, "UPDATE `teachers` SET `name`='$teacher_name', `email`='$teacher_email', `department`='$teacher_department', `phone`='$teacher_phone' WHERE `teacher_id`='$teacher_id'");
    if ($update_teacher_q) {
      ?>
      <script>
        window.location = 'teachers.php?Msg=updated';
      </script>
      <?php
    }else{
      ?>
      <script>
        window.location = 'teachers.php?Msg=failure';
      </script>
      <?php
    }
  }
}


//populate departments
$departments_q = mysqli_query($con, "SELECT * FROM `departments`");

//Populate teachers data

$teacher_q = mysqli_query($con, "SELECT * FROM `teachers` WHERE `teacher_id`='$teacher_id'");
$teacher_data = mysqli_fetch_assoc($teacher_q);
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Teachers
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'empty') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Please Fill In all the Required Fields</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Update Teacher Details</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label>Name</label>
                  <input type="text" name="teacher_name" class="form-control" placeholder="Enter Name" value="<?php echo $teacher_data['name'];?>" required>
                </div>
                <div class="form-group">
                  <label>Email address</label>
                  <input type="email" name="teacher_email" class="form-control" placeholder="Enter email" value="<?php echo $teacher_data['email'];?>" required>
                </div>
                <div class="form-group">
                    <label>Department</label>
                    <select class="form-control select2" name="teacher_department" style="width: 100%;" required="">
                      <option value="">Select Department</option>
                      <?php while($departments = mysqli_fetch_assoc($departments_q)){ ?>  
                        <!-- <option selected>CS&IT</option> -->
                        <option value="<?php echo $departments['department_id'];?>" <?php echo (($departments['department_id'] == $department_id)? 'selected':'')?> ><?php echo $departments['department_name']; ?></option>
                      <?php } ?>
                    </select>
                  <!-- /.form-group -->
                </div>
                <div class="form-group">
                  <label>Phone</label>
                  <input type="number" name="teacher_phone" class="form-control" placeholder="Enter Phone Number (Example: 03001234567)" value="<?php echo $teacher_data['phone'];?>" required>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" value="update" class="btn btn-primary" name="update">Update Teacher Details</button>
                <a type="submit" href="teachers.php" class="btn btn-default">Cancel</button>
              </a>
            </form>
          </div>
          <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>