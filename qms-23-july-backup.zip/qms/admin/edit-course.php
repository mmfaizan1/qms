<?php 
include('includes/top.php');
include('includes/connection.php');
$course_id = $_GET['course_id'];
$department_id = $_GET['department_id'];



$populate_fields_q = mysqli_query($con, "SELECT * FROM `courses` WHERE `course_id`='$course_id'");
$course_details = mysqli_fetch_assoc($populate_fields_q);
//populate departments query
$departments_q = mysqli_query($con, "SELECT * FROM `departments`");


if (isset($_POST['update']) && !empty($_POST)) {
  $department = $_POST['departments'];
  $code = $_POST['code'];
  $course_name = $_POST['course_name'];
  if (empty($department) || empty($code) || empty($course_name)) {
    ?>
    <script>window.location='edit-course.php?action=edit&course_id=<?php echo $course_details['course_id'];?>&department_id=<?php echo $department_id;?>&Msg=empty';</script>
    <?php
  }else{
    $update_course_q = mysqli_query($con, "UPDATE `courses` SET `course`='$course_name', `course_code`='$code', `department`='$department' WHERE `course_id`='$course_id'");
    if ($update_course_q) {
      ?>
      <script>window.location='courses.php?Msg=updated'</script>
      <?php
    }else{
      ?>
      <script>window.location='edit-course.php?action=edit&course_id=<?php echo $course_details['course_id'];?>&department_id=<?php echo $department_id;?>&Msg=failure';'</script>
      <?php
    }
  }
}

?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Courses
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'empty') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Fill in all the required fields</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Edit a Course</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <form method="post">
            <div class="form-group">
              <label>Select Department</label>
              <select name="departments" id="student_department" class="form-control course_department" required>
                <option value="">Select Department</option>
                <?php
                while($department = mysqli_fetch_assoc($departments_q)){
                  ?>
                  <option value="<?php echo $department['department_id'];?>" <?php echo (($department['department_id']==$department_id)?'selected':''); ?>><?php echo $department['department_name'];?></option>
                  <?php
                }
                ?>
              </select>
            </div>
            <div class="form-group">
              <label>Course Code</label>
              <input type="text" name="code" class="form-control" value="<?php echo $course_details['course_code'];?>" required>
            </div>
            <div class="form-group">
              <label>Course Name</label>
              <input type="text" name="course_name" class="form-control" value="<?php echo $course_details['course'];?>" required>
            </div>
            <div class="form-group">
              <button type="submit" name="update" value="update" class="btn btn-success">Update</button>
            </div>
          </form>
        </div>
        <!-- /.box-body -->
          
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>