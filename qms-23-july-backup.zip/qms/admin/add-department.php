<?php 
include('includes/top.php');
include('includes/connection.php');

if (isset($_POST['add'])) {
  $department_name = $_POST['department_name'];
  $duplicate_department = mysqli_query($con, "SELECT * FROM `departments` WHERE `department_name`='$department_name'");
  if(mysqli_num_rows($duplicate_department) > 0 ){
    ?>
      <script>
        window.location = 'add-department.php?Msg=exists';
      </script>
     <?php
  }else if (empty($department_name)) {
     ?>
      <script>
        window.location = 'add-department.php?Msg=empty_name';
      </script>
     <?php
  }else{
    $add_department_q = mysqli_query($con, "INSERT INTO `departments` (`department_name`) VALUES ('$department_name')");
    if ($add_department_q) {
      ?>
      <script>
        window.location = 'add-department.php?Msg=added';
      </script>
      <?php
    }else{
      ?>
      <script>
        window.location = 'add-department.php?Msg=failure';
      </script>
      <?php
    }
  } 
}
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Departments
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if($_GET['Msg'] == 'added'){
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Success! Department Added Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'empty_name') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Please Fill in all the Required fields</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'exists') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Attention! Department Already Exists. Please Choose Another Department Name</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">

      <!-- Your Page Content Here -->
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Add a department</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" method="post">
              <div class="box-body">
                <div class="form-group">
                  <label>Department Name</label>
                  <input type="text" class="form-control" name="department_name" placeholder="Enter Department Name" required>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" value="add" class="btn btn-primary" name="add">Add Department</button>
                <a href="departments.php" type="submit" class="btn btn-default">Cancel</a>
              </div>
            </form>
          </div>
          <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>