<?php 
include('includes/top.php');
include('includes/connection.php');
if(isset($_GET['action'])){
  if ($_GET['action'] == 'delete') {
    $teacher_id = $_GET['teacher_id'];
    $delete_teacher_q = mysqli_query($con, "DELETE FROM `teachers` WHERE `teacher_id`='$teacher_id'");
    if($delete_teacher_q){
      ?>
      <script>
        window.location = 'teachers.php?Msg=deleted';
      </script>
      <?php
    }else{
      ?>
      <script>
        window.location = 'teachers.php?Msg=failure';
      </script>
      <?php
    }
  }
}

$departments_q = mysqli_query($con, "SELECT * FROM `departments`");
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Teachers
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
        <li class="active">Here</li>
      </ol>
    </section>
    <div class="container">  
      <div class="row status-messages">
          <?php
            if(isset($_GET['Msg'])){
              if ($_GET['Msg'] == 'deleted') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Teacher Deleted Successfully</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'failure') {
                ?>
                <div class="alert alert-danger">
                  <h3 class="text-center">Unable to perform required operation</h3>
                </div>
                <?php
              }else if ($_GET['Msg'] == 'updated') {
                ?>
                <div class="alert alert-success">
                  <h3 class="text-center">Teacher Updated Successfully</h3>
                </div>
                <?php
              }
            }
          ?>
      </div>
    </div>
    <!-- Main content -->
    <section class="content container-fluid">
      <div class="box">
            <div class="box-header">
              <h3 class="box-title">Teachers List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form method="post">
                <div class="form-group">
                  <label>Select Department</label>
                  <select id="department" class="form-control">
                    <option value="">Select Department</option>  
                    <?php 
                    $i = 1;
                    while($department_details = mysqli_fetch_assoc($departments_q)){
                    ?>
                    <option value="<?php echo $department_details['department_id']?>"><?php echo $department_details['department_name']; ?></option>
                    <?php 
                    } 
                    ?>
                  </select>
                </div>
              </form>
              <div id="result-data">
                <h3 class="text-danger text-center">
                  Select department to view teachers list
                </h3>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->  
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php include('includes/footer.php');?>