<?php
include('includes/connection.php');
if (isset($_POST['signup']) && !empty($_POST)) {
  
  $student_name = $_POST['name'];
  $student_email = $_POST['email'];
  $student_department = $_POST['department'];
  $degree = $_POST['degree'];
  $password = $_POST['password'];
  $semester = $_POST['semester'];
  $session_year = $_POST['year'];
  $degree_level = $_POST['degree_level'];
  $rollno = $_POST['rollno'];
  $student_rollno = $session_year.'-'.$degree_level.'-'.$rollno;
  $phone = $_POST['phone'];  
  
  //fetch class
  $fetch_class_q = mysqli_query($con, "SELECT * FROM `class` WHERE `degree`='$degree' AND `semester`='$semester'");
  $is_class_found = mysqli_num_rows($fetch_class_q);
  $student_class=mysqli_fetch_assoc($fetch_class_q);
  $student_class_id = $student_class['class_id'];
  //validate email
  $duplicate_email_q = mysqli_query($con, "SELECT * FROM `students` WHERE `email`='$student_email'");
    //validate rollno
  $duplicate_rollno_q = mysqli_query($con, "SELECT * FROM `students` WHERE `rollno`='$student_rollno'");

  if (empty($student_name) OR empty($student_email) OR empty($student_department) OR empty($degree) OR empty($semester) OR empty($session_year) OR empty($degree_level) OR empty($rollno) OR empty($phone)) {
    ?>
      <div class="alert alert-danger"><h3 class="text-center">Fill in all the Required Fields</h3></div>
    <?php
  }else if (mysqli_num_rows($duplicate_email_q) > 0) {
    ?>
      <div class="alert alert-danger"><h3 class="text-center">Email Already Exists. Choose a different one.</h3></div>
    <?php
    die();
  }else if (mysqli_num_rows($duplicate_rollno_q) > 0) {
    ?>
      <div class="alert alert-danger"><h3 class="text-center">Roll no Already Exists. Choose a different one.</h3></div>
    <?php
    die();
  }else{
    if($is_class_found > 0){  
      $insert_student_q = mysqli_query($con, "INSERT INTO `students` (`name`, `rollno`, `class`, `email`, `phone`, `password`,`activation_status`) VALUES ('$student_name','$student_rollno','$student_class_id','$student_email','$phone','$password','0')");
      if ($insert_student_q) {
        ?>
        <div class="alert alert-success"><h3 class="text-center">Success! You are registered successfully.</h3></div>
        <?php
      }else{
        ?>
        <div class="alert alert-danger"><h3 class="text-center">Unable to perform required operation.</h3></div>
        <?php
      }
    }else{
      ?>
        <div class="alert alert-danger"><h3 class="text-center">Class to which you are adding student, doesnot found.</h3></div>
      <?php
    }
  }
}