<?php 
$page = 'dashboard';
include('includes/top.php');
include('includes/connection.php');

$teacher_id = $_SESSION['teacher_id']; 
$quiz_q = mysqli_query($con, "SELECT * FROM `quiz` WHERE `quiz_created_by`='$teacher_id'");
$total_quizzes = mysqli_num_rows($quiz_q);

$ongoing_q = mysqli_query($con, "SELECT * FROM `quiz` WHERE `quiz_created_by`='$teacher_id' AND `status`=2");
$ongoing_quizzes = mysqli_num_rows($ongoing_q);

$missed_q = mysqli_query($con, "SELECT * FROM `quiz` WHERE `quiz_created_by`='$teacher_id' AND `status`=5");
$missed_quizzes = mysqli_num_rows($missed_q);

$notification_q = mysqli_query($con, "SELECT * FROM `notifications` WHERE `notification_for`='teacher' ORDER BY `notification_id` DESC Limit 0,10");
$total_notifications = mysqli_num_rows($notification_q);

$new_quiz_q = mysqli_query($con, "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject`=`courses`.`course_id` WHERE `quiz_created_by`='$teacher_id' AND `status`=1");
$new_quizzes = mysqli_num_rows($new_quiz_q);
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="well" style="background-color:#8f6ad2; color:white;"><h3 class="text-center">Quizzes</h3></div>
                <div class="col-md-4">
                    <div class="panel panel-default">
                      <!-- <div class="panel-heading">
                        <h3 class="panel-title">Total Quizzes</h3>
                        </div>-->
                      <div class="panel-body">
                        <div class="col-sm-6"><a href="quizzes.php"><i class="fa fa-clipboard fa-4x pull-right"></i></a></div>
                      </div>
                      <div class="panel-footer">Total Quizzes <span class="pull-right"><?php echo $total_quizzes; ?></span></div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-default">
                      <!-- <div class="panel-heading">
                        <h3 class="panel-title">Total Quizzes</h3>
                        </div>-->
                      <div class="panel-body">
                        <div class="col-sm-6"><a href="ongoing-quiz.php"><i class="fa fa-check-circle fa-4x pull-right text-success"></i></a></div>
                      </div>
                      <div class="panel-footer">Ongoing Quizzes<span class="pull-right"><?php echo $ongoing_quizzes; ?></span></div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="panel panel-default">
                      <!-- <div class="panel-heading">
                        <h3 class="panel-title">Total Quizzes</h3>
                        </div>-->
                      <div class="panel-body">
                        <div class="col-sm-6"><a href="missed-quiz.php"><i class="fa fa-warning fa-4x pull-right text-danger"></i></a></div>
                      </div>
                      <div class="panel-footer">Missed Quizzes <span class="pull-right"><?php echo $missed_quizzes; ?></span></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="col-md-12">
                    <div class="panel panel-default">
                      <!-- <div class="panel-heading">
                        <h3 class="panel-title">Total Quizzes</h3>
                        </div>-->
                      <div class="panel-body">
                        <div class="col-sm-12">
                            <h3 class="text-info text-center">Announcements</h3>
                            <ul class="list-group">
                                <?php
                                if ($total_notifications > 0) {
                                    while ($notification = mysqli_fetch_assoc($notification_q)) {
                                        $severity = $notification['severity'];
                                        ?>
                                        <li class="list-group-item"><a class="text-<?php if($severity == 1){echo "info";}else if($severity == 2){echo "warning";}else if($severity == 3){echo "danger";}?>" href="notifications.php"><?php echo $notification['title']; ?></a></li>
                                        <?php        
                                    }
                                }else{
                                    ?>
                                    <li class="list-group-item">
                                        <h4 class="text-info text-center">No Announcement</h4>
                                    </li>
                                    <?php
                                }
                                ?>
                              </ul>
                        </div>
                      </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8">
                <div class="panel panel-default">
                    <div class="panel-heading">
                    <h3 class="panel-title"><h3 class="text-primary text-center">New Quizzes</h3></h3>
                    </div>
                    <div class="panel-body">
                        <div class="col-sm-12">
                            <?php
                            if ($new_quizzes > 0 ) {
                                while($new_quiz = mysqli_fetch_assoc($new_quiz_q)){
                                    ?>
                                    <div class="alert alert-info">    <a href="quizzes.php" class="text-primary">  
                                        <?php echo $new_quiz['topic']. " - ".$new_quiz['course_code']." - ".$new_quiz['course']; ?></div>
                                    </a>
                                    <?php
                                }  
                            }else{
                                ?>
                                <h3 class="text-danger text-center">No New Quizzes Right Now.</h3>
                                <?php
                            }

                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>
<?php
    //success or error messages
    if (isset($_GET['msg'])) {
        if($_GET['msg']=='logged_in'){    
            ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    demo.initChartist();

                    $.notify({
                        icon: 'ti-check-box',
                        message: "Welcome User. You are successfully Logged in"

                    },{
                        type: 'success',
                        timer: 4000
                    });

                });
            </script>
            <?php
        }else if($_GET['msg']=='already_logged_in'){    
            ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    demo.initChartist();

                    $.notify({
                        icon: 'ti-close',
                        message: "Attention. You are already logged in"

                    },{
                        type: 'danger',
                        timer: 4000
                    });

                });
            </script>
            <?php
        }else if($_GET['msg']=='logged_in_p'){    
            ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    demo.initChartist();

                    $.notify({
                        icon: 'ti-check-box',
                        message: "Welcome User.You have set your Password and You are successfully Logged in"

                    },{
                        type: 'success',
                        timer: 4000
                    });

                });
            </script>
            <?php
        }
    }
?>