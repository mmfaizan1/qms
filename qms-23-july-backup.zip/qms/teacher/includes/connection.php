<?php


$con = mysqli_connect('localhost', 'root', '', 'qms');
if (!$con) {
	mysqli_connect_errno();
}
?>