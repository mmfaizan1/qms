<?php 
include('../includes/connection.php');



if (isset($_POST['submit'])) {
	$quiz_id = $_POST['quiz_id'];
	$course_id = $_POST['course_id'];
	$existing_questions = $_POST['existing_questions'];
	$existing_questions = explode(",", $existing_questions);
	//print_r($existing_questions);
	$total_existing_questions = count($existing_questions);

	$db_questions_q = mysqli_query($con, "SELECT * FROM `question_paper` WHERE `quiz`='$quiz_id'");
	$i=0;
	$db_questions_array = array();
	while($db_questions = mysqli_fetch_array($db_questions_q)){
		//echo $db_questions['paper_question'];echo "<br>";
		$db_questions_array[$i] = $db_questions['paper_question'];
		$i++;
	}
	//print_r($db_questions_array);
	//to find existing records in database
	$intersection_array = array_intersect($existing_questions, $db_questions_array);
	//print_r($intersection_array);
	//to merge existing records in database with existing questions and find the unique records
	$merged_array = array_merge($existing_questions, $intersection_array);
	//print_r($merged_array);
	// $unique_array = array_diff($intersection_array, $existing_questions);
	// print_r($unique_array);
	
	/*
	Q - How can I remove ALL duplicates from an array in PHP?
	Ans - You could use the combination of array_unique, array_diff_assoc and array_diff. 
	*/
	$unique_array = array_diff($merged_array, array_diff_assoc($merged_array, array_unique($merged_array)));
	//print_r($unique_array);
	if(empty($unique_array)){
		echo "<div class='alert alert-danger'><h3 class='text-center'>0 out of ".$total_existing_questions ." Questions are Inserted. Because All Questions Already Exists</h3></div>";
	}else{
		$total_questions_inserted = count($unique_array);
		foreach ($unique_array as $paper_question) {
		 	$paper_question_qR = mysqli_query($con, "INSERT INTO `question_paper` (`quiz`,`paper_question`) VALUES ('$quiz_id','$paper_question')");
		}
		if ($paper_question_qR) {
			echo "<div class='alert alert-success'><h3 class='text-center'>". $total_questions_inserted ." out of ".$total_existing_questions ." Questions are Inserted ignoring possible duplicate questions.</h3></div>";
			?>
	 		<script>
				$("#questions-form")[0].reset();
			</script>
		<?php
		}
	}

}
?>