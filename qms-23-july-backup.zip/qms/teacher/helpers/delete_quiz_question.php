<?php
include('../includes/connection.php');


if (isset($_POST['submit'])) {
	$questions = explode(",", $_POST['questions_array']);
	$quiz_id = $_POST['quiz_id'];
	//print_r($questions);
	if(is_array($questions)){
		foreach ($questions AS $question) {
			$delete_questions_q = mysqli_query($con, "DELETE FROM `question_paper` WHERE `paper_question`='$question'");
		}
		if($delete_questions_q){
			?>
			<script type="text/javascript">
				window.location='quiz-questions.php?Msg=deleted';
			</script>
			<?php
		}
	}
}