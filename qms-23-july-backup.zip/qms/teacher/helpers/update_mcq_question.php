<?php session_start();
include('../includes/connection.php');

if (isset($_POST['submit'])) {
	$question_id = $_POST['question_id'];
	$mcq_question = $_POST['mcq_question'];
	$option1 = $_POST['option1'];
	$option2 = $_POST['option2'];
	$option3 = $_POST['option3'];
	$option4 = $_POST['option4'];
	$correct = $_POST['correct'];
	//checking if question exists or not
	$question_from_db = "SELECT `question` FROM `questions`";
	$question_from_dbR = mysqli_query($con, $question_from_db);
	$update_question = mysqli_query($con, "UPDATE `questions` SET `question`='$mcq_question' WHERE `question_id`='$question_id'");
	//Update mcqs options
	$update_options_q = mysqli_query($con, "UPDATE `mcq_options` SET `option_1`='$option1',`option_2`='$option2',`option_3`='$option3',`option_4`='$option4' WHERE `mcq_question_id`='$question_id'");
	//Update correct answer
	$correct_option_q = mysqli_query($con, "UPDATE `solution` SET `solution`='$correct' WHERE`solution_question_id`='$question_id'");

	if($update_question && $update_options_q && $correct_option_q){
		?>
		<script>
			window.location='quiz-questions.php?Msg=updated';
		</script>
		<?php
	}else{
		echo "<div class='alert alert-danger'><h3 class='text-center'>Unable To Update Question.</h3></div>";
	}
}


?>


