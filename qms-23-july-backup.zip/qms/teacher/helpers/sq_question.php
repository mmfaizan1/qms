    <hr><h2 class="text-center text-danger">Question Type: Descriptive</h2>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label>Question</label>
                <input type="text" class="form-control">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label>Keywords (To be separated with commas)</label>
                <textarea name="" id="" cols="30" rows="5" class="form-control" required></textarea>
            </div>
        </div>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-info btn-fill btn-wd">Add Question</button>
    </div>