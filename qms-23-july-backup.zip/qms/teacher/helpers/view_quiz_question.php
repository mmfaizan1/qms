<?php
include('../includes/connection.php');


if (isset($_POST['submit'])) {
	$questions = explode(",", $_POST['questions_array']);
	$quiz_id = $_POST['quiz_id'];
	//print_r($questions);
	if(is_array($questions)){
		$i=1;
		foreach ($questions AS $question) {
		 	$fetch_questions_q = mysqli_query($con, "SELECT * FROM `questions` JOIN `solution` ON `questions`.`question_id`=`solution`.`solution_question_id` WHERE `question_id`='$question'");
		 	while($questions_detail = mysqli_fetch_assoc($fetch_questions_q)){
		 		$question_id = $questions_detail['question_id'];
		 		$question_type = $questions_detail['question_type'];
		 		
		 		?>
	 			<div class="row">
    	            <div class="col-lg-12 col-md-11">
    	            	<div class="card">
    	                   <div class="header">
                                <h4 class="title">Question # <?php echo $i; ?>: <?php echo $questions_detail['question'];?></h4>
                            </div>
	                        <?php if($question_type == 1){ ?>    
	                            <div class="content">
	                                <?php 
	                                $mcq_options_Q = "SELECT * FROM `mcq_options` JOIN `questions` ON `questions`.`question_id` = `mcq_options`.`mcq_question_id` WHERE `questions`.`question_type`=1 AND `questions`.`question_id`='$question_id'";
	                                $mcq_options_QR = mysqli_query($con, $mcq_options_Q);
	                                
	                                while($mcq_option = mysqli_fetch_assoc($mcq_options_QR)):
	                                    ?>
	                                    <div class="col-md-6">
	                                        <div class="form-group">
	                                            <input type="radio" disabled><?php echo $mcq_option['option_1']; ?>
	                                        </div>
	                                    </div>
	                                    <div class="col-md-6">
	                                        <div class="form-group">
	                                            <input type="radio" disabled><?php echo $mcq_option['option_2']; ?>
	                                        </div>
	                                    </div>
	                                    <div class="col-md-6">
	                                        <div class="form-group">
	                                            <input type="radio" disabled><?php echo $mcq_option['option_3']; ?>
	                                        </div>
	                                    </div>
	                                    <div class="col-md-6">
	                                        <div class="form-group">
	                                            <input type="radio" disabled><?php echo $mcq_option['option_4']; ?>
	                                        </div>
	                                    </div>
	                                    <div class="col-sm-12">
	                                    	<h3 class="text-danger">
	                                    		Correct Answer:
	                                    		<?php echo $questions_detail['solution']; ?>
	                                    	</h3>
	                                    </div>
	                                    <div class="clearfix"></div>
	                                    <?php
	                                endwhile;
	                                ?>    
	                            </div>
	                        <?php }elseif($question_type==2){?>
                        		<div class="content">
                        			<input type="text" placeholder="Enter Answer" class="form-control" disabled>
                        			<div class="col-sm-12">
	                                	<h3 class="text-danger">
	                                		Correct Answer:
	                                		<?php echo $questions_detail['solution']; ?>
	                                	</h3>
                                	</div>
                                	<div class="clearfix"></div>
                        		</div>
                            <?php }elseif($question_type == 3){?>
    	            			<div class="content">
                        			<textarea placeholder="Enter Answer" class="form-control" rows="4" disabled></textarea>
                        			<div class="col-sm-12">
	                                	<h3 class="text-danger">
	                                		Answer Keywords:
	                                		<?php echo $questions_detail['solution']; ?>
	                                	</h3>
                                	</div>
                                	<div class="clearfix"></div>
                        		</div>
	                        <?php } ?>
    	            	</div>
    	            </div>
                </div>
		 		<?php
		 	$i++;
		 	}//while loop ends
		}
		?>
		<?php
	}else{
		echo "<div class='alert alert-danger'><h3 class='text-center'>Error in executing the required operation</h3></div>";
	}
}
?>