<?php 
include('../includes/connection.php');


$quiz_id = $_POST['quiz_id'];
$course_id = $_POST['course_id'];
$existing_questions_q = "SELECT * FROM `questions` JOIN `question_types` ON `questions`.`question_type` = `question_types`.`type_id` WHERE `questions`.`course`='$course_id' ORDER BY `question_types`.`type_id` ASC, `questions`.`question_id` ASC";
$existing_questions_qR = mysqli_query($con, $existing_questions_q);


?>

<hr><h2 class="text-center text-danger">Select questions from existing</h2>
	<div class="content table-responsive table-full-width">
		<table class="table table-hover table-striped table-bordered">
			<thead>
				<th class="col-sm-1">Select questions</th>
				<th class="col-sm-1">Question Type</th>
				<th class="col-sm-6">Question</th>
			</thead>
			<tbody>
				<?php while($questions = mysqli_fetch_assoc($existing_questions_qR)): ?>
				<tr>
					<td class="col-sm-1"><input type="checkbox" id="existing_question_checkbox" value="<?=$questions['question_id'];?>" required></td>
					<td class="col-sm-1"><?php echo $questions['type'];?></td>
					<td class="col-sm-6"><?php echo $questions['question'];?></td>
				</tr>
				<?php endwhile; ?>
			</tbody>
		</table>
	</div>
	<div class="form-group">
        <button type="button" class="btn btn-info btn-fill btn-wd" id="add_existing_questions" value="add_existing_questions">Add Existing Questions</button>
    </div>
    <script type="text/javascript" src="assets/js/custom.js"></script>