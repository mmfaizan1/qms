<?php session_start();
include('../includes/connection.php');


$teacher_id = $_SESSION['teacher_id'];
$course_id = $_POST['course_id'];
$course_class = $_POST['course_class'];
$topic = $_POST['topic'];
//fetch quiz id
$quiz_id_q = mysqli_query($con, "SELECT * FROM `quiz` WHERE `topic`='$topic'");
$quiz_id_detail = mysqli_fetch_assoc($quiz_id_q);
$quiz_id = $quiz_id_detail['quiz_id'];

//Students information
$students_q = mysqli_query($con,"SELECT * FROM `students` WHERE `class`='$course_class' ORDER BY `rollno` ASC");
while($students_details = mysqli_fetch_assoc($students_q)){
    $students_array[] = $students_details['student_id'];
}
//print_r($students_array);
//Fetch results Query
$quiz_results_q = mysqli_query($con, "SELECT * FROM `quiz` JOIN `students` ON `quiz`.`class`=`students`.`class` JOIN `result` ON `quiz`.`quiz_id` = `result`.`quiz_id` AND `result`.`student_id` = `students`.`student_id` WHERE `quiz`.`subject`='$course_id' AND `quiz`.`quiz_created_by`='$teacher_id' AND `quiz`.`class`='$course_class' AND `quiz`.`topic`='$topic' AND `quiz`.`status`=3 AND `quiz`.`result_status`=1 ORDER BY `rollno` ASC");
$total_quizzes = mysqli_num_rows($quiz_results_q);
if ($total_quizzes>0) {
?>
    <h3 class="text-center text-danger">Topic: <?php echo $topic; ?></h3>
    <div class="content table-responsive">
        <table class="table table-hover table-bordered table-striped">
            <thead>
                <th>Sr #</th>
                <th>Student Rollno</th>
            	<th>Student Name</th>
                <th>Quiz Date</th>
                <th>Quiz Total Marks</th>
                <th>Obtained Marks</th>
                <th>Preview Quiz</th>
            </thead>
            <tbody>
                <?php 
                $i = 1;
                while($quiz_details = mysqli_fetch_assoc($quiz_results_q)):
                ?>
    	            <tr>
    	            	<td><?php echo $i;?></td>
    	            	<td><?php echo $quiz_details['rollno'];?></td>
    	            	<td><?php echo $quiz_details['name']; ?></td>
    	            	<td><?php echo $quiz_details['schedule']; ?></td>
                        <td><?php echo $quiz_details['total_marks']; ?></td>
                        <td><?php echo $quiz_details['obtained_marks']; ?></td>
                        <!-- Preview paper -->
    	                <td><a href="student-answer-sheet.php?quiz_id=<?=$quiz_details['quiz_id'];?>&student_id=<?=$quiz_details['student_id'];?>" class="text-primary"><i class="fa fa-eye fa-2x"></i></a></td>
    	            </tr>
                <?php 
                $i++;
                endwhile; 
                ?>
            </tbody>
            <tfoot>
                <th>Sr #</th>
                <th>Student Rollno</th>
                <th>Student Name</th>
                <th>Quiz Date</th>
                <th>Quiz Total Marks</th>
                <th>Obtained Marks</th>
                <th>Preview Quiz</th>
            </tfoot>
        </table>
        <br><hr>
        <h3 class="text-danger text-center">Students Who Missed the quiz / Not appeared in the quiz</h3>
        <hr>
        <table class="table table-hover table-bordered table-striped">
            <thead>
                <th>Sr #</th>
                <th>Student Rollno</th>
                <th>Student Name</th>
                <th>Obtained Marks</th>
            </thead>
            <tbody>
                <?php 
                $q = 1;
                $missed_students = mysqli_query($con, "SELECT * FROM `students` WHERE `students`.`student_id` NOT IN (SELECT `student_id` FROM `result` WHERE `quiz_id`='$quiz_id') AND `students`.`class`='$course_class'");
                $total_missed = mysqli_num_rows($missed_students);
                if($total_missed > 0){    
                    while($missed_students_details = mysqli_fetch_assoc($missed_students)){
                    ?>
                    <tr>
                        <td><?php echo $q;?></td>
                        <td><?php echo $missed_students_details['rollno'];?></td>
                        <td><?php echo $missed_students_details['name']; ?></td>
                        <td>0</td>
                    </tr>
                    <?php
                    $q++;
                    }
                }else{
                    echo '<h3 class="text-danger text-center">All Students Have Taken the Quiz</h3>';      
                }
                ?>
            </tbody>
            <tfoot>
                <th>Sr #</th>
                <th>Student Rollno</th>
                <th>Student Name</th>
                <th>Obtained Marks</th>
            </tfoot>
        </table>
    </div>
<?php
}else{
    echo '<h3 class="text-danger text-center">No quizzes results for this query till now.</h3>';
}
?>