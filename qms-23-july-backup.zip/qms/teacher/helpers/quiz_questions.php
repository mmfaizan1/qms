<?php session_start();
include('../includes/connection.php');

$teacher_id = $_SESSION['teacher_id'];

$quiz_id = $_POST['quiz_id'];
$course_id = $_POST['course_id'];

$quiz_questions_q = "SELECT * FROM `question_paper` JOIN `questions` ON `question_paper`.`paper_question`=`questions`.`question_id` JOIN `question_types` ON `questions`.`question_type`=`question_types`.`type_id` JOIN `quiz` ON `question_paper`.`quiz`=`quiz`.`quiz_id` WHERE `question_paper`.`quiz`='$quiz_id' ORDER BY `question_types`.`type_id` ASC";
$quiz_questions_qR = mysqli_query($con, $quiz_questions_q);
$total_questions = mysqli_num_rows($quiz_questions_qR);
//$quiz_detail = mysqli_fetch_assoc($quiz_questions_qR);
if($total_questions>0):
?>
<hr><h2 class="text-center text-danger">Quiz Questions</h2>
	<div class="content table-responsive">
		<table class="table table-hover table-striped table-bordered">
			<thead>
				<th class="col-sm-1">Select questions</th>
				<th class="col-sm-1">Question Type</th>
				<th class="col-sm-6">Question</th>
				<th class="col-sm-1">Edit</th>
			</thead>
			<tbody>
				<?php while($questions = mysqli_fetch_assoc($quiz_questions_qR)): ?>
				<tr>
					<td class="col-sm-1"><input type="checkbox" id="question_checkbox" value="<?=$questions['question_id'];?>"></td>
					<td class="col-sm-1"><?php echo $questions['type'];?></td>
					<td class="col-sm-6"><?php echo $questions['question'];?></td>
					<td class="col-sm-1"><a href="edit-quiz-question.php?question_id=<?=$questions['question_id'];?>&quiz_id=<?=$quiz_id;?>" class="text-warning"><i class="fa fa-pencil-square-o fa-2x"></i></a></td>
				</tr>
				<?php endwhile; ?>
			</tbody>
			<tfoot>
				<th class="col-sm-1">Select questions</th>
				<th class="col-sm-1">Question Type</th>
				<th class="col-sm-6">Question</th>
				<th class="col-sm-1">Edit</th>				
			</tfoot>
		</table>
		<div class="row">
			<div class="col-sm-4"></div>
			<div class="col-sm-4">
				<div class="form-group">
					<button type="button" class="btn btn-warning btn-fill form-control" id="view-question">View Questions <i class="fa fa-eye"></i></button>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="form-group">
					<button type="button" class="btn btn-danger btn-fill form-control" id="delete-questions">Delete Questions <i class="fa fa-trash-o"></i></button>
				</div>
			</div>
		</div>	
	</div>

<?php 
else:
	echo "<h1 class='text-danger text-center'>There are Questions added in this quiz. Go and add some</h1>";
endif; ?>
<script type="text/javascript" src="assets/js/custom.js"></script>