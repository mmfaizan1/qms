<?php session_start();
include('../includes/connection.php');
$teacher_id = $_SESSION['teacher_id'];


$course_class = $_POST['course_class'];
$course_id = $_POST['course_id'];

$quiz_details_Q = "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject` = `courses`.`course_id` WHERE `quiz`.`quiz_created_by` = '$teacher_id' AND `quiz`.`class` = '$course_class' AND `quiz`.`subject` ='$course_id' AND `quiz`.`status`=1";
$quiz_details_QR = mysqli_query($con, $quiz_details_Q);
$total_quizzes = mysqli_num_rows($quiz_details_QR);
if($total_quizzes > 0):
?>
	<div class="content table-responsive">
	    <table class="table table-hover table-bordered table-striped">
	        <thead>
	            <th>Sr #</th>
	        	<th>Course Code</th>
	        	<th>Subject</th>
	            <th>Topic</th>
	            <th>Quiz Date</th>
	            <th>Quiz Time</th>
	            <th>Preview Quiz</th>
	            <th>Add Questions</th>
	        	<th>Take Quiz</th>
	        	<th>Postpone Quiz</th>
	        	<th>Edit Quiz</th>
	            <th>Delete</th>
	        </thead>
	        <tbody>
	            <?php 
	            $i = 1;
	            while($quiz_details = mysqli_fetch_assoc($quiz_details_QR)):
	            ?>
		            <tr>
		            	<td><?php echo $i;?></td>
		            	<td><?php echo $quiz_details['course_code'];?></td>
		            	<td><?php echo $quiz_details['course'];?></td>
		            	<td><?php echo $quiz_details['topic']; ?></td>
		            	<td><?php echo date("d-m-Y",strtotime($quiz_details['schedule'])); ?></td>
		            	<td><?php echo date("h:i A",strtotime($quiz_details['start_time'])); ?></td>
		            	<!-- Preview paper -->
		                <td><a href="preview-quiz.php?quiz_id=<?=$quiz_details['quiz_id'];?>" class="text-primary"><i class="fa fa-eye fa-2x"></i></a></td>
		                <!-- Add Questions -->
		                <td><a href="add-questions.php?quiz_id=<?=$quiz_details['quiz_id'];?>&course_id=<?=$quiz_details['subject'];?>" class="text-info"><i class="fa fa-plus-circle fa-2x"></i></a></td>
		                <!-- Take Quiz -->
		                <td><a href="start-quiz.php?quiz_id=<?=$quiz_details['quiz_id'];?>&class_id=<?=$quiz_details['class'];?>" class="text-success"><i class="fa fa-check-circle fa-2x"></i></a></td>
		            	<!-- postpone Quiz -->
		            	<td><a href="quizzes.php?quiz_id=<?=$quiz_details['quiz_id'];?>&action=postpone" class="text-light"><i class="fa fa-pause fa-2x"></i></a></td>
		            	<!-- edit quiz -->
		            	<td><a href="edit-quiz.php?quiz_id=<?=$quiz_details['quiz_id'];?>" class="text-warning"><i class="fa fa-pencil-square-o fa-2x"></i></a></td>
		                <!-- Delete Quiz -->
		                <td><a href="quizzes.php?quiz_id=<?=$quiz_details['quiz_id'];?>&action=delete" class="text-danger"><i class="fa fa-trash-o fa-2x"></i></a></td>
		            </tr>
	            <?php 
	            $i++;
	            endwhile; 
	            ?>
	        </tbody>
	        <tfoot>
	            <th>#</th>
	            <th>Course Code</th>
	            <th>Subject</th>
	            <th>Topic</th>
	            <th>Quiz Date</th>
	            <th>Quiz Time</th>
	            <th>Preview Quiz</th>
	            <th>Add Questions</th>
	            <th>Take Quiz</th>
	            <th>Postpone Quiz</th>
	            <th>Edit</th>
	            <th>Delete</th>
	        </tfoot>
	    </table>
	</div>
<?php 
	else:
		echo "<h1 class='text-danger text-center'>There are no quizzes to be taken related to this course and class at the moment</h1>";
endif;
?>