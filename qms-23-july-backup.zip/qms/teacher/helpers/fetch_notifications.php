<?php session_start();
include('../includes/connection.php');

$teacher_id = $_SESSION['teacher_id'];
$notification_q = mysqli_query($con, "SELECT * FROM `notifications` WHERE `notification_for`='teacher' AND `id`='$teacher_id' ORDER BY `notification_id` DESC");
$total_notifications = mysqli_num_rows($notification_q);
if ($total_notifications > 0) {
    ?>
    <div class="content">
    <?php
    while($notification = mysqli_fetch_assoc($notification_q)){
        $severity  = $notification['severity'];
        $time = strtotime($notification['time']);
        $date = date("d-m-Y" , $time);
        $time = date("h:i:s a" , $time);
?>
            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-<?php if($severity == 1){echo "info";}elseif($severity == 2){echo "warning";}elseif($severity==3){echo "danger";}?> alert-with-icon" data-notify="container">
                        <span><h3><?php echo $notification['title']; ?> (From: <?php echo $notification['notification_by']; ?> - Dated: <?php echo $date.' '. $time; ?>)</h3></span>
                        <span data-notify="icon" class="pe-7s-bell"></span>
                        <span data-notify="message"><?php echo $notification['description']; ?></span>
                    </div>
                </div>
            </div>
<?php
    }
    ?>
    </div>
    <?php
}else{
    ?>
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <h3 class=" text-primary text-center">No Notification Till now.</h3>
            </div>
        </div>
    </div>
    <?php
}
?>
