<?php session_start();

include('../includes/connection.php');

$teacher_id = $_SESSION['teacher_id'];

$course_id = $_POST['course_id'];

$quiz_sql = "SELECT * FROM `quiz` JOIN `class` ON `quiz`.`class`=`class`.`class_id` JOIN `degree` ON `class`.`degree`=`degree`.`degree_id` WHERE `quiz`.`subject`='$course_id' AND `quiz`.`quiz_created_by`='$teacher_id' AND `quiz`.`status`=1";
$quiz_sql_R = mysqli_query($con, $quiz_sql);
$total_quizzes = mysqli_num_rows($quiz_sql_R);
if ($total_quizzes>0):
?>

	<option value="">Select Quiz</option>
	<?php
	while ($subject_quizzes = mysqli_fetch_assoc($quiz_sql_R)) {
		$quiz_id = $subject_quizzes['quiz_id'];
		$class_name = $subject_quizzes['degree_name'];
		$class_name .= "-". $subject_quizzes['semester'];
		$topic = $subject_quizzes['topic'];
		?>
		<option value="<?php echo $quiz_id;?>"><?php echo $topic." (".$class_name.")"; ?></option>
		<?php
	}

else:
	?>
	<option value="">No quizzes Related to this subject Right Now</option>
	<?php
endif;
?>