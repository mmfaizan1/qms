




    <hr><h2 class="text-center text-danger">Question Type: Fill in the Blanks</h2>
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label>Question</label>
                <input type="text" class="form-control">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="form-group">
                <label>Correct Answer</label>
                <input type="text" class="form-control">
            </div>
        </div>
    </div>
    <div class="form-group">
        <button type="submit" class="btn btn-info btn-fill btn-wd">Add Question</button>
    </div>