<?php session_start();
include('../includes/connection.php');


$teacher_id = $_SESSION['teacher_id'];
$course_id = $_POST['course_id'];
$course_class = $_POST['course_class'];
$quiz_topic = mysqli_query($con, "SELECT * FROM `quiz` WHERE `subject`='$course_id' AND `quiz_created_by`='$teacher_id' AND `class`='$course_class' AND `status`=3 AND `result_status`=1");

$total_quizzes = mysqli_num_rows($quiz_topic);
	if($total_quizzes == 0){
		echo'<option value="">No Quiz Till Now.</option>';	
	}else{
		?>
		<option value="">Select Topic</option>
		<?php
		while($quiz = mysqli_fetch_assoc($quiz_topic)){
			?>
			<option value="<?= $quiz['topic'];?> "> <?php echo $quiz['topic']; ?> </option>
			<?php	
		}
	}
?>