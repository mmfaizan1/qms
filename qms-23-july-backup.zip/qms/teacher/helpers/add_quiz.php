<?php session_start();
include('../includes/connection.php');


$teacher_id = $_SESSION['teacher_id'];
//echo "response";
if (isset($_POST['add_quiz'])) {
	$course = $_POST['course'];
	$course_class = $_POST['course_class'];
	$topic_name = $_POST['topic_name'];
	$quiz_date = $_POST['quiz_date'];
	$questions_marks = $_POST['question_marks'];
	// echo "<br>".$quiz_date;//$quiz_date = date($quiz_date);
	// echo "<br>".date("Y-m-d");echo"<br>";
	$quiz_date_converted = strtotime($quiz_date);
	$today_date = strtotime(date("Y-m-d"));
	$date_diff  = $quiz_date_converted - $today_date;

	$quiz_start_time = $_POST['start_time'];
	$quiz_end_time = $_POST['end_time'];
	$start_time = strtotime($_POST['start_time']);
	$end_time = strtotime($_POST['end_time']);
	$difference = $end_time - $start_time;
	$duration = gmdate("H:i:s", $difference);
	
	//For notifications
	$course_q = mysqli_query($con, "SELECT * FROM `courses` WHERE `course_id`='$course' ");
	$teacher_q = mysqli_query($con, "SELECT * FROM `teachers` WHERE `teacher_id`='$teacher_id' ");
	$course_details = mysqli_fetch_assoc($course_q);
	$course_name = $course_details['course'];
	$course_code = $course_details['course_code'];
	$teacher_details = mysqli_fetch_assoc($teacher_q);
	$teacher_name = $teacher_details['name'];
	
	$q_start_time = strtotime($quiz_start_time);
	$q_end_time = strtotime($quiz_end_time);
	$q_start_time = date("h:i A", $q_start_time);
	$q_end_time = date("h:i A", $q_end_time);
	//validations
	if($start_time == $end_time){
		echo "<div class='alert alert-danger'><h3 class='text-center'>Start and End Time cannot be the same.</h3></div>";
	}else if($date_diff < 0){
		echo "<div class='alert alert-danger'><h3 class='text-center'>Error! Invalid date. The date you have selected has been passed</h3></div>";
	}else if($difference < 0){
		echo "<div class='alert alert-danger'><h3 class='text-center'>Error! Invalid start and end time. End time must not be before the Start time</h3></div>";
	}else{
		$add_quiz_sql = "INSERT INTO `quiz` (`subject`,`topic`, `questions_marks`,`quiz_created_on`,`quiz_created_by`,`schedule`,`duration`,`start_time`, `end_time`,`class`,`status`) VALUES ('$course','$topic_name', '$questions_marks',now(),'$teacher_id','$quiz_date','$duration','$quiz_start_time','$quiz_end_time','$course_class','1')";
		$add_quiz_sql = mysqli_query($con, $add_quiz_sql);
		
		//Notify Query
		$notify_q = mysqli_query($con, "INSERT INTO `notifications` (`title`, `description`, `time`, `notification_by`,`notification_for`,`severity`,`id`) VALUES ('New Quiz Added','Welcome Dear Student. A new quiz have been added by $teacher_name which is scheduled on $quiz_date from $q_start_time to $q_end_time. The course is $course_code - $course_name. The Topic of quiz is $topic_name', now(), 'teacher','class','1','$course_class')");
		
		if ($add_quiz_sql && $notify_q) {
			echo "<div class='alert alert-success'><h3 class='text-center'>Quiz Added Successfully</h3></div>";
			?>
			<script>
				$("#add-quiz-form")[0].reset();
			</script>
			<?php
		}else{
			echo "<div class='alert alert-danger'><h3 class='text-center'>Error! Unable to add quiz</h3></div>";
		}
	}
}
?>