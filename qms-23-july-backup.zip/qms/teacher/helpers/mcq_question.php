



    <hr><h2 class="text-center text-danger">Question Type: MCQ</h2>
    <div class="row">
        <!-- Question Type MCQ -->
        <div class="col-md-12">
            <div class="form-group">
                <label>Question</label>
                <input type="text" class="form-control" required id="mcq_question">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label>Option 1</label>
                <input type="text" class="form-control"required id="option_1">
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Option 2</label>
                <input type="text" class="form-control" required id="option_2">
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Option 3</label>
                <input type="text" class="form-control" required id="option_3">
            </div>
        </div>
        <div class="col-md-3">
            <div class="form-group">
                <label>Option 4</label>
                <input type="text" class="form-control" required id="option_4">
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <div class="form-group">
                <label>Correct Answer</label>
                <input type="text" class="form-control" required id="correct_option">
            </div>
        </div>
    </div>
    <div class="form-group">
        <button type="button" class="btn btn-info btn-fill btn-wd" id="add_mcq_question" value="add_mcq_question">Add Question</button>
    </div>
    <script type="text/javascript" src="assets/js/custom.js"></script>