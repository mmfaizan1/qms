<?php 

include('../includes/connection.php');
 
$course_id = $_POST['course_id'];
$classes_sql_q = "SELECT * FROM `class_courses` JOIN `class` ON `class_courses`.`course_class_id` = `class`.`class_id` JOIN `degree` ON `class`.`degree` = `degree`.`degree_id` WHERE `class_courses`.`course_id` = '$course_id'";
$classes_sql_qR = mysqli_query($con, $classes_sql_q);
?>
<option value="">Select Class</option>
<?php
while ($classes = mysqli_fetch_assoc($classes_sql_qR)) {
	$class_id = $classes['class_id'];
	$class_name = $classes['degree_name'];
	$class_name .= "-". $classes['semester'];
	?>
	<option value="<?php echo $class_id;?>"><?php echo $class_name; ?></option>
	<?php
}

//echo "Hello World"; 

?>