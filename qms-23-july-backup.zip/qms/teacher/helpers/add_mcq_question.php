<?php
include('../includes/connection.php');


if (isset($_POST['submit'])) {
	$question_type = 1;
	$quiz_id = $_POST['quiz_id'];
	$course_id = $_POST['course_id'];
	$mcq_question = trim($_POST['mcq_question']);
	$option1 = trim($_POST['option1']);
	$option2 = trim($_POST['option2']);
	$option3 = trim($_POST['option3']);
	$option4 = trim($_POST['option4']);
	$correct = trim($_POST['correct']);
	//checking if question exists or not
	$question_from_db = "SELECT `question` FROM `questions`";
	$question_from_dbR = mysqli_query($con, $question_from_db);
	while($result = mysqli_fetch_assoc($question_from_dbR)):
		$question = $result['question'];
		//for case insensitiveness comparison
		if (strcasecmp($question, $mcq_question) == 0) {
			echo "<div class='alert alert-danger'><h4 class='text-center'>Question Already exists... To add this choose it from existing</h4></div>";
			die();
		}
	endwhile;
	//add question in questions table
	$add_mcq_question_q = mysqli_query($con, "INSERT INTO `questions` (`course`,`question_type`,`question`) VALUES ('$course_id','$question_type','$mcq_question')");
	$question_inserted_id = mysqli_insert_id($con);
	//insert mcqs options
	$add_options_q = mysqli_query($con, "INSERT INTO `mcq_options` (`mcq_question_id`,`option_1`,`option_2`,`option_3`,`option_4`) VALUES ('$question_inserted_id','$option1','$option2','$option3','$option4')");
	//insert correct answer
	$correct_option_q = mysqli_query($con, "INSERT INTO `solution` (`solution_question_id`,`solution`) VALUES ('$question_inserted_id','$correct')");
	//add into question paper
	$question_paper_q = mysqli_query($con, "INSERT INTO `question_paper` (`quiz`,`paper_question`) VALUES ('$quiz_id',$question_inserted_id)");
	if ($add_mcq_question_q && $add_options_q && $correct_option_q && $question_paper_q){
			echo "<div class='alert alert-success'><h4 class='text-center'>Mcq Question Added Successfully</h4></div>";
		?>
		<script>
			$("#questions-form")[0].reset();
		</script>
		<?php
	}
	//echo "<div class='alert alert-success'><h1 class='text-center'>Question added successfully</h1></div>";
}
?>