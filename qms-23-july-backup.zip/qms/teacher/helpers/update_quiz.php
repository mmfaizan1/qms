<?php session_start();
include('../includes/connection.php');


$teacher_id = $_SESSION['teacher_id'];
//echo "response";
if (isset($_POST['update_quiz'])) {
	$quiz_id = $_POST['quiz_id'];
	$course = $_POST['course'];
	$course_class = $_POST['course_class'];
	$topic_name = $_POST['topic_name'];
	$quiz_date = $_POST['quiz_date'];
	$questions_marks = $_POST['question_marks'];
	// echo "<br>".$quiz_date;//$quiz_date = date($quiz_date);
	// echo "<br>".date("Y-m-d");echo"<br>";
	$quiz_date_converted = strtotime($quiz_date);
	$today_date = strtotime(date("Y-m-d"));
	$date_diff  = $quiz_date_converted - $today_date;

	$quiz_start_time = $_POST['start_time'];
	$quiz_end_time = $_POST['end_time'];
	
	$start_time = strtotime($_POST['start_time']);
	$end_time = strtotime($_POST['end_time']);
	$difference = $end_time - $start_time;
	$duration = gmdate("H:i:s", $difference);
	//For notifications
	$course_q = mysqli_query($con, "SELECT * FROM `courses` WHERE `course_id`='$course' ");
	$teacher_q = mysqli_query($con, "SELECT * FROM `teachers` WHERE `teacher_id`='$teacher_id' ");
	$course_details = mysqli_fetch_assoc($course_q);
	$course_name = $course_details['course'];
	$course_code = $course_details['course_code'];
	$teacher_details = mysqli_fetch_assoc($teacher_q);
	$teacher_name = $teacher_details['name'];
	
	$q_start_time = strtotime($quiz_start_time);
	$q_end_time = strtotime($quiz_end_time);
	$q_start_time = date("h:i A", $q_start_time);
	$q_end_time = date("h:i A", $q_end_time);
	
	//validations
	if($start_time == $end_time){
		echo "<div class='alert alert-danger'><h3 class='text-center'>Start and End Time cannot be the same.</h3></div>";
	}else if($date_diff < 0){
		echo "<div class='alert alert-danger'><h3 class='text-center'>Error! Invalid date. The date you have selected has been passed</h3></div>";
	}else if($difference < 0){
		echo "<div class='alert alert-danger'><h3 class='text-center'>Error! Invalid start and end time. End time must not be before the Start time</h3></div>";
	}else{
		$add_quiz_sql = "UPDATE `quiz` SET `subject`='$course',`topic`='$topic_name', `questions_marks`='$questions_marks',`quiz_created_on`=now(),`quiz_created_by`='$teacher_id',`schedule`='$quiz_date',`duration`='$duration',`start_time`='$quiz_start_time', `end_time`='$quiz_end_time',`class`='$course_class',`status`=1 WHERE `quiz_id`='$quiz_id'";
		$add_quiz_sql = mysqli_query($con, $add_quiz_sql);
		
		//Notify Query
		$notify_q = mysqli_query($con, "INSERT INTO `notifications` (`title`, `description`, `time`, `notification_by`,`notification_for`,`severity`,`id`) VALUES ('Quiz Details Updated','Welcome Dear Student. A quiz details have been added by $teacher_name which is now scheduled on $quiz_date from $q_start_time to $q_end_time and the course is $course_code - $course_name. The Topic of quiz is $topic_name', now(), 'teacher','class','1','$course_class')");

		if ($add_quiz_sql && $notify_q) {
			echo "<div class='alert alert-success'><h3 class='text-center'>Quiz Updated Successfully... Redirecting back to quizzes Page.</h3></div>";
			?>
			<script>
				$("#update-quiz-form")[0].reset();
				setTimeout(function() {
				  window.location.href = "quizzes.php";
				}, 5000);
			</script>
			<?php
		}else{
			echo "<div class='alert alert-danger'><h3 class='text-center'>Error! Unable to update quiz</h3></div>";
		}
	}
}
?>