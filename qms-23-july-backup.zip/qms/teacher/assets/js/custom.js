

//Teacher login form validation
$(document).ready(function(){
  //Disable Inspect Element and reload keys starts
  //f12 key
  $(document).keydown(function(e){
      if(e.which === 123){
   
         return false;
   
      }
   
  });
  //Disable Right Click 
  // document.addEventListener('contextmenu', function(e) {
  //   e.preventDefault();
  // });
  //disble ctrl+shift+c, ctrl+shift+j, ctrl+shift+i and ctrl+u
  $(document).keydown(function (event) {
    if ((event.ctrlKey && event.shiftKey && event.keyCode == 73) || (event.ctrlKey && event.shiftKey && event.keyCode == 74) || (event.ctrlKey && event.shiftKey && event.keyCode == 67) || (event.ctrlKey && event.keyCode == 85)) {
        return false;
    }
  });
  //Disable inspect element and reload keys ends

  //Teachers login page
  $('#login').click(function(){
    var email = $('#email').val();
    var password = $('#password').val();
    var login = $('#login').val();
    var dataString = 'email='+email + '&password='+password + '&login='+login;
    function ValidateEmail(email) {
        var expr = /^(?!_)([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return expr.test(email);
    };
    if (email == '' || password == '') {
      $("#status_message").addClass("alert");
      $("#status_message").addClass("alert-danger");
      $("#status_message").css("color","red");
      $("#status_message").html('ATTENTION! Fill in all the required Fields');
    }else if (!ValidateEmail(email)) {
      $("#status_message").addClass("alert");
      $("#status_message").addClass("alert-danger");
      $("#status_message").css("color","red");
      $("#status_message").html('ATTENTION! Invalid Email Address. Correct format "abc@gmail.com"');
    }else{
      $.ajax({
        type: 'POST',
        url: 'teacher-auth.php',
        data: dataString,
        cache: false,
        success: function(result){
          $("#status_message").html(result);
        }
      });
    }
  });

  //Fetch course classes
  $('#courses').change(function(){
    var course_id = $('#courses').val();
    var dataString = 'course_id='+course_id;
    $.ajax({
        type: 'POST',
        url: 'helpers/course_classes.php',
        data: dataString,
        cache: false,
        success: function(result){
          //alert(result);
          $('#course_class').html(result);
        }
    });
  });
  //Fetch unattended quiz details
  $('#course_class').change(function(){
    var course_class = $('#course_class').val();
    var course_id = $('#courses option:selected').val();
    var dataString = 'course_class='+course_class+'&course_id='+course_id;
    $.ajax({
        type: 'POST',
        url: 'helpers/class_quizzes.php',
        data: dataString,
        cache: false,
        success: function(result){
          $('#quiz-data').html(result);
        }
    });
  });
  //add quiz ajax call and response
  $('#add-quiz').click(function(){
    var course = $('#courses').val();
    var course_class = $('#course_class').val();
    var topic_name = $('#topic_name').val();
    var quiz_date = $('#quiz_date').val();
    var start_time = $('#quiz_start_time').val();
    var end_time = $('#quiz_end_time').val();
    var add_quiz = $('#add-quiz').val();
    var question_marks = $('#question_marks option:selected').val();
    var dataString = "course="+course+"&course_class="+course_class+"&topic_name="+topic_name+"&start_time="+start_time+"&end_time="+end_time+"&add_quiz="+add_quiz+"&quiz_date="+quiz_date+"&question_marks="+question_marks;
    // alert(course);
    // alert(course_class);
    // alert(topic_name);
    // alert(quiz_date);
    // alert(start_time);
    // alert(end_time);
    //alert(question_marks);
    if (course == '' || course_class == '' || topic_name == '' || start_time == '' || end_time == '' || question_marks == '') {
      $("#status_message").addClass("alert");
      $("#status_message").addClass("alert-danger");
      $("#status_message").addClass("text-center");
      $("#status_message").css("color","#fff");
      $("#status_message").html('<h3>ATTENTION! Fill in all the required Fields</h3>');

    }else{
      $.ajax({
          type: 'POST',
          url: 'helpers/add_quiz.php',
          data: dataString,
          cache: false,
          success: function(result){
            console.log(result);
            //alert(result);
            $('#status_message').html(result);
          }
      });
    }
  });
  //Question type template picker
  $('#question_type').change(function(){
    var question_type = $('#question_type').val();
    var quiz_id = $('#quiz_id').val();
    var course_id = $('#course_id').val();
    var dataString = 'question_type='+question_type+'&quiz_id='+quiz_id+'&course_id='+course_id;
    var url;
    // alert(dataString);
    //alert(question_type);
    if (question_type == 'MCQ') {
      url = 'helpers/mcq_question.php';
    }else if (question_type == 'FIB') {
      url = 'helpers/fib_question.php';
    }else if(question_type == 'SQ'){
      url = 'helpers/sq_question.php';
    }else if (question_type == 'existing') {
      url = 'helpers/existing_questions.php';
    }
    $.ajax({
      type: 'POST',
      url: url,
      data: dataString,
      cache: false,
      success: function(result){
        $('#question_template').html(result);
      }
    });
  });
  //add mcqs quiz question
  $('#add_mcq_question').click(function(){
    var quiz_id = $('#quiz_id').val();
    var course_id = $('#course_id').val();
    var question = $('#mcq_question').val();
    var option1 = $('#option_1').val();
    var option2 = $('#option_2').val();
    var option3 = $('#option_3').val();
    var option4 = $('#option_4').val();
    var correct = $('#correct_option').val();
    var submit = $('#add_mcq_question').val();
    var dataString = 'quiz_id='+quiz_id+'&course_id='+course_id+'&mcq_question='+question+'&option1='+option1+'&option2='+option2+'&option3='+option3+'&option4='+option4+'&correct='+correct+'&submit='+submit;
    // alert(quiz_id);
    // alert(course_id);
    if (question == '' || option1 == '' || option2 == ''|| option3 == ''|| option4 == '' || correct =='') {
      $("#status_message").addClass("alert");
      $("#status_message").addClass("alert-danger");
      $("#status_message").addClass("text-center");
      $("#status_message").css("color","#fff");
      $("#status_message").html('<h3>ATTENTION! Fill in all the required Fields</h3>');
    }else{
      $.ajax({
        type: 'POST',
        url: 'helpers/add_mcq_question.php',
        data: dataString,
        cache: false,
        success: function(result){
          $('#status_message').html(result);
        }
      }); 
    }
  });
  //add existing questions
  $('#add_existing_questions').click(function(){
    var quiz_id = $('#quiz_id').val();
    var course_id = $('#course_id').val();
    var submit = $('#add_existing_questions').val();
    //getting values of multiple checkboxes
    var existing_questions = new Array();
    $('#existing_question_checkbox:checked').each(function() {
      existing_questions.push(this.value);
    });
    var dataString = 'quiz_id='+quiz_id+'&course_id='+course_id+"&existing_questions="+existing_questions+"&submit="+submit;
    if(existing_questions == ''){
      $("#status_message").addClass("alert");
      $("#status_message").addClass("alert-danger");
      $("#status_message").addClass("text-center");
      $("#status_message").css("color","#fff");
      $("#status_message").html('<h3>ATTENTION! Select atleast one question to continue</h3>');
    }else{
      $.ajax({
        type: 'POST',
        url: 'helpers/add_existing_question.php',
        data: dataString,
        cache: false,
        success: function(result){
          $('#status_message').html(result);
        }
      }); 
    }
    // alert(existing_questions);
  });
  //edit quiz
  $('#update-quiz').click(function(){
    var quiz_id = $('#quiz_id').val();
    var course = $('#courses').val();
    var course_class = $('#course_class').val();
    var topic_name = $('#topic_name').val();
    var quiz_date = $('#quiz_date').val();
    var start_time = $('#quiz_start_time').val();
    var end_time = $('#quiz_end_time').val();
    var update_quiz = $('#update-quiz').val();
    var question_marks = $('#question_marks option:selected').val();
    var dataString = "quiz_id="+quiz_id+"&course="+course+"&course_class="+course_class+"&topic_name="+topic_name+"&start_time="+start_time+"&end_time="+end_time+"&update_quiz="+update_quiz+"&quiz_date="+quiz_date+"&question_marks="+question_marks;
    // alert(course);
    // alert(course_class);
    // alert(topic_name);
    // alert(quiz_date);
    // alert(start_time);
    // alert(end_time);
    //alert(question_marks);
    if (course == '' || course_class == '' || topic_name == '' || start_time == '' || end_time == '' || question_marks == '') {
      $("#status_message").addClass("alert");
      $("#status_message").addClass("alert-danger");
      $("#status_message").addClass("text-center");
      $("#status_message").css("color","#fff");
      $("#status_message").html('<h3>ATTENTION! Fill in all the required Fields</h3>');

    }else{
      $.ajax({
          type: 'POST',
          url: 'helpers/update_quiz.php',
          data: dataString,
          cache: false,
          success: function(result){
            //console.log(result);
            //alert(result);
            $('#status_message').html(result);
          }
      });
    }
  });
  //Fetch course_quiz
  $('#quiz-courses').change(function(){
    var course_id = $('#quiz-courses option:selected').val();

    var dataString = "course_id="+course_id;
    $.ajax({
          type: 'POST',
          url: 'helpers/course_quiz.php',
          data: dataString,
          cache: false,
          success: function(result){
            //console.log(result);
            //alert(result);
            $('#course-quiz').html(result);
          }
    });
  });
  //Select Quiz Questions
  $('#course-quiz').change(function(){
    var quiz_id = $('#course-quiz').val();
    var course_id = $('#quiz-courses option:selected').val();
    var dataString = "quiz_id="+quiz_id+'&course_id='+course_id;
    $.ajax({
          type: 'POST',
          url: 'helpers/quiz_questions.php',
          data: dataString,
          cache: false,
          success: function(result){
            //console.log(result);
            //alert(result);
            $('#quiz-questions').html(result);
          }
    });
  });
  //View multiple quiz Questions
  $('#view-question').click(function(){
    var quiz_id = $('#course-quiz').val();
    var submit = $('#view-question').val();
    //getting values of multiple checkboxes
    var questions_array = new Array();
    $('#question_checkbox:checked').each(function() {
      questions_array.push(this.value);
    });
    var dataString = 'quiz_id='+quiz_id+'&questions_array='+questions_array+'&submit='+submit;
    if(questions_array == ''){
      $("#status_message").addClass("alert");
      $("#status_message").addClass("alert-danger");
      $("#status_message").addClass("text-center");
      $("#status_message").css("color","#fff");
      $("#status_message").html('<h3>ATTENTION! Select atleast one question to see results</h3>');
    }else{
      $.ajax({
        type: 'POST',
        url: 'helpers/view_quiz_question.php',
        data: dataString,
        cache: false,
        success: function(result){
          $('#quiz-questions').html(result);
        }
      }); 
    }
  });
  //delete multiple quiz questions
  $('#delete-questions').click(function(){
    var quiz_id = $('#course-quiz').val();
    var submit = $('#delete-questions').val();
    //getting values of multiple checkboxes
    var questions_array = new Array();
    $('#question_checkbox:checked').each(function() {
      questions_array.push(this.value);
    });
    var dataString = 'quiz_id='+quiz_id+'&questions_array='+questions_array+'&submit='+submit;
    if(questions_array == ''){
      $("#status_message").addClass("alert");
      $("#status_message").addClass("alert-danger");
      $("#status_message").addClass("text-center");
      $("#status_message").css("color","#fff");
      $("#status_message").html('<h3>ATTENTION! Select atleast one question to delete</h3>');
    }else{
      $.ajax({
        type: 'POST',
        url: 'helpers/delete_quiz_question.php',
        data: dataString,
        cache: false,
        success: function(result){
          $('#quiz-questions').html(result);
        }
      }); 
    }
  });
  //Edit Quiz Questions
  $('#edit-quiz-question').click(function(){
    var quiz_id = $('#quiz_id').val();
    var question = $('#mcq_question').val();
    var option1 = $('#option_1').val();
    var option2 = $('#option_2').val();
    var option3 = $('#option_3').val();
    var option4 = $('#option_4').val();
    var correct = $('#correct_option').val();
    var question_id = $('#edit_question_id').val();
    var submit = $('#edit-quiz-question').val();
    var dataString = 'question_id='+question_id+'&mcq_question='+question+'&option1='+option1+'&option2='+option2+'&option3='+option3+'&option4='+option4+'&correct='+correct+'&submit='+submit;
    // alert(quiz_id);
    // alert(course_id);
    if (question == '' || option1 == '' || option2 == ''|| option3 == ''|| option4 == '' || correct =='') {
      $("#status_message").addClass("alert");
      $("#status_message").addClass("alert-danger");
      $("#status_message").addClass("text-center");
      $("#status_message").css("color","#fff");
      $("#status_message").html('<h3>ATTENTION! Fill in all the required Fields</h3>');
    }else{
      $.ajax({
        type: 'POST',
        url: 'helpers/update_mcq_question.php',
        data: dataString,
        cache: false,
        success: function(result){
          $('#status_message').html(result);
        }
      }); 
    }
  });
  /*Results*/
  //Fetch quiz class details
  $('.r_courses').change(function(){
    var course_id = $('.r_courses option:selected').val();
    var dataString = 'course_id='+course_id;
    $.ajax({
        type: 'POST',
        url: 'helpers/course_classes.php',
        data: dataString,
        cache: false,
        success: function(result){
          $('.r_course_class').html(result);
        }
    });
  });
  //Fetch results topic
  $('.r_course_class').change(function(){
    var course_class = $('.r_course_class').val();
    var course_id = $('.r_courses option:selected').val();
    var dataString = 'course_class='+course_class+'&course_id='+course_id;
    $.ajax({
        type: 'POST',
        url: 'helpers/quiz_topic.php',
        data: dataString,
        cache: false,
        success: function(result){
          $('#quiz_topic').html(result);
        }
    });
  });
  //Fetch quiz results
  $('#quiz_topic').change(function(){
    var course_class = $('.r_course_class').val();
    var course_id = $('.r_courses option:selected').val();
    var topic = $('#quiz_topic option:selected').val();
    var dataString = 'course_class='+course_class+'&course_id='+course_id+'&topic='+topic;
    $.ajax({
        type: 'POST',
        url: 'helpers/quiz-results.php',
        data: dataString,
        cache: false,
        success: function(result){
          $('#quiz-data').html(result);
        }
    });
  });
});
