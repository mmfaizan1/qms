<?php
$page = "quiz";
include('includes/top.php'); 
$teacher_id = $_SESSION['teacher_id'];
include('includes/connection.php');

$teacher_courses_sql = "SELECT * FROM `course_allocation` JOIN `courses` ON `course_allocation`.`allocated_course_id` = `courses`.`course_id` JOIN `teachers` ON `course_allocation`.`course_teacher_id` = `teachers`.`teacher_id` WHERE `course_allocation`.`course_teacher_id` ='$teacher_id'";
$teacher_courses_sqlR = mysqli_query($con, $teacher_courses_sql);

$quiz_id = $_GET['quiz_id'];

$populate_fields_q = mysqli_query($con, "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject`=`courses`.`course_id` JOIN `class` ON `quiz`.`class`=`class`.`class_id` JOIN `degree` ON `class`.`degree`=`degree`.`degree_id` WHERE `quiz`.`quiz_id`='$quiz_id'");
$quiz_data = mysqli_fetch_assoc($populate_fields_q);
$quiz_course = $quiz_data['course_id'];
$quiz_class = $quiz_data['class_id'];
$question_marks = $quiz_data['questions_marks'];
?>
<div class="content">
    <div class="container-fluid">
        <div class="form-group pull-left">
            <div class="col-sm-4">
                <a type="submit" href="quizzes.php" class="btn btn-default btn-fill btn-wd form-control"> <i class="fa fa-arrow-left"></i> Back to quizzes</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-11">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Edit Quiz</h4>
                    </div>
                    <div class="header">
                        <h4 class="text-danger text-center">Subject: <?php echo $quiz_data['course']; ?></h4>
                    </div>
                    <div class="content">
                        <input type="hidden" id="quiz_id" value="<?=$quiz_id;?>">
                        <div id="status_message"></div>
                        <form id="update-quiz-form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Course (<span class="text-warning">Change course first to view classes</span>)</label>
                                        <select name="" id="courses" class="form-control" required>
                                            <option value="">Select Course to Display Quizzes</option>
                                            <?php while($subjects = mysqli_fetch_assoc($teacher_courses_sqlR)):?>
                                                <option value="<?=$subjects[
                                                    'course_id'];?>"
                                                    <?php
                                                        if($quiz_course == $subjects['course_id']){
                                                            echo 'selected';
                                                        }
                                                    ?>
                                                    ><?= $subjects['course']; ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Class</label>
                                        <select name="" id="course_class" class="form-control" required>    <!-- Value from Database -->
                                            <option value="<?=$quiz_class?>" selected><?php echo $quiz_data['degree_name']."-".$quiz_data['semester']; ?></option>             
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Topic Name</label>
                                        <input type="text" id="topic_name" class="form-control" value="<?=$quiz_data['topic'];?>" required>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Select Question Marks</label>
                                        <select class="form-control" id="question_marks" required title="Each question will carry selected mark">
                                            <option>Select Marks</option>
                                            <option value="1"     <?php
                                                if($question_marks == "1"){
                                                    echo "selected";
                                                }else{

                                                }
                                            ?>
                                            >1</option>
                                            <option value="1.5"
                                            <?php
                                                if($question_marks == "1.5"){
                                                    echo "selected";
                                                }else{
                                                    
                                                }
                                            ?>
                                            >1.5</option>
                                            <option value="2"
                                            <?php
                                                if($question_marks == "2"){
                                                    echo "selected";
                                                }else{
                                                    
                                                }
                                            ?>
                                            >2</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Select Quiz Date</label>
                                        <input type="date" id="quiz_date"class="form-control" value="<?=$quiz_data['schedule'];?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Quiz Start Time</label>
                                        <input type="time" id="quiz_start_time"class="form-control" value="<?=$quiz_data['start_time'];?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Quiz End Time</label>
                                        <input type="time" id="quiz_end_time" class="form-control" value="<?=$quiz_data['end_time'];?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="pull-right">
                                    <a type="submit" href="quizzes.php" class="btn btn-default btn-wd">Cancel</a>
                                    <button type="button" class="btn btn-info btn-fill btn-wd" value="update-quiz" id="update-quiz">Update Quiz</button>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>