<?php
$page = "quiz";
include('includes/top.php'); 

$teacher_id = $_SESSION['teacher_id'];
include('includes/connection.php');

$attended_quiz_sql = "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject` = `courses`.`course_id` JOIN `class` ON `quiz`.`class`=`class`.`class_id` JOIN `degree` ON `class`.`degree`=`degree`.`degree_id`  WHERE `quiz`.`quiz_created_by` = '$teacher_id' AND `quiz`.`status`=3 ORDER BY `class`, `result_status` ASC";
$attended_quiz_sqlR = mysqli_query($con, $attended_quiz_sql);
?>
<div class="content">
    <div class="container-fluid">
        <?php 
            if (isset($_GET['Msg'])) {
                if ($_GET['Msg'] == 'declared') {
                    echo "<div class='alert alert-success'><h4 class='text-center'>Result against the quiz is Declared...</h4></div>";
                }
            }
        ?>
        <div class="form-group pull-left">
            <div class="col-sm-4">
                <a type="submit" href="quizzes.php" class="btn btn-default btn-fill btn-wd form-control"> <i class="fa fa-arrow-left"></i> Back to quizzes</a>
            </div>
        </div>
        <div class="form-group pull-right">
            <div class="col-sm-2">    
            </div>
            <div class="col-sm-2">    
                <a type="submit" href="add-quiz.php" class="btn btn-primary btn-fill btn-wd form-control"> Add New Quiz</a>
            </div>
            <div class="col-sm-2">
                <a type="submit" href="ongoing-quiz.php" class="btn btn-primary btn-fill btn-wd form-control"> Ongoing Quizzes</a>
            </div>
            <div class="col-sm-2">
                <a type="submit" href="attended-quiz.php" class="btn btn-primary btn-fill btn-wd form-control"> Quizzes Taken</a>
            </div>
            <div class="col-sm-2">
                <a type="submit" href="missed-quiz.php" class="btn btn-primary btn-fill btn-wd form-control"> Missed Quizzes</a>
            </div>
            <div class="col-sm-2">
                <a type="submit" href="postponed-quiz.php" class="btn btn-primary btn-fill btn-wd form-control"> Quiz postponed</a>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Quizzes Taken</h4>
                    </div>
                    <div class="content table-responsive">
                        <table class="table table-hover table-bordered table-striped">
                            <thead>
                                <th>Sr #</th>
                                <th>Course Code</th>
                                <th>Subject</th>
                                <th>Topic</th>
                                <th>Class</th>
                                <th>End Time</th>
                                <th>Status</th>
                            </thead>
                            <tbody>
                                <?php 
                                $i = 1;
                                while($attended_quizzes = mysqli_fetch_assoc($attended_quiz_sqlR)):
                                ?>
                                    <tr>
                                        <td><?php echo $i;?></td>
                                        <td><?php echo $attended_quizzes['course_code'];?></td>
                                        <td><?php echo $attended_quizzes['course'];?></td>
                                        <td><?php echo $attended_quizzes['topic']; ?></td>
                                        <td><?php echo $attended_quizzes['degree_name']."-".$attended_quizzes['semester']; ?></td>
                                        <td><?php echo $attended_quizzes['end_time']; ?></td>
                                        <td>
                                            <?php
                                            if($attended_quizzes['result_status'] == 0){
                                            ?>
                                                <a type="submit" value="declare_results" class="btn btn-primary btn-fill form-control" name="declare" href="declare-results.php?action=declare&quiz_id=<?=$attended_quizzes['quiz_id'];?>">Declare Result</a>
                                            <?php }else{ ?>
                                                <h5 class="text-danger">Result is Declared</h5>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                <?php 
                                $i++;
                                endwhile; 
                                ?>
                            </tbody>
                            <tfoot>
                                <th>#</th>
                                <th>Course Code</th>
                                <th>Subject</th>
                                <th>Topic</th>
                                <th>Class</th>
                                <th>End Time</th>
                                <th>Status</th>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>