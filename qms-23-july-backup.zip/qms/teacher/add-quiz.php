<?php
$page = "quiz";
include('includes/top.php'); 
$teacher_id = $_SESSION['teacher_id'];
include('includes/connection.php');

$teacher_courses_sql = "SELECT * FROM `course_allocation` JOIN `courses` ON `course_allocation`.`allocated_course_id` = `courses`.`course_id` JOIN `teachers` ON `course_allocation`.`course_teacher_id` = `teachers`.`teacher_id` WHERE `course_allocation`.`course_teacher_id` ='$teacher_id'";
$teacher_courses_sqlR = mysqli_query($con, $teacher_courses_sql);
?>

<div class="content">
    <div class="container-fluid">
        <div class="form-group pull-left">
            <div class="col-sm-4">
                <a type="submit" href="quizzes.php" class="btn btn-default btn-fill btn-wd form-control"> <i class="fa fa-arrow-left"></i> Back to quizzes</a>
            </div>
        </div>
        <div class="form-group pull-right">
            <div class="col-sm-2">    
            </div>
            <div class="col-sm-2">    
                <a type="submit" href="add-quiz.php" class="btn btn-primary btn-fill btn-wd form-control"> Add New Quiz</a>
            </div>
            <div class="col-sm-2">
                <a type="submit" href="ongoing-quiz.php" class="btn btn-primary btn-fill btn-wd form-control"> Ongoing Quizzes</a>
            </div>
            <div class="col-sm-2">
                <a type="submit" href="attended-quiz.php" class="btn btn-primary btn-fill btn-wd form-control"> Quizzes Taken</a>
            </div>
            <div class="col-sm-2">
                <a type="submit" href="missed-quiz.php" class="btn btn-primary btn-fill btn-wd form-control"> Missed Quizzes</a>
            </div>
            <div class="col-sm-2">
                <a type="submit" href="postponed-quiz.php" class="btn btn-primary btn-fill btn-wd form-control"> Quiz postponed</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-11">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Add Quiz</h4>
                    </div>
                    <div class="content">
                        <div id="status_message"></div>
                        <form id="add-quiz-form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Course</label>
                                        <select name="" id="courses" class="form-control" required>
                                            <option value="">Select Course to Display Quizzes</option>
                                            <?php while($subjects = mysqli_fetch_assoc($teacher_courses_sqlR)):?>
                                                <option value="<?=$subjects[
                                                    'course_id'];?>"><?= $subjects[
                                                    'course_code'].' - ' . $subjects['course']; ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Class</label>
                                        <select name="" id="course_class" class="form-control" required>
                                                    
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Topic Name</label>
                                        <input type="text" id="topic_name" class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Select Question Marks</label>
                                        <select class="form-control" id="question_marks" required title="Each question will carry selected mark">
                                            <option>Select Marks</option>
                                            <option value="1">1</option>
                                            <option value="1.5">1.5</option>
                                            <option value="2">2</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Select Quiz Date</label>
                                        <input type="date" id="quiz_date"class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Quiz Start Time</label>
                                        <input type="time" id="quiz_start_time"class="form-control" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Select Quiz End Time</label>
                                        <input type="time" id="quiz_end_time" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="pull-right">
                                    <a type="submit" href="quizzes.php" class="btn btn-default btn-wd">Cancel</a>
                                    <button type="button" class="btn btn-info btn-fill btn-wd" value="add-quiz" id="add-quiz">Add Quiz</button>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>