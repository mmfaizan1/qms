<?php
$page = "questions";
include('includes/top.php'); 
include('includes/connection.php');
$quiz_id = $_GET['quiz_id'];
$course_id = $_GET['course_id'];
$course_sql = "SELECT `course` FROM `courses` WHERE course_id='$course_id'";
$course_sqlR = mysqli_query($con, $course_sql);
$course_detail = mysqli_fetch_assoc($course_sqlR);
?>
<input type="hidden" id="quiz_id" value="<?=$quiz_id?>">
<input type="hidden" id="course_id" value="<?=$course_id?>">
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-11">
                <?php
                if(isset($_GET['msg'])){
                    if ($_GET['msg']=='mcq_added') {
                        echo "<div class='alert alert-success'><h4 class='text-center'>MCQ type Question Inserted successfully. Add More if you want..</h4></div>";
                    }
                }
                ?>
                <div class="card">
                    <div class="header">
                        <h4 class="title">Subject: <?= $course_detail['course'];?></h4>
                    </div>
                    <div class="content">
                        <form id="questions-form">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Select Question Type</label>
                                        <select name="" id="question_type" class="form-control">
                                            <option value="MCQ"></option>
                                            <optgroup label="Select Question Type">
                                                <option value="MCQ">Add New Question</option>
                                                <!-- <option value="FIB">Fill In The Blanks</option>
                                                <option value="SQ">Descriptive</option> -->
                                            </optgroup>
                                            <optgroup label="OR">
                                                <option value="existing">Select questions from existing</option>
                                            </optgroup>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div id="question_template">
                                
                            </div>
                            <div id="status_message"></div>
                            <div class="pull-right">
                                <a type="submit" href="quizzes.php" class="btn btn-default btn-wd" title="Finished adding questions?">Finish Adding Questions and Go Back</a>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>