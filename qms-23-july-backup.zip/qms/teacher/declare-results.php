<?php
$page = "quiz";
include('includes/top.php'); 

$teacher_id = $_SESSION['teacher_id'];
include('includes/connection.php');
//Declare Results
if (isset($_GET['action'])) {
    if ($_GET['action'] == 'declare') {
        $quiz_id = $_GET['quiz_id'];
        $quiz_details = mysqli_query($con, "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject`=`courses`.`course_id` WHERE `quiz`.`quiz_id`='$quiz_id'");

        $quiz = mysqli_fetch_assoc($quiz_details);
        $course_code = $quiz['course_code'];
        $course_name = $quiz['course'];
        $topic = $quiz['topic'];
        $class_id = $quiz['class'];
        $schedule = strtotime($quiz['schedule']);
        $schedule = date("d-m-Y", $schedule);

        $declare_result_q = mysqli_query($con, "UPDATE `quiz` SET `result_status`=1 WHERE `quiz_id`='$quiz_id'");
        //Notify Query
		$notify_q = mysqli_query($con, "INSERT INTO `notifications` (`title`, `description`, `time`, `notification_by`,`notification_for`,`severity`,`id`) VALUES ('Result Declared','Dear Student. Result of $topic has been Declared. The course is $course_code - $course_name. The quiz was taken on $schedule.', now(), 'teacher','class','1','$class_id')");
        /* sms gateway starts */
        $username = "923086573512";///Your Username
        $password = "1624";///Your Password
        $mobile = "923086573512";///Recepient Mobile Number
        $sender = "SenderID";
        $message = "SMS From QMS Application: Quiz Result of Topic '$topic' for the course '$course_name' Has Been Declared. Go and Check the Result";

        ////sending sms

        $post = "sender=".urlencode($sender)."&mobile=".urlencode($mobile)."&message=".urlencode($message)."";
        $url = "http://bulksms.com.pk/api/sms.php?username=923086573512&password=1624";
        $ch = curl_init();
        $timeout = 30; // set to zero for no timeout
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)');
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        $result = curl_exec($ch); 
        /*Print Responce*/
        //echo $result;
        /*sms gateway ends*/
        if($declare_result_q && $result){
            ?>
             <script>window.location='attended-quiz.php?Msg=declared';</script>
            <?php
        }
    }
}