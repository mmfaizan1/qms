<?php
$page = "questions";
include('includes/top.php'); 
include('includes/connection.php');
$question_id = $_GET['question_id'];
$quiz_id = $_GET['quiz_id'];
//quiz topic
$quiz_topic = mysqli_query($con, "SELECT `topic` FROM `quiz` WHERE `quiz_id`='$quiz_id'");
$topic_name = mysqli_fetch_assoc($quiz_topic);
$topic_name = $topic_name['topic'];
//populate input fields from database
$question_sql = "SELECT * FROM `questions` JOIN `question_types` ON `questions`.`question_type`=`question_types`.`type_id` JOIN `solution` ON `questions`.`question_id`=`solution`.`solution_question_id` WHERE `questions`.`question_id`='$question_id'";
$question_sqlR = mysqli_query($con, $question_sql);
$question_detail = mysqli_fetch_assoc($question_sqlR);
$question_type = $question_detail['type'];
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-11">
                <?php
                if(isset($_GET['msg'])){
                    if ($_GET['msg']=='mcq_added') {
                        echo "<div class='alert alert-success'><h4 class='text-center'>MCQ type Question Inserted successfully. Add More if you want..</h4></div>";
                    }
                }
                ?>
                <div class="card">
                    <div class="header">
                        <h4 class="title">Quiz Topic: <?= $topic_name;?></h4>
                    </div>
                    <div class="content">
                        <form id="questions-form">
                            <input type="hidden" id="edit_question_id" value="<?=$question_id;?>">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Question</label>
                                        <input type="text" class="form-control" required id="mcq_question" value="<?=$question_detail['question'];?>">   
                                    </div>
                                </div>
                            </div>
                            <?php if($question_type == 'MCQ'){ 

                                $mcq_options = mysqli_query($con, "SELECT * FROM `mcq_options` WHERE `mcq_question_id`='$question_id'");
                                $options = mysqli_fetch_assoc($mcq_options);
                            ?>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Option 1</label>
                                            <input type="text" class="form-control"required id="option_1" value="<?=$options['option_1'];?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Option 2</label>
                                            <input type="text" class="form-control" required id="option_2" value="<?=$options['option_2'];?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Option 3</label>
                                            <input type="text" class="form-control" required id="option_3" value="<?=$options['option_3'];?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Option 4</label>
                                            <input type="text" class="form-control" required id="option_4" value="<?=$options['option_4'];?>">
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Correct Answer</label>
                                        <input type="text" class="form-control" required id="correct_option" value="<?=$question_detail['solution'];?>">
                                    </div>
                                </div>
                            </div>
                            <div class="pull-right">
                                <a type="submit" href="quizzes.php" class="btn btn-default btn-wd" title="Finished adding questions?">Cancel</a>
                                <button type="button" id="edit-quiz-question" class="btn btn-success btn-fill" value="edit-question">Update Question</button>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div id="status_message"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>