<?php session_start();
include('session-set.php');
include('includes/connection.php');

if (isset($_POST['send_pass'])) {
	$s_email = $_POST['email'];
	$s_phone = $_POST['phone'];
	$verify_q = mysqli_query($con, "SELECT * FROM `teachers` WHERE `email`='$s_email' AND `activation_status`=1");
	$record_found = mysqli_num_rows($verify_q);
	if ($record_found == 1) {
		$s_details = mysqli_fetch_assoc($verify_q);
		
		$phone_number = $s_details['phone'];
		if ($phone_number == $s_phone) {
			$string = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$password = substr( str_shuffle( $string ), 0, 8 );
			$update_password = mysqli_query($con, "UPDATE `teachers` SET `password`='$password' WHERE `email`='$s_email'");
			if ($update_password) {
				// the message
				$msg = "Hello Dear, \n Your New Password is : '$password'. \n You can also Change Your Password If You Want.\n Have A Good Day.";
				// use wordwrap() if lines are longer than 70 characters
				$msg = wordwrap($msg,70);

				// send email
				$password_mail = mail($s_email,"Account Password Recovery.", $msg);
				if($password_mail){
					?>
						<script>window.location='forgot-password.php?Msg=sent'</script>
					<?php
				}else{
					?>
						<script>window.location='forgot-password.php?Msg=failure'</script>
					<?php
				}

			}
		}else{
			?>
			<script>window.location='forgot-password.php?Msg=incorrect'</script>
			<?php
		}
	}else{
		?>
		<script>window.location='forgot-password.php?Msg=incorrect'</script>
		<?php
	}
}
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Teacher | QMS</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <link href="assets/css/style.css" rel="stylesheet" />

    <!--     Fonts and icons     -->
    <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <!--     <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet"> -->
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

</head>
<body>
    <div class="margin-top" style="margin-top: 100px;"></div>
    
    <div class="container">  
        <?php 
            if (isset($_GET['msg'])) {
                if($_GET['msg'] == 'login_to_continue'){
                    ?>
                    <div class="alert alert-danger">
                        <h3 class="text-center">Attention! Please Login to continue</h3>
                    </div>
                    <?php
                }else if($_GET['msg'] == 'loggedout'){
                    ?>
                    <div class="alert alert-success">
                        <h3 class="text-center">Your are logged out Successfully</h3>
                    </div>
                    <?php
                }
            }
            if (isset($_GET['Msg'])) {
				if ($_GET['Msg']=='incorrect') {
					echo "<h1 class='text-center text-primary alert alert-danger'>Attention! Provided Details doesnot Match to any Record. Provide Correct Details</h1>";
				}else if ($_GET['Msg']=='sent') {
					echo "<h1 class='text-center text-primary alert alert-success'>Success! Your New Password has been sent to You Mail. <a href='index.php#initiate'>Login Now</a></h1>";
				}else if ($_GET['Msg']=='failure') {
					echo "<h1 class='text-center text-primary alert alert-danger'>Attention! Unable to perform Required Operation</h1>";
				}
			}
        ?>
        <div class="col-xs-2 hidden-xs"></div>
        <div class="col-sm-8">
        	<div id="reset">
				<div class="container">
					<div class="col-md-6 col-sm-12">
						<h2 class="heading bold">Fill in the Correct details to get New Password</h2>
						<br>
						<form method="post" class="wow fadeInUp" data-wow-delay="0.6s">
							<div class="row">
								<div class="form-group col-md-12 col-sm-12">
									<input type="email" class="form-control" placeholder="Your Email" name="email" required id="email">
								</div>
								<div class="form-group col-md-12 col-sm-12">
									<input type="text" class="form-control" name="phone" required id="phone" title="Enter Phone Example: 03001234567" pattern="[0][3][0-9]{9}" placeholder="(Example: 0300 1234567)">
								</div>
								<div class="form-group col-md-12 col-sm-12">
									<input type="submit" class="form-control" value="Send Password" name="send_pass" id="send_pass">
								</div>
								<div class="form-group col-md-12 col-sm-12 pull-right">
				                    <h3><a href="index.php">Go Back</a></h3>                    
				                </div>
							</div>
						</form>
					</div>
				</div>
			</div>
        </div>
</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
    <script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

    <!--  Charts Plugin -->
    <script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
    <script src="assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

    <!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
    <script src="assets/js/demo.js"></script>

    <script src="assets/js/custom.js"></script>


</html>
