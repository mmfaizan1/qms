<?php 
$page = "questions";
include('include/top.php'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-11">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Subject: Design and Analysis of Algorithm</h4>
                    </div>
                    <div class="content">
                        <form>
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="form-group">
                                        <label>Question Type</label>
                                        <select name="" id="" class="form-control">
                                            <option value="">Select Question Type</option>
                                            <option value="">MCQ</option>
                                            <option value="">Fill In The Blanks</option>
                                            <option value="">Descriptive</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <hr><h2>Question Type MCQ</h2>
                            <div class="row">
                                <!-- Question Type MCQ -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Question</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Option 1</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Option 2</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Option 3</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Option 4</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Correct Option</label>
                                        <select name="" id="" class="form-control">
                                            <option value=""></option>
                                            <option value="">Option 1</option>
                                            <option value="">Option 2</option>
                                            <option value="">Option 3</option>
                                            <option value="">Option 4</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <hr>
                                <h2>Question Type Fill in the Blanks</h2>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Question</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Correct Answer</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <hr>
                                <h2>Question Type Descriptive</h2>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Question</label>
                                        <input type="text" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Keywords (To be separated with commas)</label>
                                        <textarea name="" id="" cols="30" rows="5" class="form-control"></textarea>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="pull-right">
                                    <a type="submit" href="dashboard.html" class="btn btn-default btn-wd">Cancel</a>
                                    <button type="submit" class="btn btn-info btn-fill btn-wd">Add Question</button>
                            </div>
                            <div class="clearfix"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/top.php'); ?>