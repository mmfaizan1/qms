<?php
include('includes/connection.php');
$departments_q = mysqli_query($con, "SELECT * FROM `departments`");

$student_departments_q = mysqli_query($con, "SELECT * FROM `departments`");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Quiz Management System</title>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">

	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/animate.min.css">
	<link rel="stylesheet" href="css/et-line-font.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/style.css">
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500' rel='stylesheet' type='text/css'>
</head>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
<!-- preloader section -->
<div class="preloader">
	<div class="sk-spinner sk-spinner-circle">
       <div class="sk-circle1 sk-circle"></div>
       <div class="sk-circle2 sk-circle"></div>
       <div class="sk-circle3 sk-circle"></div>
       <div class="sk-circle4 sk-circle"></div>
       <div class="sk-circle5 sk-circle"></div>
       <div class="sk-circle6 sk-circle"></div>
       <div class="sk-circle7 sk-circle"></div>
       <div class="sk-circle8 sk-circle"></div>
       <div class="sk-circle9 sk-circle"></div>
       <div class="sk-circle10 sk-circle"></div>
       <div class="sk-circle11 sk-circle"></div>
       <div class="sk-circle12 sk-circle"></div>
    </div>
</div>
<!-- navigation section -->
<section class="navbar navbar-fixed-top custom-navbar" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="#" class="navbar-brand">QMS</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="index.php" class="smoothScroll">HOME</a></li>
				<li><a href="index.php#initiate" class="smoothScroll">Student Login</a></li>
			</ul>
		</div>
	</div>
</section>
<!-- initiate section -->
<section id="initiate">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 text-center">
				<div class="section-title">
					<h1 class="heading bold">Signup</h1>
					<hr>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<h2 class="heading bold">REGISTER AS TEACHER</h2>
				<form method="post" class="wow fadeInUp" data-wow-delay="0.6s" id="teacher_signup_form">
					<div class="col-md-12 col-sm-12 form-group">
						<input type="text" class="form-control" placeholder="Name" name="teacher_name" id="teacher_name">
					</div>
					<div class="col-md-12 col-sm-12 form-group">
						<input type="email" class="form-control" placeholder="Email" name="teacher_email" id="teacher_email">
					</div>
					<div class="col-md-12 col-sm-12 form-group">
						<select name="teacher_department" class="form-control" id="teacher_department">
							<option value="">Select Department</option>
							<?php while($departments = mysqli_fetch_assoc($departments_q)){ ?>
								<option value="<?php echo $departments['department_id'];?>"><?php echo $departments['department_name'];?></option>
							<?php } ?>
						</select>
					</div>
					<div class="col-md-12 col-sm-12 form-group">
						<input type="text" class="form-control" placeholder="Phone" name="teacher_phone" id="teacher_phone">
					</div>
					<div class="col-md-12 col-sm-12 form-group">
						<input type="password" class="form-control" placeholder="Password" name="teacher_password" id="teacher_password">
					</div>
					<div class="col-md-12 col-sm-12 form-group">
						<input type="button" class="form-control" name="teacher_signup" id="teacher_signup" value="Signup as a Teacher">
					</div>
				</form>
				<div class="col-md-12 col-md-12">
					<div id="teacher_status_message"></div>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<h2 class="heading bold">REGISTER AS STUDENT</h2>
				<form method="post" class="wow fadeInUp" data-wow-delay="0.6s" id="student_signup_form">
					<div class="col-md-12 col-sm-12 form-group">
						<input type="text" class="form-control" placeholder="Name" id="student_name">
					</div>
					<div class="col-md-12 col-sm-12 form-group">
						<input type="email" class="form-control" placeholder="Email" id="student_email">
					</div>
					<div class="col-md-12 col-sm-12 form-group">
						<select class="form-control" id="student_department">
							<option value="">Select Department</option>
							<?php while($student_departments = mysqli_fetch_assoc($student_departments_q)){ ?>
								<option value="<?php echo $student_departments['department_id'];?>"><?php echo $student_departments['department_name'];?></option>
							<?php } ?>
						</select>
					</div>
					<div class="col-md-12 col-sm-12 form-group">
						<select name="degree" name="degree" class="form-control" id="student_degrees">
							<option value="">Select Department to proceed</option>
						</select>
					</div>
					<div class="col-md-12 col-sm-12 form-group">
						<select name="semester" id="semester" class="form-control">
							<option value="">Select Degree to proceed</option>
						</select>
					</div>
					<div class="col-md-12 col-sm-12 form-group">
	                  <div class="col-sm-3">
	                    <label>Year</label>
	                    <input type="text" id="session_year" name="session_year" class="form-control" placeholder="eg: 14" pattern="[0-9]{2,2}" title="Atleast two Digits" required>
	                  </div>
	                  <div class="col-sm-3">
	                    <label>Degree Level</label>
	                    <input type="text" id="degree_level" name="degree_level" class="form-control" placeholder="uglc or glc" readonly required>
	                  </div>
	                  <div class="col-sm-6">
	                    <label>Rollno</label>
	                    <input type="text" id="rollno" name="rollno" class="form-control" placeholder="eg: 502" pattern="[0-9]{3,}" title="Enter valid Rollno in Digits" required>
	                  </div>
	                </div>
	                <div class="col-md-12 col-sm-12 form-group">
						<input type="text" class="form-control" placeholder="Phone" id="student_phone">
					</div>
					<div class="col-md-12 col-sm-12 form-group">
						<input type="password" class="form-control" placeholder="Password" id="student_password">
					</div>
					<div class="col-md-12 col-sm-12 form-group">
						<input type="button" name="add" class="form-control" id="student_signup" value="Signup as a Student">
					</div>
				</form>
				<div class="col-md-12 col-md-12">
					<div id="student_status_message"></div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- footer section -->
<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<p>Copyright © QMS | <a href="#" target="_parent">Unstoppables</a></p>
			</div>
		</div>
	</div>
</footer>


<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/isotope.js"></script>
<script src="js/imagesloaded.min.js"></script>
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/jquery.backstretch.min.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>