<?php session_start();
	$from_time = date('Y-m-d H:i:s');
	$to_time = $_SESSION['end_time'];

	$time_form = strtotime($from_time);
	$time_to = strtotime($to_time);

	$difference = $time_to - $time_form;

	echo "Time Left: ";echo $timer_time = date("i:s",$difference);echo "<br>"; 
	//echo date ('H:i:s',strtotime($timer_time));
	
	if($timer_time == "00:00"){
		unset($_SESSION['quiz_id']);
		?>
		<script>window.location="manage_quizzes.php?Msg=quiz_ended"</script>
		<?php
	}else{
		echo "OKAY";
	}
?>