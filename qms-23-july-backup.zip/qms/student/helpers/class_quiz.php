<?php session_start();


include('../../includes/connection.php'); 
$course_id = $_POST['course_id'];
$student_class = $_SESSION['student_class'];
$student_id = $_SESSION['student_id'];
$class_quiz_q = mysqli_query($con, "SELECT *  FROM `quiz` JOIN `result` ON `quiz`.`quiz_id` = `result`.`quiz_id` AND `result`.`student_id` = '$student_id' WHERE `subject`='$course_id' AND `class`='$student_class' AND `status`=3 AND `result_status`=1 ORDER BY `result`.`result_id` DESC");
$total_quizzes = mysqli_num_rows($class_quiz_q);

if ($total_quizzes>0) {
?>
	<div class="content table-responsive table-full-width">
	    <table class="table table-striped">
	        <thead>
	            <th>#</th>
	            <th>Topic</th>
	            <th>Quiz Date</th>
	            <th>Total Marks</th>
	            <th>Obtained Marks</th>
	            <th>Preview Quiz</th>
	        </thead>
	        <tbody>
	            <?php 
	            $i = 1;
	            while($quiz = mysqli_fetch_assoc($class_quiz_q)): ?>
		            <tr>
		                <td><?php echo $i; ?></td>
		                <td><?php echo $quiz['topic']; ?></td>
		                <td><?php echo $quiz['schedule']; ?></td>
		                <td><?php echo $quiz['total_marks'];?></td>
		                <td><?php echo $quiz['obtained_marks'];?></td>
		                <!-- Preview paper -->
		                <td><a href="student-answer-sheet.php?quiz_id=<?=$quiz['quiz_id'];?>&student_id=<?=$student_id;?>" class="text-primary"><i class="fa fa-eye fa-2x"></i></a></td>
		            </tr>
		        <?php 
		        $i++;
		        endwhile; ?>
	        </tbody>
	        <tfoot>
	            <th>#</th>
	            <th>Topic</th>
	            <th>Quiz Date</th>
	            <th>Total Marks</th>
	            <th>Obtained Marks</th>
	            <th>Preview Quiz</th>
	        </tfoot>
	    </table>
	</div>
<?php 
}else{
	echo '<h3 class="text-danger text-center">No quizzes results for this subject till now.</h3>';
}
?>