



<?php
$page = 'quiz';
include('includes/top.php');
$student_class = $_SESSION['student_class'];
//Fetch Quiz Details
$quiz_info = "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject`=`courses`.`course_id` JOIN `students` ON `quiz`.`class`=`students`.`class` WHERE `quiz`.`status`=2 AND `quiz`.`class`='$student_class'";
$quiz_info_R = mysqli_query($con, $quiz_info);
$quiz_details = mysqli_fetch_assoc($quiz_info_R);
$quiz_id = $quiz_details['quiz_id'];
$quiz_status = $quiz_details['status'];
$quiz_duration = $quiz_details['duration'];
if($quiz_status == 2):
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-11">        
                        <h4 class="text-danger blockquote">Subject: <?php echo $quiz_details['course']; ?></h4>
                        <span class="pull-right">Total Time: <?php echo $quiz_duration; ?> Minutes</span>
                        <hr>
                        <h4 class="text-center text-danger">Topic: <?php echo $quiz_details['topic']; ?></h4>
                        <?php  
                            //Fetch Quiz Questions Query
                            $MCQ_Q = "SELECT * FROM `questions` JOIN `question_paper` ON `question_paper`.`paper_question` = `questions`.`question_id` JOIN `question_types` ON `questions`.`question_type` = `question_types`.`type_id` JOIN `quiz` ON `quiz`.`quiz_id`=`question_paper`.`quiz` JOIN `students` ON `quiz`.`class`= `students`.`class` WHERE `students`.`class`='$student_class' AND `quiz`.`quiz_id`='$quiz_id' AND `quiz`.`status`=2 AND `questions`.`question_type`=1";
                            $MCQ_QR = mysqli_query($con, $MCQ_Q);
                            $total_MCQ = mysqli_num_rows($MCQ_QR);
                            //echo "<pre>"; print_r($questions = mysqli_fetch_assoc($question_paper_QR)); echo "</pre>";
                        ?>
                        <!-- For sending mcqs Count for validation -->
                        <input type="hidden" id="mcqs_count" name="mcqs_count" value="<?=$total_MCQ;?>">
                        <?php 
                            $i = 1; //for question Numbers 
                            $q = 1;

                        while($MCQ = mysqli_fetch_assoc($MCQ_QR)):
                            $question_id = $MCQ['question_id'];
                            $question_type_id = $MCQ['type_id'];
                            $question_type = $MCQ['type'];
                                //Fetch Mcq's Options Query
                                $mcq_options_Q = "SELECT * FROM `mcq_options` JOIN `questions` ON `questions`.`question_id` = `mcq_options`.`mcq_question_id` WHERE `questions`.`question_type`='$question_type_id' AND `questions`.`question_id`='$question_id'";
                                $mcq_options_QR = mysqli_query($con, $mcq_options_Q);
                        ?>
                                <!-- MCQs Questions -->
                                <div class="card mcq_question_<?=$q;?>">
                                    <div class="header">
                                        <h4 class="title">Question # <?php echo $i++; ?>: <?php echo $MCQ['question'];?></h4>
                                    	<div id="status_message"></div>
                                    </div>
                                    <div class="content mcq_option_<?=$q?>">
                                        <form>
                                            <?php 
                                                //print_r($options = mysqli_fetch_assoc($mcq_options_QR));
                                            while($options = mysqli_fetch_assoc($mcq_options_QR)):
                                            ?>
	                                            <div id="mcqs_options_<?=$q;?>">
                                                    <div class="col-md-6 option">
	                                                    <div class="form-group">
    	                                                    <input type="radio" name="option" id="option_<?= $q?>" value="<?= $options['option_1'];?>"> 
                                                            <?= $options['option_1'];?>
                                                    	</div>
                                                	</div>
                                                </div>
                                                <div id="mcqs_options_<?=$q;?>">
                                                    <div class="col-md-6 option">
                                                        <div class="form-group">
                                                            <input type="radio" name="option" id="option_<?= $q?>" value="<?= $options['option_2'];?>"> 
                                                            <?= $options['option_2'];?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="mcqs_options_<?=$q;?>">
                                                    <div class="col-md-6 option">
                                                        <div class="form-group">
                                                            <input type="radio" name="option" id="option_<?= $q?>" value="<?= $options['option_3'];?>"> 
                                                            <?= $options['option_3'];?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="mcqs_options_<?=$q;?>">
                                                    <div class="col-md-6 option">
                                                        <div class="form-group">
                                                            <input type="radio" name="option" id="option_<?= $q?>" value="<?= $options['option_4'];?>"> 
                                                            <?= $options['option_4'];?>
                                                        </div>
                                                    </div>
	                                            </div>
                                            <?php endwhile; ?>
                                                <div class="clearfix"></div>
                                        </form>
                                    </div>
                                </div>                                    
    	                <?php
    	                $q++;
                        endwhile; 
                        ?>
                    </div>
                </div><!-- Row Ends -->
                <!--Fill In the Blanks-->
				<div class="row">
                    <div class="col-lg-12 col-md-11">
                        <?php  
                            //Fetch Quiz Questions Query
                            $FIB_Q = "SELECT * FROM `questions` JOIN `question_paper` ON `question_paper`.`paper_question` = `questions`.`question_id` JOIN `question_types` ON `questions`.`question_type` = `question_types`.`type_id` JOIN `quiz` ON `quiz`.`quiz_id`=`question_paper`.`quiz` JOIN `students` ON `quiz`.`class`= `students`.`class` WHERE `students`.`class`='$student_class' AND `quiz`.`quiz_id`='$quiz_id' AND `quiz`.`status`=2 AND `questions`.`question_type`=2";
                            $FIB_QR = mysqli_query($con, $FIB_Q);
                            $total_FIB = mysqli_num_rows($FIB_QR);
                            //echo "<pre>"; print_r($questions = mysqli_fetch_assoc($question_paper_QR)); echo "</pre>";
                        ?>
                        <?php 
                        while($FIB = mysqli_fetch_assoc($FIB_QR)):
                            $question_id = $FIB['question_id'];
                            $question_type_id = $FIB['type_id'];
                        ?>
                                <!-- FIB Questions -->
                                <div class="card">
                                    <div class="header">
                                        <h4 class="title">Question # <?php echo $i++; ?>: <?php echo $FIB['question'];?></h4>
                                    	<div id="status_message"></div>
                                    </div>
                                    <div class="content">
                                        <form>
                                            Answer: <input type="text">
                                            <div class="clearfix"></div>
                                        </form>
                                    </div>
                                </div>
    	                <?php
                        endwhile; 
                        ?>
                    </div>
                </div><!-- Row Ends -->
                <!--Short Questions-->
				<div class="row">
                    <div class="col-lg-12 col-md-11">
                        <?php  
                            //Fetch Quiz Questions Query
                            $SQ_Q = "SELECT * FROM `questions` JOIN `question_paper` ON `question_paper`.`paper_question` = `questions`.`question_id` JOIN `question_types` ON `questions`.`question_type` = `question_types`.`type_id` JOIN `quiz` ON `quiz`.`quiz_id`=`question_paper`.`quiz` JOIN `students` ON `quiz`.`class`= `students`.`class` WHERE `students`.`class`='$student_class' AND `quiz`.`quiz_id`='$quiz_id' AND `quiz`.`status`=2 AND `questions`.`question_type`=3";
                            $SQ_QR = mysqli_query($con, $SQ_Q);
                            $total_SQ = mysqli_num_rows($SQ_QR);
                            //echo "<pre>"; print_r($questions = mysqli_fetch_assoc($question_paper_QR)); echo "</pre>";
                        ?>
                        <?php 
                        while($SQ = mysqli_fetch_assoc($SQ_QR)):
                            $question_id = $SQ['question_id'];
                            $question_type_id = $SQ['type_id'];
                        ?>
                                <!-- FIB Questions -->
                                <div class="card">
                                    <div class="header">
                                        <h4 class="title">Question # <?php echo $i++; ?>: <?php echo $FIB['question'];?></h4>
                                    	<div id="status_message"></div>
                                    </div>
                                    <div class="content">
                                <form>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <textarea name="" id="" rows="10" placeholder="Enter Your Answer Here" class="form-control border-input"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                                </div>
                                	
                                    
    	                <?php
                        endwhile; 
                        ?>
                    </div>
                </div><!-- Row Ends -->
                <div class="col-md-2 pull-right">
                    <div class="form-group">
                        <button type="submit" class="btn btn-info btn-fill btn-wd form-control">Submit Quiz</button>  
                    </div>
                </div>
            </div>
        </div>
<?php
include('includes/footer.php');
?>

<?php 
    else:
        echo "<div class='text-danger text-center my-auto'><h1>No Ongoing Quizzes. Come Back Later For Quiz</h1></div>";
endif;
?>
