<?php
$page = 'manage_quiz';
include('includes/top.php');

$student_id = $_SESSION['student_id'];
if (isset($_SESSION['quiz_id'])) {
    ?>
	<script>window.location='quiz.php?Msg=incomplete_quiz'</script>
    <?php
}

if (isset($_POST['start'])) {
	//if join Quiz Button is pressed
	$student_class = $_SESSION['student_class'];
	$quiz_id = $_POST['quiz_id'];
    echo $_SESSION['quiz_id'] = $quiz_id;
    $quiz_status = $_POST['quiz_status'];
    echo $_SESSION['quiz_status'] = $quiz_status;
    $quiz_duration = $_POST['quiz_duration'];
    echo $_SESSION['quiz_duration'] = $quiz_duration;
    $quiz_teacher = $_POST['teacher_id'];
    echo $_SESSION['teacher_id'] = $quiz_teacher;
    ?>
    	<div class="alert alert-success col-sm-12"><p class="text-center">Redirecting to Quiz Page! Please Wait. <img src='assets/img/loader.gif' alt='loading'> </p></div>
		<script type="text/JavaScript">
            setTimeout("location.href = 'quiz.php';", 5000);
        </script>
    <?php

}


//Fetch Quiz Details
$quiz_info = "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject`=`courses`.`course_id` JOIN `students` ON `quiz`.`class`=`students`.`class` JOIN `teachers` ON `quiz`.`quiz_created_by`=`teachers`.`teacher_id` WHERE `quiz`.`status`=2 AND `quiz`.`class`='$student_class'";
$quiz_info_R = mysqli_query($con, $quiz_info);
$quiz_details = mysqli_fetch_assoc($quiz_info_R);
$quiz_id = $quiz_details['quiz_id'];
$quiz_status = $quiz_details['status'];
$quiz_duration = $quiz_details['duration'];
$teacher_id = $quiz_details['quiz_created_by'];
//$_SESSION['quiz_id'] = $quiz_id;
//$session_quiz_id = $_SESSION['quiz_id'];
//echo $quiz_schedule = $quiz_details['schedule']."<br>";
//echo date('Y-m-d H:i:s');

$check_quiz_attended = "SELECT * FROM `answers` WHERE `answer_quiz_id`='$quiz_id' AND `answer_student_id`='$student_id'";
$check_quiz_attendedR = mysqli_query($con, $check_quiz_attended);
$is_appeared = mysqli_num_rows($check_quiz_attendedR);
if($is_appeared > 0){ 
	if (isset($_GET['Msg'])){
		if($_GET['Msg'] == 'no-quiz'){
			echo "<div class='alert alert-danger' id='messages'><h4 class='text-center'>Join any Quiz to Proceed</h4></div>";
		}else if($_GET['Msg'] == 'quiz_ended'){
			echo "<div class='alert alert-success' id='messages'><h4 class='text-center'>Quiz Ended Successfully. Wait till the results are Declared..!</h4></div>";
		}
	}
	echo "<div class='text-danger' id='messages' style='margin-top:170px; margin-bottom:200px'><h1 class='text-center'>No Quiz Right Now! Come back later....</h1></div>";
}else
if($quiz_status == 2):
?>

<div class="content">
	<div class="container-fluid">
		<?php 
			if (isset($_GET['Msg'])){
				if($_GET['Msg'] == 'no-quiz'){
					echo "<div class='alert alert-danger' id='messages'><h4 class='text-center'>Join any Quiz to Proceed</h4></div>";
				}else if($_GET['Msg'] == 'quiz_ended'){
					echo "<div class='alert alert-success' id='messages'><h4 class='text-center'>Quiz Ended Successfully. Wait till the results are Declared..!</h4></div>";
				}
			}
		?>
		<div class="row">
			<div class="col-lg-12 col-md-11">
				<div class="content table-responsive table-full-width">
					<form method="post">	
						<table class="table table-striped table-bordered">
							<thead>
								<th>Subject</th>
								<th>Quiz Topic</th>
								<th>Teacher</th>
								<th>Quiz Duration</th>
								<th>Action</th>
							</thead>
							<tbody>
								<?php ?>
								<tr>
									<td><?= $quiz_details['course'];?></td>
									<td><?= $quiz_details['topic'];?></td>
									<td><?= $quiz_details['name'];?></td>
									<td><?= $quiz_details['duration'];?> Minutes</td>
									<td>
										<button class="btn btn-info btn-fill btn-wd" value="start" name="start">Join Quiz</button>
									</td>
									<input type="text" name="subject" value="<?= $quiz_details['subject'];?>">
									<input type="text" name="quiz_id" value="<?= $quiz_id;?>">
									<input type="text" name="quiz_status" value="<?= $quiz_status;?>">
									<input type="text" name="quiz_duration" value="<?= $quiz_duration;?>">
									<input type="text" name="teacher_id" value="<?= $teacher_id;?>">
								</tr>
							</tbody>
						</table>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
    else:
        echo "<div class='text-danger text-center my-auto'><h1>No Ongoing Quizzes. Come Back Later For Quiz</h1></div>";
endif;
include('includes/footer.php');
?>