<?php
$page = 'manage_quiz';
include('includes/top.php');
date_default_timezone_set('Asia/Karachi');
$student_id = $_SESSION['student_id'];
if (isset($_SESSION['quiz_id'])) {
    ?>
	<script>window.location='quiz.php?Msg=incomplete_quiz'</script>
    <?php
}

if (isset($_POST['start'])) {
	//if join Quiz Button is pressed
	$student_class = $_SESSION['student_class'];
	$quiz_id = $_POST['quiz_id'];
    $quiz_status = $_POST['quiz_status'];
    $quiz_duration = $_POST['quiz_duration'];
    $quiz_teacher = $_POST['teacher_id'];

    //fetch quiz End time
    $quiz_missed_q=mysqli_query($con, "SELECT * FROM `quiz` WHERE `quiz_id`='$quiz_id'");
	$quiz_missed_details = mysqli_fetch_assoc($quiz_missed_q);
	$quiz_date = $quiz_missed_details['schedule'];
	$today_date = date("Y-m-d"); 
	$quiz_time = $quiz_missed_details['end_time'];
	$now_time = date("H:i:s");
	if($quiz_date < $today_date){
		?>
		<script type="text/JavaScript">
            window.location='manage-quizzes.php?Msg=missed';
        </script>
		<?php
	}else if($quiz_date > $today_date){
	?>
	<script type="text/javascript">
 		window.location='manage-quizzes.php?quiz_id=<?=$quiz_id?>&Msg=early&quiz_date=<?=$quiz_date;?>';
 	</script>
	<?php
	}else if($quiz_date < $today_date && $quiz_time < $now_time){
		?>
		<script type="text/JavaScript">
            window.location='manage-quizzes.php?Msg=missed';
        </script>
		<?php
	}elseif($quiz_date == $today_date && $quiz_time < $now_time){
		?>
		<script type="text/JavaScript">
            window.location='manage-quizzes.php?Msg=missed';
        </script>
		<?php
	}else{
		$_SESSION['teacher_id'] = $quiz_teacher;
    	$_SESSION['quiz_id'] = $quiz_id;
    	$_SESSION['quiz_status'] = $quiz_status;
    	$_SESSION['quiz_duration'] = $quiz_duration;
    ?>
    	<div class="alert alert-success col-sm-12"><p class="text-center">Redirecting to Quiz Page! Please Wait. <img src='assets/img/loader.gif' alt='loading'> </p></div>
		<script type="text/JavaScript">
            setTimeout("location.href = 'quiz.php';", 5000);
        </script>
    <?php
	}

}
?>

<div class="content">
	<div class="container-fluid">
		<?php 
			if (isset($_GET['Msg'])){
				if($_GET['Msg'] == 'no-quiz'){
					echo "<div class='alert alert-danger' id='messages'><h4 class='text-center'>Join any Quiz to Proceed</h4></div>";
				}if($_GET['Msg'] == 'no-quiz'){
					echo "<div class='alert alert-danger' id='messages'><h4 class='text-center'>Join any Quiz to Proceed</h4></div>";
				}else if($_GET['Msg'] == 'quiz_ended'){
					echo "<div class='alert alert-success' id='messages'><h4 class='text-center'>Quiz Ended Successfully. Wait till the results are Declared..!</h4></div>";
				}else if($_GET['Msg'] == 'time_over'){
					echo "<div class='alert alert-danger' id='messages'><h4 class='text-center'>Time Over! Quiz Ended. Please! Wait till the results are Declared..!</h4></div>";
				}else if($_GET['Msg'] == 'missed'){
					echo '<div class="alert alert-danger col-sm-12"><h4 class="text-center">Attention! You have missed the quiz. You are too late. You cannot join the quiz now.</h4></div>';
				}else if($_GET['Msg'] == 'early'){
                    $quiz_date = $_GET['quiz_date'];
                    echo "<div class='alert alert-danger'><h4 class='text-center'>You are too early. Quiz is on ".$quiz_date . ". You can on take quiz on the schedule date. Come back Later</h4></div>";
                }else if($_GET['Msg'] == 'pagerefresh'){
					echo "<div class='alert alert-danger' id='messages'><h4 class='text-center'>Attention! You have already been notified. You have Refreshed the Page while attending quiz. So, You have been Awarded Zero (0) Marks for this quiz.</h4></div>";
				}
				
			}
		?>
		<div class="row">
			<button class="btn btn-primary" data-toggle="collapse" data-target="#instructions"><h3 class="panel-title">Important Instructions (Click to view)</h3> </button>
			<!-- List group -->
			<ul class="list-group collapse" id="instructions">
			    <br>
			    <li class="list-group-item">Quiz will end at the scheduled time.</li>
			    <li class="list-group-item text-danger">Zero marks will be awarded for Unanswered questions.</li>
			    <li class="list-group-item text-warning">Your cannot change your answer once selected.</li>
			    <li class="list-group-item text-danger">Zero marks will be awarded for quiz if you refresh the page or try to leave the quiz during quiz.</li>
			    <li class="list-group-item">Quiz will be submitted automatically if you doesnot submit the quiz within given time frame.</li>
			</ul>
		</div><!-- Instruction Ends -->
		<hr>
		<div class="row">
			<div class="col-lg-12 col-md-11">
				<div class="content table-responsive table-full-width">
					<form method="post">	
						<table class="table table-striped table-bordered">
							<thead>
								<th>Sr#</th>
								<th>Subject</th>
								<th>Quiz Topic</th>
								<th>Teacher</th>
								<th>Quiz Duration</th>
								<th>Quiz End Time</th>
								<th>Action</th>
							</thead>
							<tbody>
								<?php
								//Fetch Quiz Details
								$quiz_info = "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject`=`courses`.`course_id` JOIN `students` ON `quiz`.`class`=`students`.`class` JOIN `teachers` ON `quiz`.`quiz_created_by`=`teachers`.`teacher_id` WHERE `quiz`.`status`=2 AND `quiz`.`class`='$student_class' AND `students`.`student_id`='$student_id'";
								$quiz_info_R = mysqli_query($con, $quiz_info);
								$total_quizzes = mysqli_num_rows($quiz_info_R);
								$sr_no = 1;
								if ($total_quizzes > 0) {
									while($quiz_details = mysqli_fetch_assoc($quiz_info_R)):
										$quiz_id = $quiz_details['quiz_id'];
										$quiz_status = $quiz_details['status'];
										$quiz_duration = $quiz_details['duration'];
										$teacher_id = $quiz_details['quiz_created_by'];
										$quiz_end_time = strtotime($quiz_details['end_time']);
										//$_SESSION['quiz_id'] = $quiz_id;
										//$session_quiz_id = $_SESSION['quiz_id'];
										//echo $quiz_schedule = $quiz_details['schedule']."<br>";
										//echo date('Y-m-d H:i:s');

										$check_quiz_attended = "SELECT * FROM `answers` WHERE `answer_quiz_id`='$quiz_id' AND `answer_student_id`='$student_id'";
										$check_quiz_attendedR = mysqli_query($con, $check_quiz_attended);
										$is_appeared = mysqli_num_rows($check_quiz_attendedR);
										if($is_appeared > 0){
										}else						

										if($quiz_status == 2):
										?>
												<tr>
													<td><?= $sr_no; ?></td>
													<td><?= $quiz_details['course'];?></td>
													<td><?= $quiz_details['topic'];?></td>
													<td><?= $quiz_details['name'];?></td>
													<td><?= $quiz_details['duration'];?> Minutes</td>
													<td><?= date('h:i:s a', $quiz_end_time);?></td>
													<td>
														<button class="btn btn-info btn-fill btn-wd" value="start" name="start">Join Quiz</button>
													</td>
													<input type="hidden" name="subject" value="<?= $quiz_details['subject'];?>">
													<input type="hidden" name="quiz_id" value="<?= $quiz_id;?>">
													<input type="hidden" name="quiz_status" value="<?= $quiz_status;?>">
													<input type="hidden" name="quiz_duration" value="<?= $quiz_duration;?>">
													<input type="hidden" name="teacher_id" value="<?= $teacher_id;?>">
												</tr>
										<?php
											else:
											    echo "<div class='text-danger text-center my-auto'><h1>No Ongoing Quizzes. Come Back Later For Quiz</h1></div>";
											endif;
											$sr_no++;
										endwhile;
									}else{
										echo "<div class='text-danger text-center my-auto'><h1>No Ongoing Quizzes. Come Back Later For Quiz.</h1></div>";
									}
									?>
								</tbody>
							</table>
						</form>
					</div> <!-- Content table ends-->
				</div> <!-- col-lg-12 col-md-11 Div ends -->
			</div><!-- Row Ends -->
			<hr>
		</div> <!-- end Container-fluid div -->
	</div><!-- end Content div -->
	<?php
include('includes/footer.php');
?>