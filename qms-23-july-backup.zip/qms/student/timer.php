


<?php session_start();
	include("./../includes/connection.php");
	$quiz_id = $_SESSION['quiz_id'];
	date_default_timezone_set('Asia/Karachi');
	$_SESSION['end_time'];
	$end_time = strtotime($_SESSION['end_time']);
	$now_time = strtotime(date("H:i:s"));
	$difference = $end_time - $now_time;
	
	echo "Time Left: ";
	echo $quiz_end_time = gmdate("H:i:s", $difference);
	if ($difference == 300) {
		?>
		<script type="text/javascript">
			var hurrySound = new Audio('assets/audios/five_minutes.mp3');
				hurrySound.loop = false;
				hurrySound.play();	
		</script>
		<?php
	}
	if ($difference == 60) {
		?>
		<script type="text/javascript">
			var hurrySound = new Audio('assets/audios/hurryup.mp3');
				hurrySound.loop = false;
				hurrySound.play();	
		</script>
		<?php
	}
	if ($difference < 60) {
		echo "<br> Hurry up. Less time Left. <br>Your quiz will submit automatically";
	}
	if ($difference == 0) {
		//$update_quiz_status_q = mysqli_query($con,"UPDATE `quiz` SET `status`=3 WHERE `quiz_id`='$quiz_id'");
		?>
			<script type="text/javascript">
				$("#quiz_form").submit();
				unset($_SESSION['quiz_id']);
			</script>
		<?php
	}
?>