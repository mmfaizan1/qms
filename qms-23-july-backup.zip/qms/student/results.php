<?php
$page = 'result';
include('includes/top.php');
if (isset($_SESSION['quiz_id'])) {
    ?>
    <script>window.location='quiz.php?Msg=incomplete_quiz'</script>
    <?php
}
$student_class = $_SESSION['student_class'];
$class_courses_q = mysqli_query($con, "SELECT * FROM `class_courses` JOIN `courses` ON `class_courses`.`course_id` = `courses`.`course_id` WHERE `class_courses`.`course_class_id` = '$student_class'");
?>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <div class="form-group">
                                    <label>Select Subject to View Quizzes</label>
                                    <select name="courses" id="courses" class="form-control border-input">
                                        <option value="">Select a course to view result</option>
                                        <?php while ($class_courses = mysqli_fetch_assoc($class_courses_q) ):?>
                                            <option value="<?php echo $class_courses['course_id'];?>"><?php echo $class_courses['course']; ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="content">
                                <div id="quiz-data">
                                    <h1 class="text-danger text-center">Select course and topic view Quiz Results</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br><hr>
                <h1 class="text-danger text-center">Quizzes that are missed by you</h1>
                <hr>
<?php 
//missed quizzes query
$student_id = $_SESSION['student_id'];
$class_quizzes = mysqli_query($con, "SELECT * FROM `quiz` WHERE `class`='$student_class' AND `status`=3");
$quiz_array = array();
while($quizzes = mysqli_fetch_assoc($class_quizzes)){
    $quiz_id = $quizzes['quiz_id'];
    $quiz_array[] = $quizzes['quiz_id'];
}
$attended_array = array();
$attended_quizzes = mysqli_query($con, "SELECT * FROM `result` WHERE `student_id`='$student_id'");
while ($attended = mysqli_fetch_assoc($attended_quizzes)) {
    $attended_array[] = $attended['quiz_id'];
}
$merged_array = array_merge($quiz_array, $attended_array);
//print_r($merged_array);
$unique_array = array_diff($merged_array, array_diff_assoc($merged_array, array_unique($merged_array)));
?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <table class="table table-hover table-bordered table-striped">
                                <thead>
                                    <th>Sr #</th>
                                    <th>Subject</th>
                                    <th>Topic</th>
                                    <th>Schedule</th>
                                    <th>Quiz Ended at</th>
                                    <th>Obtained Marks</th>
                                </thead>
                                <tbody>
                                    <?php 
                                    $q = 1;
                                    $total_missed = 0;
                                    foreach ($unique_array as $missed_quizzes) {
                                        $missed_quizzes_q = mysqli_query($con, "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject`=`courses`.`course_id` WHERE `quiz`.`quiz_id`=$missed_quizzes");
                                        $missed_quiz_details = mysqli_fetch_assoc($missed_quizzes_q);
                                        //$total_missed = $total_missed + 1;
                                        ?>
                                        <tr>
                                            <td><?php echo $q;?></td>
                                            <td><?php echo $missed_quiz_details['course'];?></td>
                                            <td><?php echo $missed_quiz_details['topic']; ?></td>
                                            <td><?php echo date("d-m-Y", strtotime($missed_quiz_details['schedule']));?></td>
                                            <td><?php echo date('h:i A', strtotime($missed_quiz_details['end_time']));
                                            ?></td>
                                            <td>0</td>
                                        </tr>
                                        <?php
                                        $q++;
                                    }
                                    ?>
                                </tbody>
                                <tfoot>
                                    <th>Sr #</th>
                                    <th>Subject</th>
                                    <th>Topic</th>
                                    <th>Schedule</th>
                                    <th>Quiz Ended at</th>
                                    <th>Obtained Marks</th>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php
include('includes/footer.php');
?>