<?php 
$page = "result";
include('includes/top.php');

$attempted_student_id = $_GET['student_id'];
//Fetching Student Details
$student_detail_q = mysqli_query($con, "SELECT * FROM `students` WHERE `student_id`='$attempted_student_id'");
$student_data = mysqli_fetch_assoc($student_detail_q);
//Fetch quiz Question paper
$quiz_id = $_GET['quiz_id'];
$quiz_details_q = "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject`=`courses`.`course_id` WHERE `quiz_id`='$quiz_id'";
$quiz_details_qr = mysqli_query($con, $quiz_details_q);
$quiz_details = mysqli_fetch_assoc($quiz_details_qr);

//Student attempted answer
$attempted_answer_q = mysqli_query($con, "SELECT * FROM `answers` WHERE `answer_quiz_id`='$quiz_id' AND `answer_student_id`='$attempted_student_id'");
?>
<div class="content">
    <div class="container-fluid">
    	<div class="row">
            <div class="col-lg-12 col-md-11">        
                <h4 class="text-danger blockquote">Subject: <?php echo $quiz_details['course']; ?><span class="pull-right">Topic: <?php echo $quiz_details['topic'];?></span> </h4>
                <hr>
            </div>
            <?php
            $quiz_question_q = "SELECT * FROM `questions` JOIN `question_paper` ON `questions`.`question_id`=`question_paper`.`paper_question` JOIN `question_types` ON `questions`.`question_type`=`question_types`.`type_id` JOIN `solution` ON `solution`.`solution_question_id`=`questions`.`question_id` WHERE `question_paper`.`quiz`='$quiz_id' ";
            
            $quiz_question_qr = mysqli_query($con, $quiz_question_q);
            $i = 1;
            while ($quiz_question = mysqli_fetch_assoc($quiz_question_qr)):
                $Question_type = $quiz_question['type'];
                $question_id = $quiz_question['question_id'];
                if($Question_type == 'MCQ'):
            ?>
                    <div class="row">
        	            <div class="col-lg-12 col-md-11">
        	            	<div class="card">
        	                   <div class="header">
                                    <h4 class="title">Question # <?php echo $i; ?>: <?php echo $quiz_question['question'];?></h4>
                                </div>
                                <?php 
                                $mcq_options_Q = "SELECT * FROM `mcq_options` JOIN `questions` ON `questions`.`question_id` = `mcq_options`.`mcq_question_id` WHERE `questions`.`question_type`=1 AND `questions`.`question_id`='$question_id'";
                                $mcq_options_QR = mysqli_query($con, $mcq_options_Q);
                                ?>
                                <div class="content">
                                <?php
                                while($mcq_option = mysqli_fetch_assoc($mcq_options_QR)):
                                    $mcq_option = array(
                                        "option1" =>   $mcq_option['option_1'],
                                        "option2" =>   $mcq_option['option_2'],
                                        "option3" =>   $mcq_option['option_3'],
                                        "option4" =>   $mcq_option['option_4']

                                    );
                                    //echo "Mcq_options ";print_r($mcq_option);
                                    ?>
                                    <?php for($i=1; $i<=4; $i++): ?>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <input type="radio" name="option" disabled><?php echo $mcq_option["option".$i]; ?>
                                            </div>
                                        </div>
                                    <?php endfor; ?>
                                </div>
                                <?php $attempted_ans = mysqli_fetch_assoc($attempted_answer_q);?>
                                <div class="col-sm-6">
                                    <h4 class="text-danger">
                                        Attempted answer: <?php echo $attempted_ans['answer'];?>
                                    </h4>
                                </div>
                                <div class="col-sm-6">
                                    <h4 class="text-danger">
                                        Correct answer: <?php echo $quiz_question['solution'];?>
                                    </h4>
                                </div>
                                <div class="clearfix"></div>
                                <?php
                                endwhile;
                                ?>
        	            	</div>
        	            </div>
                    </div>
            <?php
                elseif($Question_type == 'FIB'):
                    //Fill In The Blanks
                    ?>
                    <div class="card">
                       <div class="header">
                            <h4 class="title">Question # <?php echo $i; ?>: <?php echo $quiz_question['question'];?></h4>
                        </div>
                        <div class="content">
                            <!-- Input Type for answer -->
                        </div>
                    </div>
                    <?php
                elseif($Question_type == 'SQ'):
                    ?>
                    <div class="card">
                       <div class="header">
                            <h4 class="title">Question # <?php echo $i; ?>: <?php echo $quiz_question['question'];?></h4>
                        </div>
                        <div class="content">
                            <!-- textareas for answer -->
                        </div>
                    </div>
                    <?php
                endif;
            $i++;
            endwhile;
            ?>
    	</div><!-- Questions Row Ends -->
        <div class="row">
            <div class="col-md-2 pull-right">
                <div class="form-group">
                    <a type="submit" href="results.php" class="btn btn-info btn-fill btn-wd form-control" value="submit">Go Back</a>  
                </div>
            </div>
        </div>
    </div>
</div>
<?php include('includes/footer.php'); ?>