




<?php
$page = 'quiz';
include('includes/top.php');
$session_student_id = $_SESSION['student_id'];
$session_quiz_id = $_SESSION['quiz_id'];
$session_quiz_status = $_SESSION['quiz_status'];
$session_quiz_duration = $_SESSION['quiz_duration'];
$session_quiz_teacher = $_SESSION['teacher_id'];
    if (!isset($_SESSION['quiz_id'])) {
        ?>
        <script>window.location = 'manage-quizzes.php?Msg=no-quiz'</script>
        <?php
    }
if (isset($_SESSION['quiz_id'])):
    /* Submit quiz */
    if (isset($_POST['submit_quiz'])) {
        $question_id = $_POST['question_id']; 
        $options = $_POST['option'];
        $combined_array = array_combine ($question_id, $options);
        //echo "<pre>";print_r($combined_array);echo"</pre>";
        
        foreach ($combined_array as $question_id => $answer) {
            // insert the attempted answers in the database table
            $insert_answers_sql = "INSERT INTO `answers` (`answer_quiz_id`,`answer_student_id`,`answer_teacher_id`,`answer_question_id`,`answer`) VALUES ('$session_quiz_id','$session_student_id','$session_quiz_teacher','$question_id','$answer')";
            $insert_answers_sqlR = mysqli_query($con, $insert_answers_sql);

            //Check Whether answers are right or wrong
            $check_answers_sql = "SELECT * FROM `solution` WHERE `solution_question_id`='$question_id'";
            $check_answers_sqlR = mysqli_query($con, $check_answers_sql);
            while ($answers_solution = mysqli_fetch_assoc($check_answers_sqlR)) {
                $correct_answer = $answers_solution['solution'];
                //echo "answer Attempted=== " .$answer. "<br>";
                //echo "Correct answer=== " .$correct_answer. "<br>";
                if($answer == $correct_answer) {
                    //echo "correct <br><br>";
                    $mark_question_query = "UPDATE `answers` SET `answer_status`=1 WHERE `answer_quiz_id`='$session_quiz_id' AND `answer_student_id`='$session_student_id' AND `answer_question_id` ='$question_id'";
                    $mark_question_queryR = mysqli_query($con, $mark_question_query);    
                }else{
                    //echo "wrong <br><br>";
                    $mark_question_query = "UPDATE `answers` SET `answer_status`=0 WHERE `answer_quiz_id`='$session_quiz_id' AND `answer_student_id`='$session_student_id' AND `answer_question_id` ='$question_id'";
                    $mark_question_queryR = mysqli_query($con, $mark_question_query);
                }
            }
        }
        unset($_SESSION['quiz_id']);
        ?>
        <script>window.location='manage-quizzes.php?Msg=quiz_ended'</script>
        <?php
    }
        //Fetch Quiz Details
    $quiz_info = "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject`=`courses`.`course_id` JOIN `students` ON `quiz`.`class`=`students`.`class` WHERE `quiz`.`status`=2 AND `quiz`.`class`='$student_class' AND `quiz`.`quiz_id` = '$session_quiz_id'";
    $quiz_info_R = mysqli_query($con, $quiz_info);
    $quiz_details = mysqli_fetch_assoc($quiz_info_R);
    $quiz_id = $quiz_details['quiz_id'];
    //$quiz_status = $quiz_details['status'];
    $quiz_duration = $quiz_details['duration'];
    //$_SESSION['duration'] = $quiz_duration;
    //echo $quiz_start_time = $quiz_details['start_time'];echo "<br>";
    date_default_timezone_set('Asia/Karachi');
    $quiz_end_time = $quiz_details['end_time'];
    echo $_SESSION['start_time'] = date("Y-m-d H:i:s");
    echo "<br>";
    //echo $quiz_end_time = date('Y-m-d',strtotime('+'.$_SESSION['duration'].'minutes',strtotime($_SESSION['start_time'])));
    echo $_SESSION['end_time'] = $quiz_end_time;
    
    if($session_quiz_status == 2):
    ?>
        <div class="content">
            <div class="container-fluid">
                <?php 
                    if (isset($_GET['Msg'])){
                        if($_GET['Msg'] == 'incomplete_quiz'){
                            echo "<div class='alert alert-danger' id='messages'><h4 class='text-center'>Complete Quiz to go Back!</h4></div>";
                        }
                    }
                ?>
                <form method="post" id="quiz_form">
                <div class="row">
                    <div class="col-lg-12 col-md-11">        
                        <h4 class="text-danger blockquote">Subject: <?php echo $quiz_details['course']; ?> <span class="pull-right" id="time_left"></span></h4>
                        <hr>
                        <h4 class="text-center text-danger">Topic: <?php echo $quiz_details['topic']; ?></h4>
                        <hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-11">
                        <?php  
                            //Fetch Quiz Questions Query
                            $Question_Q = "SELECT * FROM `questions` JOIN `question_paper` ON `question_paper`.`paper_question` = `questions`.`question_id` JOIN `question_types` ON `questions`.`question_type` = `question_types`.`type_id` JOIN `quiz` ON `quiz`.`quiz_id`=`question_paper`.`quiz` JOIN `students` ON `quiz`.`class`= `students`.`class` WHERE `students`.`class`='$student_class' AND `quiz`.`quiz_id`='$quiz_id' AND `quiz`.`status`=2";
                            $Question_QR = mysqli_query($con, $Question_Q);
                            $total_MCQ = mysqli_num_rows($Question_QR);
                            //echo "<pre>"; print_r($questions = mysqli_fetch_assoc($question_paper_QR)); echo "</pre>";

                            $i = 1; //for question Numbers 
                            $q = 1; //for mcqs option divs
                            $m = 1; //for radio button name as $options[$m]

                        while($Question = mysqli_fetch_assoc($Question_QR)):
                            $question_id = $Question['question_id'];
                            $question_type_id = $Question['type_id'];
                            $question_type = $Question['type'];
                                //Fetch Mcq's Options Query
                                $mcq_options_Q = "SELECT * FROM `mcq_options` JOIN `questions` ON `questions`.`question_id` = `mcq_options`.`mcq_question_id` WHERE `questions`.`question_type`='$question_type_id' AND `questions`.`question_id`='$question_id'";
                                $mcq_options_QR = mysqli_query($con, $mcq_options_Q);
                            if($question_type == 'MCQ'):
                        ?>
                                <!-- For sending questions Count for validation -->
                                <input type="hidden" id="quiz_id" name="quiz_id" value="<?=$quiz_id;?>">
                                <input type="hidden" id="questions_count" name="questions_count" value="<?=$total_MCQ;?>">
                                <input type="hidden" id="question_id" name="question_id[]" value="<?=$question_id;?>">
                                <!-- MCQs Questions -->
                                <div class="card mcq_question_<?=$q;?>">
                                    <div class="header">
                                        <h4 class="title">Question # <?php echo $i++; ?>: <?php echo $Question['question'];?></h4>
                                    </div>
                                    <div class="content mcq_option_<?=$q?>">
                                        <?php 
                                            //print_r($options = mysqli_fetch_assoc($mcq_options_QR));
                                        while($options = mysqli_fetch_assoc($mcq_options_QR)):
                                        ?>
                                            <div id="mcqs_options_<?=$q;?>">
                                                <div class="col-md-6 option">
                                                    <div class="form-group">
	                                                    <input type="radio" name="option[<?=$m;?>]" id="option_<?= $q?>" class="q<?=$q;?>" value="<?= $options['option_1'];?>" required> 
                                                        <?= $options['option_1'];?>
                                                	</div>
                                            	</div>
                                            </div>
                                            <div id="mcqs_options_<?=$q;?>">
                                                <div class="col-md-6 option">
                                                    <div class="form-group">
                                                        <input type="radio" name="option[<?=$m;?>]" id="option_<?= $q?>" class="q<?=$q;?>" value="<?= $options['option_2'];?>" required> 
                                                        <?= $options['option_2'];?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="mcqs_options_<?=$q;?>">
                                                <div class="col-md-6 option">
                                                    <div class="form-group">
                                                        <input type="radio" name="option[<?=$m;?>]" id="option_<?= $q?>" class="q<?=$q;?>" value="<?= $options['option_3'];?>" required> 
                                                        <?= $options['option_3'];?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="mcqs_options_<?=$q;?>">
                                                <div class="col-md-6 option">
                                                    <div class="form-group">
                                                        <input type="radio" name="option[<?=$m;?>]" id="option_<?= $q?>" class="q<?=$q;?>" value="<?= $options['option_4'];?>" required> 
                                                        <?= $options['option_4'];?>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endwhile; ?>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>                                    
    	                <?php
                                elseif($question_type == 'FIB'):
                                    //echo $MCQ['question'];
                                elseif($question_type == 'SQ'):
    	                            //echo $MCQ['question'];
                                endif;
                        $q++; $m++;
                        endwhile; 
                        ?>
                        <div id="status_message" class="status<?=$q;?>"></div>
                    </div>
                </div><!-- Row Ends -->
                <div class="col-md-2 pull-right">
                    <div class="form-group">
                        <button type="submit" name="submit_quiz" class="btn btn-info btn-fill btn-wd form-control" value="submit">Submit Quiz</button>  
                    </div>
                </div>
                </form> 
                <!-- Form Ends -->
            </div>
        </div>
    <?php
    include('includes/footer.php');
    
    ?>
    <script>
        //Hide sidebar in Quiz page
        $(document).ready(function(){
            $(".sidebar").hide();
            $(".sidebar-wrapper").hide();
            $(".navbar").hide();
            $(".main-panel").css("width", "100%");
            
        });

        //timer function
        setInterval (function(){
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.open("GET","timer.php",false);
            xmlhttp.send(null);
            document.getElementById("time_left").innerHTML = xmlhttp.responseText;
        }, 1000);
    </script>
    <?php             
    endif;
endif;
?>

