<?php
$page = 'user';
include('includes/top.php');
if (isset($_SESSION['quiz_id'])) {
    ?>
    <script>window.location='quiz.php?Msg=incomplete_quiz'</script>
    <?php
}
$student_id = $_SESSION['student_id'];

if (isset($_POST['update'])) {
    $name = $_POST['student_name'];
    $email = $_POST['student_email'];
    $phone = $_POST['student_phone'];
    $password = $_POST['student_pass'];
    if (empty($name) || empty($email) || empty($phone) || empty($password)) {
        ?>
        <script>window.location='user.php?msg=empty'</script>
        <?php
    }else{
        $update_q = mysqli_query($con, "UPDATE `students` SET `name`='$name', `email`='$email', `phone`='$phone', `password`='$password' WHERE `student_id`='$student_id'");
        if ($update_q) {
            ?>
            <script>window.location='user.php?msg=updated'</script>
            <?php  
        }else{
            ?>
            <script>window.location='user.php?msg=failure'</script>
            <?php
        }
    }
}


$student_data = mysqli_query($con, "SELECT * FROM `students` JOIN `class` ON `students`.`class`=`class`.`class_id` JOIN `degree` ON `class`.`degree`=`degree`.`degree_id` JOIN `departments` ON `degree`.`department_id`=`departments`.`department_id` WHERE `students`.`student_id`='$student_id'");
$student = mysqli_fetch_assoc($student_data);
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <?php
                        if (isset($_GET['msg'])) {
                            if ($_GET['msg'] == 'empty') {
                                echo "<div class='alert alert-danger'><h3 class='text-danger text-center'>Attention! All fields Required</h3></div>";
                            }else if ($_GET['msg'] == 'updated') {
                                echo "<div class='alert alert-success'><h3 class='text-success text-center'>Success! Profile Updated successfully.</h3></div>";
                            }else if ($_GET['msg'] == 'failure') {
                                echo "<div class='alert alert-danger'><h3 class='text-danger text-center'>Attention! Unable to perform required operation</h3></div>";
                            }
                        }
                    ?>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-5">
                        <div class="card card-user">
                            <div class="image">
                                <img src="assets/img/background.jpg" alt="..."/>
                            </div>
                            <div class="content">
                                <div class="author">
                                  <img class="avatar border-white" src="assets/img/faces/face-2.jpg" alt="..."/>
                                  <h4 class="title"><?php echo $student['name']; ?><br /></h4>
                                </div>
                                <p class="description">
                                    <h6 class="text-danger text-center"><?php echo $student['email']; ?></h6>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-7">
                        <div class="card">
                            <div class="header">
                                <h4 class="title">Edit Profile</h4>
                            </div>
                            <div class="content">
                                <form method="post">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label>Roll#</label>
                                                <input type="text" class="form-control border-input" disabled placeholder="Roll#" value="<?php echo $student['rollno']; ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Degree</label>
                                                <input type="text" class="form-control border-input" placeholder="Degree" value="<?php echo $student['degree_name']; ?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>Semester</label>
                                                <input type="text" class="form-control border-input" placeholder="Semester" value="<?php echo $student['semester']; ?>" disabled>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Department</label>
                                                <input type="text" class="form-control border-input" placeholder="Department" value="<?php echo $student['department_name']; ?>" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Name</label>
                                                <input type="text" class="form-control border-input" name="student_name" placeholder="Username" value="<?php echo $student['name']; ?>" required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email address</label>
                                                <input type="email" class="form-control border-input" name="student_email" placeholder="Email" value="<?php echo $student['email']; ?>" required title="Example: example@gmail.com" pattern="(?!_)[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,63}$">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Phone</label>
                                                <input type="text" class="form-control border-input" name="student_phone" placeholder="Phone" value="<?php echo $student['phone']; ?>" title="Enter Phone Example: 03001234567" pattern="[0][3][0-9]{9}" placeholder="(Example: 0300 1234567)" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Password</label>
                                                <input type="text" class="form-control border-input" name="student_pass" placeholder="Phone" value="<?php echo $student['password']; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-info btn-fill btn-wd" name="update" value="update">Update Profile</button>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>

<?php
include('includes/footer.php');
?>