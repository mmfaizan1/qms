<?php 



if (isset($_SESSION['email'])) {
	header('Location: student/index.php?msg=already_logged_in');
}
?>