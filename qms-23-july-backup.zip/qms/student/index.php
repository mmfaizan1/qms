<?php
$page = 'dashboard';
include('includes/top.php');

if (isset($_SESSION['quiz_id'])) {
    ?>
    <script>window.location='quiz.php?Msg=incomplete_quiz'</script>
    <?php
}
$student_class = $_SESSION['student_class'];
$quiz_q = mysqli_query($con, "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject`=`courses`.`course_id` WHERE `class`='$student_class' AND `quiz`.`status`=1");
$total_quizzes = mysqli_num_rows($quiz_q);


$notification_q = mysqli_query($con, "SELECT * FROM `notifications` WHERE `notification_for`='student' AND `id`='$student_id' OR `notification_for`='class' AND `id`='$student_class' ORDER BY `notification_id` DESC Limit 0,10");
$total_notifications = mysqli_num_rows($notification_q);
?>
        <div class="content">
            <div class="container-fluid">   
                <div class="row">
                    <div class="col-lg-8 col-sm-6">
                        <div class="card" style="padding: 4px;">
                            <div class="card-title">
                                <h3 class="text-center">New quizzes</h3><hr />
                            </div>
                            <div class="content">
                                <div class="row">
                                    <div class="col-md-12 col-xs-5">
                                        <?php
                                        if ($total_quizzes > 0 ) {
                                            while($new_quiz = mysqli_fetch_assoc($quiz_q)){
                                                ?>
                                                <div class="alert alert-info">    <a href="manage-quizzes.php" class="text-primary">  
                                                    <?php echo $new_quiz['topic']. " - ".$new_quiz['course_code']." - ".$new_quiz['course']; ?></div>
                                                </a>
                                               <?php
                                            }  
                                        }else{
                                            ?>
                                            <h3 class="text-danger text-center">No New Quizzes Right Now.</h3>
                                            <?php
                                        }

                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="card" style="padding: 4px;">
                            <div class="card-title">
                                <h3 class="text-center">Announcements</h3><hr />
                            </div>
                            <div class="content">
                                <div class="row">
                                    <div class="col-md-12 col-xs-5">
                                        <ul class="list-group">
                                            <?php
                                            if ($total_notifications > 0) {
                                                while ($notification = mysqli_fetch_assoc($notification_q)) {
                                                    $severity = $notification['severity'];
                                                    ?>
                                                    <li class="list-group-item"><a class="text-<?php if($severity == 1){echo "info";}else if($severity == 2){echo "warning";}else if($severity == 3){echo "danger";}?>" href="notifications.php"><?php echo $notification['title']; ?></a></li>
                                                    <?php        
                                                }
                                            }else{
                                                ?>
                                                <li class="list-group-item">
                                                    <h4 class="text-info text-center">No Announcement</h4>
                                                </li>
                                                <?php
                                            }
                                            ?>
                                        </ul>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
include('includes/footer.php');
?>

<?php
    //success or error messages
    if (isset($_GET['msg'])) {
        if($_GET['msg']=='logged_in'){    
            ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    demo.initChartist();

                    $.notify({
                        icon: 'ti-check-box',
                        message: "Welcome User. You are successfully Logged in"

                    },{
                        type: 'success',
                        timer: 4000
                    });

                });
            </script>
            <?php
        }else if($_GET['msg']=='logged_in_p'){    
            ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    demo.initChartist();

                    $.notify({
                        icon: 'ti-check-box',
                        message: "Welcome User.You have set your Password and You are successfully Logged in"

                    },{
                        type: 'success',
                        timer: 4000
                    });

                });
            </script>
            <?php
        }   else if($_GET['msg']=='already_logged_in'){    
            ?>
            <script type="text/javascript">
                $(document).ready(function(){
                    demo.initChartist();

                    $.notify({
                        icon: 'ti-close',
                        message: "Attention! You are already Logged in"

                    },{
                        type: 'danger',
                        timer: 4000
                    });

                });
            </script>
            <?php
        }
    }
?>