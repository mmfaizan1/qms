<?php session_start();
include('session-not-set.php');
include('./../includes/connection.php');
$email = $_SESSION['email'];


$usernameQ = mysqli_query($con, "SELECT * FROM `students` WHERE `email` = '$email'");
$user = mysqli_fetch_assoc($usernameQ);
$student_id = $user['student_id'];
$student_name = $user['name'];
$student_class = $user['class'];
$student_department_sql = mysqli_query($con, "SELECT * FROM `class` JOIN `students` ON `class`.`class_id` = `students`.`class` JOIN `degree` ON `class`.`degree` = `degree`.`degree_id` JOIN `departments` ON `degree`.`department_id` = `departments`.`department_id` WHERE `students`.`student_id` ='$student_id' AND `class`.`class_id`='$student_class'"); 
$student_department = mysqli_fetch_assoc($student_department_sql);
$student_depart = $student_department['department_id']; 
$student_degree = $student_department['degree_id'];

$_SESSION['department'] = $student_depart;
$_SESSION['degree'] = $student_degree;
$_SESSION['student_name'] = $student_name;
$_SESSION['student_class'] = $student_class;
$_SESSION['student_id'] = $student_id;
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>QMS | Student</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Paper Dashboard core CSS    -->
    <link href="assets/css/paper-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--  Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/themify-icons.css" rel="stylesheet">

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">

    <!--
		Tip 1: you can change the color of the sidebar's background using: data-background-color="white | black"
		Tip 2: you can change the color of the active button using the data-active-color="primary | info | success | warning | danger"
	-->
    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                    <?php echo $student_name; ?>
                </a>
            </div>

            <ul class="nav">
                <li class="<?php if ($page == 'dashboard') {echo 'active';} ?>">
                    <a href="index.php">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="<?php if ($page == 'manage_quiz') {echo 'active';} ?>">
                    <a href="manage-quizzes.php">
                        <i class="ti-comment"></i>
                        <p>Quiz</p>
                    </a>
                </li>
                <li class="<?php if ($page == 'result') {echo 'active';} ?>">
                    <a href="results.php">
                        <i class="ti-view-list-alt"></i>
                        <p>Results</p>
                    </a>
                </li>
                <li class="<?php if ($page == 'announcements') {echo 'active';} ?>">
                    <a href="notifications.php">
                        <i class="ti-bell"></i>
                        <p>Announcements</p>
                    </a>
                </li>
                <li class="<?php if ($page == 'user') {echo 'active';} ?>">
                    <a href="user.php">
                        <i class="ti-user"></i>
                        <p>Profile</p>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <i class="ti-close"></i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">
                        <?php 
                            if ($page == 'manage_quiz') {
                                echo 'Quiz';
                            }elseif ($page == 'dashboard'){
                                echo 'Dashboard';
                            }elseif ($page == 'announcements'){
                                echo 'Announcements';
                            }elseif ($page == 'user'){
                                echo 'User Profile';
                            }elseif ($page == 'result'){
                                echo 'Quiz Results';
                            }elseif ($page == 'user'){
                                echo 'Profile';
                            }
                        ?>
                        
                    </a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-bell"></i>
                                    <p class="notification">5</p>
									<p>Notifications</p>
									<b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Notification 1</a></li>
                                <li><a href="#">Notification 2</a></li>
                                <li><a href="#">Notification 3</a></li>
                                <li><a href="#">Notification 4</a></li>
                                <li><a href="#">Another notification</a></li>
                              </ul>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>