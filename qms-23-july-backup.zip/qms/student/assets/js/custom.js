


$(document).ready(function(){
    //Disable Inspect Element and reload keys starts
    //f12 key
    $(document).keydown(function(e){
      if(e.which === 123){

         return false;

      }

    });
    //Disable Right Click 
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });
    //disble ctrl+shift+c, ctrl+shift+j, ctrl+shift+i and ctrl+u
    $(document).keydown(function (event) {
        if ((event.ctrlKey && event.shiftKey && event.keyCode == 73) || (event.ctrlKey && event.shiftKey && event.keyCode == 74) || (event.ctrlKey && event.shiftKey && event.keyCode == 67) || (event.ctrlKey && event.keyCode == 85)) {
            return false;
        }
    });
  //Disable inspect element and reload keys ends

    //Quiz conduction ajax script
    $("input[type='radio']").click(function(){
         var option_selected = $(this);
         var option_value = option_selected.val();        
         var mcqClass = $(this).attr('class');
         $("."+mcqClass).hide();
         $("#status_message").append("<div class='col-sm-12 alert alert-success text-primary'> You Have Selected The Option -' "+option_value+" '</div>");
    });

    //student Quizzes
    $('#courses').change(function(){
    	var course_id = $('#courses').val();
    	var dataString = 'course_id='+course_id;
    	$.ajax({
	        type: 'POST',
	        url: 'helpers/class_quiz.php',
	        data: dataString,
	        cache: false,
	        success: function(result){
	          $('#quiz-data').html(result);
	        }
    	});
    });
});

