



<?php
$page = 'quiz';
include('includes/top.php');
$student_class = $_SESSION['student_class'];
//Fetch Quiz Details
$quiz_info = "SELECT * FROM `quiz` JOIN `courses` ON `quiz`.`subject`=`courses`.`course_id` JOIN `students` ON `quiz`.`class`=`students`.`class` WHERE `quiz`.`status`=2 AND `quiz`.`class`='$student_class'";
$quiz_info_R = mysqli_query($con, $quiz_info);
$quiz_details = mysqli_fetch_assoc($quiz_info_R);
$quiz_id = $quiz_details['quiz_id'];
$quiz_status = $quiz_details['status'];
$quiz_duration = $quiz_details['duration'];
if($quiz_status == 2):
?>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-11">        
                        <h4 class="text-danger blockquote">Subject: <?php echo $quiz_details['course']; ?></h4>
                        <span class="pull-right">Total Time: <?php echo $quiz_duration; ?> Minutes</span>
                        <hr>
                        <h4 class="text-center text-danger">Topic: <?php echo $quiz_details['topic']; ?></h4>
                        <?php  
                            //Fetch Quiz Questions Query
                            $question_paper_Q = "SELECT * FROM `questions` JOIN `question_paper` ON `question_paper`.`paper_question` = `questions`.`question_id` JOIN `question_types` ON `questions`.`question_type` = `question_types`.`type_id` JOIN `quiz` ON `quiz`.`quiz_id`=`question_paper`.`quiz` JOIN `students` ON `quiz`.`class`= `students`.`class` WHERE `students`.`class`='$student_class' AND `quiz`.`quiz_id`='$quiz_id' AND `quiz`.`status`=2";
                            $question_paper_QR = mysqli_query($con, $question_paper_Q);
                            echo $num_rows = mysqli_num_rows($question_paper_QR);
                            //print_r($questions = mysqli_fetch_assoc($question_paper_QR));
                        ?>
                        <?php 
                            $i = 1;
                            $q = 1;
                            $total_mcqs = 0;
                        while($questions = mysqli_fetch_assoc($question_paper_QR)): 
                            $question_id = $questions['question_id'];
                            $question_type_id = $questions['type_id'];
                            $question_type = $questions['type'];
                            
                            if($question_type == 'MCQ'):
                                
                                //Fetch Mcq's Options Query
                                $mcq_options_Q = "SELECT * FROM `mcq_options` JOIN `questions` ON `questions`.`question_id` = `mcq_options`.`mcq_question_id` WHERE `questions`.`question_type`='$question_type_id' AND `questions`.`question_id`='$question_id'";
                                $mcq_options_QR = mysqli_query($con, $mcq_options_Q);
                        ?>
                                <div class="card">
                                    <div class="header">
                                        <h4 class="title">Question # <?php echo $i++; ?>: <?php echo $questions['question'];?></h4>
                                    	<div id="status_message"></div>
                                    </div>
                                    <div class="content">
                                        <form>
                                            <?php 
                                                //print_r($options = mysqli_fetch_assoc($mcq_options_QR));
                                            while($options = mysqli_fetch_assoc($mcq_options_QR)):
                                                $mcq_option_array = 
                                                array($options["option_1"],
                                                    $options["option_2"],
                                                        $options["option_3"],
                                                            $options["option_4"]
                                                );
                                            ?>
	                                            <div class="mcqs_options_<?=$q;?>">    
	                                                <?php foreach ($mcq_option_array as $option): ?>
		                                                    <div class="col-md-6 option">
	    	                                                    <div class="form-group">
	        	                                                    <input type="radio" name="option" id="option" value="<?= $option;?>"> 
		                                                            <?= $option;?>
	                                                        	</div>
	                                                    	</div>
	                                                <?php  endforeach; ?>
	                                            </div>
                                            <?php endwhile; ?>
                                                <div class="clearfix"></div>
                                        </form>
                                    </div>
                                </div>
                        <?php
                                elseif ($question_type == 'SQ'): ?>
                                	<div class="card">
                                    	<div class="header">
                                        	<h4 class="title">Question # <?php echo $i++; ?>: <?php echo $questions['question'];?></h4>
	                                    	<div id="status_message"></div>
    	                                </div>
    	                                <div class="content">
			                                <form>
			                                    <div class="row">
			                                        <div class="col-md-12">
			                                            <div class="form-group">
			                                                <textarea name="" id="" rows="10" placeholder="Enter Your Answer Here" class="form-control border-input"></textarea>
			                                            </div>
			                                        </div>
			                                    </div>
			                                    <div class="form-group">
			                                        <div class="col-md-2">
			                                            <div class="form-group">
			                                                <button type="submit" class="btn btn-default btn-fill btn-wd form-control">Save</button>  
			                                            </div>
			                                        </div>
			                                        <div class="col-md-2">
			                                            <div class="form-group">
			                                                <button type="submit" class="btn btn-info btn-fill btn-wd form-control">Submit</button>  
			                                            </div>
			                                        </div>
			                                    </div>
			                                    <div class="clearfix"></div>
			                                </form>
			                            </div>
    	                            </div>
                        <?php
                                elseif($question_type == 'FIB'): ?>
                                    <div class="card">
                                    	<div class="header">
                                        	<h4 class="title">Question # <?php echo $i++; ?>: <?php echo $questions['question'];?></h4>
	                                    	<div id="status_message"></div>
    	                                </div>
    	                                <div class="content">
			                                <form>
			                                    <div class="row">
			                                        <div class="col-md-12">
			                                            <div class="form-group">
			                                                <textarea name="" id="" rows="10" placeholder="Enter Your Answer Here" class="form-control border-input"></textarea>
			                                            </div>
			                                        </div>
			                                    </div>
			                                    <div class="form-group">
			                                        <div class="col-md-2">
			                                            <div class="form-group">
			                                                <button type="submit" class="btn btn-default btn-fill btn-wd form-control">Save</button>  
			                                            </div>
			                                        </div>
			                                        <div class="col-md-2">
			                                            <div class="form-group">
			                                                <button type="submit" class="btn btn-info btn-fill btn-wd form-control">Submit</button>  
			                                            </div>
			                                        </div>
			                                    </div>
			                                    <div class="clearfix"></div>
			                                </form>
			                            </div>
    	                            </div>
    	                <?php
    	                		else:
    	                			"<div class='text-center text-center'><h1>There are no Questions Added For This Quiz </h1></div>";
                            endif;
                        $q++;
                        endwhile; 
                        echo "Total Mcqs". $total_mcqs;
                        ?>
                    </div>
                </div><!-- Row Ends -->
                <!-- <div class="row">
                    <div class="col-lg-12 col-md-11">
                        <div class="card">
                            <div class="header">
                                <p class="pull-right">(Marks: 1)</p>
                                <h4 class="title">Question # 2: Define Stakeholders.</h4>
                            </div>
                            <div class="content">
                                <form>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <textarea name="" id="" rows="10" placeholder="Enter Your Answer Here" class="form-control border-input"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-default btn-fill btn-wd form-control">Save</button>  
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-info btn-fill btn-wd form-control">Submit</button>  
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div><!-- Row Ends -->
                <!--
                <div class="row">
                    <div class="col-lg-12 col-md-11">
                        <div class="card">
                            <div class="header">
                                <h4 class="title"></h4>
                            </div>
                            <div class="content">
                                <form>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <h4 class="title">
                                                    <p class="pull-right">(Marks: 1)</p>
                                                    Question # 3: In 2018, Project Management will be equivalent to <input type="text" placeholder="Write the answer" class="blank_space"> in the technological aspects.
                                                </h4>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-info btn-fill btn-wd form-control">Submit</button>  
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div><!-- Row Ends -->
            </div>
        </div>
<?php
include('includes/footer.php');
?>

<?php 
    else:
        echo "<div class='text-danger text-center my-auto'><h1>No Ongoing Quizzes. Come Back Later For Quiz</h1></div>";
endif;
?>
