<?php session_start();
include("./../includes/connection.php");

/* Submit quiz */
$session_student_id = $_SESSION['student_id'];
$session_quiz_id = $_SESSION['quiz_id'];
$session_quiz_status = $_SESSION['quiz_status'];
$session_quiz_duration = $_SESSION['quiz_duration'];
$session_quiz_teacher = $_SESSION['teacher_id'];
        
        $question_id = $_POST['question_id']; 
        $options = $_POST['option'];
        
        $combined_array = array_combine ($question_id, $options);
        //echo "<pre>";print_r($combined_array);echo"</pre>";
        
        foreach ($combined_array as $question_id => $answer) {
            // insert the attempted answers in the database table
            $insert_answers_sql = "INSERT INTO `answers` (`answer_quiz_id`,`answer_student_id`,`answer_teacher_id`,`answer_question_id`,`answer`) VALUES ('$session_quiz_id','$session_student_id','$session_quiz_teacher','$question_id','$answer')";
            $insert_answers_sqlR = mysqli_query($con, $insert_answers_sql);

            //Check Whether answers are right or wrong
            $check_answers_sql = "SELECT * FROM `solution` WHERE `solution_question_id`='$question_id'";
            $check_answers_sqlR = mysqli_query($con, $check_answers_sql);
            while ($answers_solution = mysqli_fetch_assoc($check_answers_sqlR)) {
                $correct_answer = $answers_solution['solution'];
                //echo "answer Attempted=== " .$answer. "<br>";
                //echo "Correct answer=== " .$correct_answer. "<br>";
                if($answer == $correct_answer) {
                    // echo "correct <br><br>";
                    $mark_question_query = "UPDATE `answers` SET `answer_status`=1 WHERE `answer_quiz_id`='$session_quiz_id' AND `answer_student_id`='$session_student_id' AND `answer_question_id` ='$question_id'";
                    $mark_question_queryR = mysqli_query($con, $mark_question_query);    
                }else{
                    //echo "wrong <br><br>";
                    $mark_question_query = "UPDATE `answers` SET `answer_status`=0 WHERE `answer_quiz_id`='$session_quiz_id' AND `answer_student_id`='$session_student_id' AND `answer_question_id` ='$question_id'";
                    $mark_question_queryR = mysqli_query($con, $mark_question_query);
                }
            }
        }
        //Total quiz marks
        $total_marks_q = mysqli_query($con, "SELECT * FROM `quiz` JOIN `question_paper` ON `quiz`.`quiz_id`=`question_paper`.`quiz` WHERE `quiz_id`='$session_quiz_id'");
        $total_marks_details = mysqli_fetch_assoc($total_marks_q);
        $total_marks = $total_marks_details['questions_marks'];
        $total_questions = mysqli_num_rows($total_marks_q);
        $total_quiz_marks = $total_marks * $total_questions;
        
        // Check whether how many questions are right and wrong
        $attempted_answers_q = mysqli_query($con, "SELECT `answer_status` FROM `answers` JOIN `quiz` ON `answers`.`answer_quiz_id` = `quiz`.`quiz_id` JOIN `students` ON `answers`.`answer_student_id`=`students`.`student_id` WHERE `answers`.`answer_quiz_id`='$session_quiz_id' AND `answers`.`answer_student_id`='$session_student_id'");
        $attempted_questions_array = array();
        while($attempted_answers_details = mysqli_fetch_assoc($attempted_answers_q)){
            $attempted_answers_array[] = $attempted_answers_details;

        }
        // echo "<pre>";
        // print_r($attempted_answers_array);
        // echo "</pre>";
        $total_answers = count($attempted_answers_array);
        //Total marks obtained 
        $total_marks_obtained= 0;
        for($i=0; $i<$total_answers; $i++){
            if ($attempted_answers_array[$i]['answer_status'] == 0) {
                $total_marks_obtained = $total_marks_obtained + 0;
            }
            if($attempted_answers_array[$i]['answer_status'] == 1){
                $total_marks_obtained = $total_marks_obtained + $total_marks;
            }
        }
        //echo $total_marks_obtained;
        $add_result_q = mysqli_query($con, "INSERT INTO `result` (`quiz_id`, `student_id`, `total_marks`, `obtained_marks`) VALUE ('$session_quiz_id','$session_student_id', '$total_quiz_marks','$total_marks_obtained')");
        if ($add_result_q) {
            unset($_SESSION['quiz_id']);
            ?>
            <script>window.location='manage-quizzes.php?Msg=quiz_ended'</script>
            <?php
        }
?>
