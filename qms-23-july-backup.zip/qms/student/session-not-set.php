<?php



if (!isset($_SESSION['email'])) {
	header('Location: ../index.php?msg=login_to_continue');
}

?>