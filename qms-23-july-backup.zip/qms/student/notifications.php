<?php
$page = 'announcements';
include('includes/top.php');
if (isset($_SESSION['quiz_id'])) {
    ?>
    <script>window.location='quiz.php?Msg=incomplete_quiz'</script>
    <?php
}
?>


        <div class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Announcements</h4>
                    </div>
                    <div class="notification-div"></div>
                </div>
            </div>
        </div>
<?php
include('includes/footer.php');
?>
<script>
$(document).ready(function(){
    function load_notification(){
        $.ajax({
           url:"helpers/fetch_notifications.php",
           method:"POST",
           success:function(data){
                $('.notification-div').html(data);     
           }
        });
    }
    load_notification();

    setInterval(function(){ 
      load_notification(); 
    }, 5000);
});
</script>