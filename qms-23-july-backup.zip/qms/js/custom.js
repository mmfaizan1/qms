
// ISOTOPE FILTER
jQuery(document).ready(function($){

  if ( $('.iso-box-wrapper').length > 0 ) { 

      var $container  = $('.iso-box-wrapper'), 
        $imgs     = $('.iso-box img');

      $container.imagesLoaded(function () {

        $container.isotope({
        layoutMode: 'fitRows',
        itemSelector: '.iso-box'
        });

        $imgs.load(function(){
          $container.isotope('reLayout');
        })

      });

      //filter items on button click

      $('.filter-wrapper li a').click(function(){

          var $this = $(this), filterValue = $this.attr('data-filter');

      $container.isotope({ 
        filter: filterValue,
        animationOptions: { 
            duration: 750, 
            easing: 'linear', 
            queue: false, 
        }                
      });             

      // don't proceed if already selected 

      if ( $this.hasClass('selected') ) { 
        return false; 
      }

      var filter_wrapper = $this.closest('.filter-wrapper');
      filter_wrapper.find('.selected').removeClass('selected');
      $this.addClass('selected');

        return false;
      }); 

  }

});


// PRELOADER JS
$(window).load(function(){
    $('.preloader').fadeOut(1000); // set duration in brackets    
});


// jQuery to collapse the navbar on scroll //
$(window).scroll(function() {
    if ($(".navbar").offset().top > 50) {
        $(".navbar-fixed-top").addClass("top-nav-collapse");
    } else {
        $(".navbar-fixed-top").removeClass("top-nav-collapse");
    }
});


/* HTML document is loaded. DOM is ready. 
-------------------------------------------*/
$(function(){

  // ------- WOW ANIMATED ------ //
  wow = new WOW(
  {
    mobile: false
  });
  wow.init();


  // HIDE MOBILE MENU AFTER CLIKING ON A LINK
  $('.navbar-collapse a').click(function(){
        $(".navbar-collapse").collapse('hide');
    });


  // NIVO LIGHTBOX
  $('.iso-box-section a').nivoLightbox({
        effect: 'fadeScale',
    });


  // HOME BACKGROUND SLIDESHOW
  $(function(){
    jQuery(document).ready(function() {
    $('#home').backstretch([
       "images/home-bg-slideshow1.jpg", 
       "images/home-bg-slideshow2.jpg",
        ],  {duration: 2000, fade: 750});
    });
  })

});

//Student login form validation
$(document).ready(function(){
  $('#login').click(function(){
    var email = $('#email').val();
    var password = $('#password').val();
    var login = $('#login').val();
    var dataString = 'email='+email + '&password='+password + '&login='+login;
    function ValidateEmail(email) {
        var expr = /^(?!_)([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return expr.test(email);
    };
    if (email == '' || password == '') {
      $("#status_message").addClass("alert");
      $("#status_message").addClass("alert-danger");
      $("#status_message").css("color","red");
      $("#status_message").html('ATTENTION! Fill in all the required Fields');
    }else if (!ValidateEmail(email)) {
      $("#status_message").addClass("alert");
      $("#status_message").addClass("alert-danger");
      $("#status_message").css("color","red");
      $("#status_message").html('ATTENTION! Invalid Email Address. Correct format "abc@gmail.com"');
    }else{
      $.ajax({
        type: 'POST',
        url: 'student-auth.php',
        data: dataString,
        cache: false,
        success: function(result){
          $("#status_message").html(result);
        }
      });
    }
  });

});

//Teacher Signup
$(document).ready(function(){
  $('#teacher_signup').click(function(){
    var name = $('#teacher_name').val();
    var email = $('#teacher_email').val();
    var department = $('#teacher_department').val();
    var phone = $('#teacher_phone').val();
    var password = $('#teacher_password').val();
    var signup = $('#teacher_signup').val();
    var dataString = 'name='+name+'&email='+email+'&department='+department+'&phone='+phone+'&password='+password+'&signup='+signup;
    function ValidateEmail(email) {
        var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return expr.test(email);
    };
    if (name == '' ||email == '' || department == '' || phone == '' || password == '') {
      $("#teacher_status_message").addClass("h4");
      $("#teacher_status_message").addClass("alert");
      $("#teacher_status_message").addClass("alert-danger");
      $("#teacher_status_message").css("color","red");
      $("#teacher_status_message").addClass("text-center");
      $("#teacher_status_message").html('ATTENTION! Fill in all the required Fields');
    }else if (!ValidateEmail(email)) {
      $("#teacher_status_message").addClass("h4");
      $("#teacher_status_message").addClass("alert");
      $("#teacher_status_message").addClass("alert-danger");
      $("#teacher_status_message").css("color","red");
      $("#teacher_status_message").addClass("text-center");
      $("#teacher_status_message").html('ATTENTION! Invalid Email Address. Correct format "abc@gmail.com"');
    }else{
      $.ajax({
        type: 'POST',
        url: 'teacher-signup.php',
        data: dataString,
        cache: false,
        success: function(result){
          $("#teacher_status_message").html(result);
        }
      });
    }
  });

});
//Student Signup
$(document).ready(function(){
  //Fetch Department Degrees
  $('#student_department').change(function(){
    var department_id = $('#student_department').val();
    var dataString = 'department_id='+department_id;
    $.ajax({
          type: 'POST',
          url: 'department_degrees.php',
          data: dataString,
          cache: false,
          success: function(result){
            $('#student_degrees').html(result);
          }
      });
  });
  //if degree is msc show 4 semesters and if degree is bs show 8 semesters
  $('#student_degrees').change(function(){
    var student_degrees = $('#student_degrees option:selected').text();
    var degree_level = student_degrees.substring(0, student_degrees.indexOf('-'));
    if (degree_level == 'BS') {
      $('#semester').html('<option value="">Select Semester</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option>');
      $('#degree_level').val('uglc');
    }else if (degree_level == 'MSC') {
      $('#semester').html('<option value="">Select Semester</option><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option>');
      $('#degree_level').val('glc');
    }
  });
  //student signup
  $('#student_signup').click(function(){
    var name = $('#student_name').val();
    var email = $('#student_email').val();
    var department = $('#student_department').val();
    var degree = $('#student_degrees').val();
    var year = $('#session_year').val();
    var degree_level = $('#degree_level').val();
    var rollno = $('#rollno').val();
    var semester = $('#semester').val();
    var phone = $('#student_phone').val();
    var password = $('#student_password').val();
    var signup = $('#student_signup').val();
    var dataString = 'name='+name+'&email='+email+'&department='+department+'&phone='+phone+'&password='+password+'&signup='+signup+'&degree='+degree+'&year='+year+'&degree_level='+degree_level+'&rollno='+rollno+'&semester='+semester;
    function ValidateEmail(email) {
        var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return expr.test(email);
    };
    if (name == '' ||email == '' || department == '' || phone == '' || password == '') {
      $("#student_status_message").addClass("h4");
      $("#student_status_message").addClass("alert");
      $("#student_status_message").addClass("alert-danger");
      $("#student_status_message").css("color","red");
      $("#student_status_message").addClass("text-center");
      $("#student_status_message").html('ATTENTION! Fill in all the required Fields');
    }else if (!ValidateEmail(email)) {
      $("#student_status_message").addClass("h4");
      $("#student_status_message").addClass("alert");
      $("#student_status_message").addClass("alert-danger");
      $("#student_status_message").css("color","red");
      $("#student_status_message").addClass("text-center");
      $("#student_status_message").html('ATTENTION! Invalid Email Address. Correct format "abc@gmail.com"');
    }else{
      $.ajax({
        type: 'POST',
        url: 'student-signup.php',
        data: dataString,
        cache: false,
        success: function(result){
          $("#student_status_message").html(result);
        }
      });
    }
  });
    //Disable Inspect Element and reload keys starts
  //f12 key
  $(document).keydown(function(e){
      if(e.which === 123){
   
         return false;
   
      }
   
  });
  //Disable Right Click 
  document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
  });
  //disble ctrl+shift+c, ctrl+shift+j, ctrl+shift+i and ctrl+u
  $(document).keydown(function (event) {
        if ((event.ctrlKey && event.shiftKey && event.keyCode == 73) || (event.ctrlKey && event.shiftKey && event.keyCode == 74) || (event.ctrlKey && event.shiftKey && event.keyCode == 67) || (event.ctrlKey && event.keyCode == 85)) {
            return false;
        }
    });
  //Disable inspect element and reload keys ends
});