-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2018 at 04:02 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qms`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `answer_id` int(11) NOT NULL,
  `answer_quiz_id` int(11) NOT NULL,
  `answer_student_id` int(11) NOT NULL,
  `answer_teacher_id` int(11) NOT NULL,
  `answer_question_id` int(11) NOT NULL,
  `answer` varchar(200) NOT NULL,
  `answer_status` varchar(10) NOT NULL COMMENT '0 for wrong and 1 for right'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`answer_id`, `answer_quiz_id`, `answer_student_id`, `answer_teacher_id`, `answer_question_id`, `answer`, `answer_status`) VALUES
(45, 5, 1, 1, 7, 'Ebay', '0'),
(46, 1, 1, 1, 1, 'Cluster Cloud', '0'),
(47, 1, 1, 1, 6, 'Information Technology', '1'),
(48, 1, 1, 1, 11, 'Internet', '1');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL,
  `degree` int(11) NOT NULL,
  `semester` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `degree`, `semester`) VALUES
(1, 1, 8),
(2, 2, 8),
(3, 3, 8),
(4, 4, 4),
(5, 5, 8),
(6, 6, 4),
(7, 7, 8),
(8, 8, 4),
(9, 9, 8),
(10, 10, 8);

-- --------------------------------------------------------

--
-- Table structure for table `class_courses`
--

CREATE TABLE `class_courses` (
  `class_course_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `course_class_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_courses`
--

INSERT INTO `class_courses` (`class_course_id`, `course_id`, `course_class_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 3, 5),
(4, 4, 7);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course` varchar(50) NOT NULL,
  `course_code` varchar(20) NOT NULL,
  `department` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course`, `course_code`, `department`) VALUES
(1, 'Cloud Computing', 'IT-4122', 1),
(2, 'Ecommerce Application Development', 'IT-4541', 1),
(3, 'Meta Physics', 'PHY-1221', 4),
(4, 'Linear Algebra I', 'MATH-1342', 6),
(5, 'Bone Diseases', 'DPT-8123', 2),
(6, 'Financial Accounting', 'BA-1233', 3),
(7, 'Multimedia', 'CS-5972', 1);

-- --------------------------------------------------------

--
-- Table structure for table `course_allocation`
--

CREATE TABLE `course_allocation` (
  `course_allocation_id` int(11) NOT NULL,
  `allocated_course_id` int(11) NOT NULL,
  `course_teacher_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_allocation`
--

INSERT INTO `course_allocation` (`course_allocation_id`, `allocated_course_id`, `course_teacher_id`) VALUES
(1, 1, 1),
(2, 3, 3),
(3, 4, 4),
(4, 5, 6),
(5, 6, 7),
(6, 2, 2),
(7, 7, 1);

-- --------------------------------------------------------

--
-- Table structure for table `degree`
--

CREATE TABLE `degree` (
  `degree_id` int(11) NOT NULL,
  `department_name` int(11) NOT NULL,
  `degree_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `degree`
--

INSERT INTO `degree` (`degree_id`, `department_name`, `degree_name`) VALUES
(1, 1, 'BS-IT'),
(2, 1, 'BS-CS'),
(3, 1, 'BS-SE'),
(4, 1, 'MSC-IT'),
(5, 4, 'BS-PHY'),
(6, 4, 'MSC-PHY'),
(7, 6, 'BS-MATH'),
(8, 6, 'MSC-MATH'),
(9, 2, 'BS-DPT'),
(10, 3, 'BBA');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `department_name`) VALUES
(1, 'CS & IT'),
(2, 'DPT'),
(3, 'Business Administration'),
(4, 'Physics'),
(5, 'Zoology'),
(6, 'Math'),
(7, 'English'),
(8, 'Chemistry');

-- --------------------------------------------------------

--
-- Table structure for table `mcq_options`
--

CREATE TABLE `mcq_options` (
  `option_id` int(11) NOT NULL,
  `mcq_question_id` int(11) NOT NULL,
  `option_1` varchar(30) NOT NULL,
  `option_2` varchar(30) NOT NULL,
  `option_3` varchar(30) NOT NULL,
  `option_4` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mcq_options`
--

INSERT INTO `mcq_options` (`option_id`, `mcq_question_id`, `option_1`, `option_2`, `option_3`, `option_4`) VALUES
(1, 1, 'Castel Cloud', 'Cluster Cloud', 'Cloud Computing', 'Cloud Computer'),
(2, 6, 'Computer Science', 'Information Technology', 'Artificial Intelligence', 'Maths'),
(3, 7, 'Ebay', 'Amazon', 'Play.com', 'All Of These'),
(4, 8, 'Google Drive', 'Balmasiq Mockup', 'PHP', 'Laptop'),
(5, 4, 'Maths', 'Philosophy', 'Physics', 'Psychology'),
(6, 9, 'Computer Science', 'Business', 'Chemistry', 'Physics'),
(7, 10, 'CS', 'BBA', 'BDS', 'DPT'),
(8, 5, 'Mathematics', 'Algebra', 'Statistics', 'None Of These'),
(9, 11, 'Rain', 'Internet', 'All Of These', 'None Of These');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_id` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `question_type` int(11) NOT NULL,
  `question` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_id`, `course`, `question_type`, `question`) VALUES
(1, 1, 1, 'Abbreviation of CC?'),
(2, 1, 2, 'abbreviation of cc is'),
(3, 1, 3, 'Define Cloud computing.'),
(4, 3, 1, 'Meta Physics is the Branch of? '),
(5, 4, 1, 'Linear Algebra is the branch of?'),
(6, 1, 1, 'Cloud computing is the emerging technology of?'),
(7, 2, 1, 'Famous Ecommerce Platforms are?'),
(8, 2, 1, 'Which of the following is used to make an Ecommerce site?'),
(9, 6, 1, 'Accounting is the Backbone of?'),
(10, 5, 1, 'Bone Disease is the subject of?'),
(11, 1, 1, 'Cloud Refers to?');

-- --------------------------------------------------------

--
-- Table structure for table `question_paper`
--

CREATE TABLE `question_paper` (
  `paper_question_id` int(11) NOT NULL,
  `quiz` int(11) NOT NULL,
  `paper_question` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question_paper`
--

INSERT INTO `question_paper` (`paper_question_id`, `quiz`, `paper_question`) VALUES
(1, 1, 1),
(2, 1, 6),
(3, 2, 8),
(4, 4, 10),
(5, 3, 4),
(7, 1, 11),
(8, 5, 7);

-- --------------------------------------------------------

--
-- Table structure for table `question_types`
--

CREATE TABLE `question_types` (
  `type_id` int(11) NOT NULL,
  `type` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question_types`
--

INSERT INTO `question_types` (`type_id`, `type`) VALUES
(1, 'MCQ'),
(2, 'FIB'),
(3, 'SQ');

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `quiz_id` int(11) NOT NULL,
  `subject` int(11) NOT NULL,
  `topic` varchar(100) NOT NULL,
  `quiz_created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `quiz_created_by` int(11) NOT NULL COMMENT 'teacher who creates the quiz',
  `schedule` date NOT NULL,
  `duration` time NOT NULL COMMENT 'Time in hours, minutes and seconds',
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `class` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`quiz_id`, `subject`, `topic`, `quiz_created_on`, `quiz_created_by`, `schedule`, `duration`, `start_time`, `end_time`, `class`, `status`) VALUES
(1, 1, 'Introduction to Cloud Computing', '2018-03-14 12:43:43', 1, '2018-03-14', '00:00:10', '19:30:00', '22:05:00', 1, 1),
(2, 2, 'Technologies in Ecommerce platforms', '2018-03-14 12:15:32', 2, '2018-03-14', '00:00:20', '10:30:00', '10:50:00', 2, 1),
(3, 3, 'Basics of Meta Physics', '2018-03-05 15:07:18', 3, '2018-03-05', '00:00:10', '10:30:00', '20:15:00', 5, 2),
(4, 5, 'Introduction To Bone Diseases', '2018-03-05 12:23:24', 6, '2018-02-28', '00:00:15', '10:30:00', '10:50:00', 9, 1),
(5, 2, 'Introduction to Ecommerce', '2018-03-06 17:03:27', 1, '2018-03-06', '00:00:10', '19:30:00', '22:05:00', 1, 2),
(6, 1, 'aaaa', '2018-03-20 11:06:13', 1, '2018-12-31', '00:00:00', '00:00:00', '00:00:00', 2, 1),
(7, 1, 'nnnnn', '2018-03-20 11:14:37', 1, '2018-12-31', '00:00:00', '00:00:00', '00:00:00', 1, 1),
(8, 1, 'mmmmmmmmm', '2018-03-20 11:17:46', 1, '2018-01-01', '00:00:00', '00:00:00', '00:00:00', 1, 1),
(9, 1, 'ss', '2018-03-20 11:18:50', 1, '2018-12-31', '00:00:00', '00:00:00', '00:00:00', 1, 1),
(10, 1, 'asdadasdadas', '2018-03-20 11:32:42', 1, '2018-12-31', '00:00:00', '12:59:00', '12:59:00', 1, 1),
(11, 1, 'hitest', '2018-03-20 11:33:30', 1, '2018-12-31', '00:00:00', '12:59:00', '12:59:00', 1, 1),
(12, 1, 'ss', '2018-03-20 13:25:04', 1, '2018-12-31', '00:00:00', '00:00:00', '00:00:00', 1, 1),
(13, 1, 'test1', '2018-03-20 13:27:44', 1, '2018-03-21', '00:00:01', '00:00:00', '838:59:59', 1, 1),
(14, 1, 'test1', '2018-03-20 13:28:17', 1, '2018-03-21', '00:00:01', '00:00:00', '838:59:59', 1, 1),
(15, 1, 'test1', '2018-03-20 13:30:09', 1, '2018-03-21', '00:00:01', '13:05:00', '14:05:00', 1, 1),
(16, 1, 'test1', '2018-03-20 13:32:03', 1, '2018-03-21', '01:00:00', '13:05:00', '14:05:00', 1, 1),
(17, 1, 'test1', '2018-03-20 13:36:16', 1, '2018-03-21', '23:00:00', '14:05:00', '13:05:00', 1, 1),
(18, 1, 'testing 123', '2018-03-20 13:42:49', 1, '2018-03-24', '00:10:00', '13:50:00', '14:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `result_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `result` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `semester_id` int(11) NOT NULL,
  `semester` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`semester_id`, `semester`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8);

-- --------------------------------------------------------

--
-- Table structure for table `solution`
--

CREATE TABLE `solution` (
  `solution_id` int(11) NOT NULL,
  `solution_question_id` int(11) NOT NULL,
  `solution` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `solution`
--

INSERT INTO `solution` (`solution_id`, `solution_question_id`, `solution`) VALUES
(1, 1, 'Cloud Computing'),
(2, 2, 'Cloud Computing'),
(3, 3, 'computing,resources,internet,cloud'),
(4, 4, 'Philosophy'),
(5, 5, 'Mathematics'),
(6, 6, 'Information Technology'),
(7, 7, 'All Of These'),
(8, 8, 'PHP'),
(9, 9, 'Business'),
(10, 10, 'DPT'),
(11, 11, 'Internet');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `staus_id` int(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`staus_id`, `status`) VALUES
(1, 'not attended'),
(2, 'attending'),
(3, 'attended'),
(4, 'postponed'),
(5, 'missed');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `rollno` varchar(20) NOT NULL,
  `class` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `name`, `rollno`, `class`, `email`, `phone`, `password`) VALUES
(1, 'Faizan Zafar', '14-uglc-502', 1, 'mmfaizan1@gmail.com', '03001234567', '123'),
(2, 'Noman', '14-uglc-501', 2, 'noman@i.com', '03031234567', '123'),
(3, 'Hamid', '14-uglc-923', 5, 'hamid@gmail.com', '3036589658', '123'),
(4, 'Nasir Khan Jan', '14-uglc-1039', 9, 'nkj@gmail.com', '3036589658', '123');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `department` int(11) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `name`, `email`, `department`, `phone`, `password`) VALUES
(1, 'Aized Amin Suffi', 'aized@gmail.com', 1, '03001234567', '123'),
(2, 'Asif Ameer', 'asif370@gmail.com', 1, '3036589658', '123'),
(3, 'Mr Physics', 'phy@gmail.com', 4, '3036589658', '123'),
(4, 'Mr. Math', 'math@gmail.com', 6, '03031234567', '123'),
(5, 'Manzoor', 'manzoor@gmail.com', 5, '03001234567', '123'),
(6, 'Imran', 'imran@gmail.com', 2, '3036589658', '123'),
(7, 'Javaid', 'javaid@gmail.com', 3, '03001234456', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`answer_id`),
  ADD KEY `student_id` (`answer_student_id`),
  ADD KEY `teacher_id` (`answer_teacher_id`),
  ADD KEY `quiz_id` (`answer_quiz_id`),
  ADD KEY `question_id` (`answer_question_id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`class_id`),
  ADD KEY `degree` (`degree`),
  ADD KEY `semester` (`semester`);

--
-- Indexes for table `class_courses`
--
ALTER TABLE `class_courses`
  ADD PRIMARY KEY (`class_course_id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `class_id` (`course_class_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `course_allocation`
--
ALTER TABLE `course_allocation`
  ADD PRIMARY KEY (`course_allocation_id`),
  ADD KEY `course_id` (`allocated_course_id`),
  ADD KEY `teacher_id` (`course_teacher_id`);

--
-- Indexes for table `degree`
--
ALTER TABLE `degree`
  ADD PRIMARY KEY (`degree_id`),
  ADD KEY `department` (`department_name`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `mcq_options`
--
ALTER TABLE `mcq_options`
  ADD PRIMARY KEY (`option_id`),
  ADD KEY `mcq_question_id` (`mcq_question_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_id`),
  ADD KEY `subject` (`course`),
  ADD KEY `question_type` (`question_type`);

--
-- Indexes for table `question_paper`
--
ALTER TABLE `question_paper`
  ADD PRIMARY KEY (`paper_question_id`),
  ADD KEY `quiz` (`quiz`),
  ADD KEY `question` (`paper_question`);

--
-- Indexes for table `question_types`
--
ALTER TABLE `question_types`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`quiz_id`),
  ADD KEY `subject` (`subject`),
  ADD KEY `class` (`class`),
  ADD KEY `status` (`status`),
  ADD KEY `quiz_created_by` (`quiz_created_by`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `quiz_id` (`quiz_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`semester_id`);

--
-- Indexes for table `solution`
--
ALTER TABLE `solution`
  ADD PRIMARY KEY (`solution_id`),
  ADD KEY `question_id` (`solution_question_id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`staus_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `class` (`class`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`),
  ADD KEY `department` (`department`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `answer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `class_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `class_courses`
--
ALTER TABLE `class_courses`
  MODIFY `class_course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `course_allocation`
--
ALTER TABLE `course_allocation`
  MODIFY `course_allocation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `degree`
--
ALTER TABLE `degree`
  MODIFY `degree_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `mcq_options`
--
ALTER TABLE `mcq_options`
  MODIFY `option_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `question_paper`
--
ALTER TABLE `question_paper`
  MODIFY `paper_question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `question_types`
--
ALTER TABLE `question_types`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `quiz`
--
ALTER TABLE `quiz`
  MODIFY `quiz_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `semester_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `solution`
--
ALTER TABLE `solution`
  MODIFY `solution_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `staus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `answers_ibfk_2` FOREIGN KEY (`answer_student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `answers_ibfk_3` FOREIGN KEY (`answer_teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `answers_ibfk_6` FOREIGN KEY (`answer_quiz_id`) REFERENCES `quiz` (`quiz_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `answers_ibfk_7` FOREIGN KEY (`answer_question_id`) REFERENCES `questions` (`question_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `class`
--
ALTER TABLE `class`
  ADD CONSTRAINT `class_ibfk_1` FOREIGN KEY (`degree`) REFERENCES `degree` (`degree_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `class_ibfk_2` FOREIGN KEY (`semester`) REFERENCES `semester` (`semester_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `class_courses`
--
ALTER TABLE `class_courses`
  ADD CONSTRAINT `class_courses_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `class_courses_ibfk_2` FOREIGN KEY (`course_class_id`) REFERENCES `class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`department`) REFERENCES `departments` (`department_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `course_allocation`
--
ALTER TABLE `course_allocation`
  ADD CONSTRAINT `course_allocation_ibfk_1` FOREIGN KEY (`allocated_course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `course_allocation_ibfk_2` FOREIGN KEY (`course_teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `degree`
--
ALTER TABLE `degree`
  ADD CONSTRAINT `degree_ibfk_1` FOREIGN KEY (`department_name`) REFERENCES `departments` (`department_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `mcq_options`
--
ALTER TABLE `mcq_options`
  ADD CONSTRAINT `mcq_options_ibfk_1` FOREIGN KEY (`mcq_question_id`) REFERENCES `questions` (`question_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `questions_ibfk_1` FOREIGN KEY (`course`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `questions_ibfk_2` FOREIGN KEY (`question_type`) REFERENCES `question_types` (`type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `question_paper`
--
ALTER TABLE `question_paper`
  ADD CONSTRAINT `question_paper_ibfk_1` FOREIGN KEY (`paper_question`) REFERENCES `questions` (`question_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `question_paper_ibfk_2` FOREIGN KEY (`quiz`) REFERENCES `quiz` (`quiz_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `quiz`
--
ALTER TABLE `quiz`
  ADD CONSTRAINT `quiz_ibfk_1` FOREIGN KEY (`subject`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `quiz_ibfk_2` FOREIGN KEY (`class`) REFERENCES `class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `quiz_ibfk_3` FOREIGN KEY (`status`) REFERENCES `status` (`staus_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `quiz_ibfk_4` FOREIGN KEY (`quiz_created_by`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `result`
--
ALTER TABLE `result`
  ADD CONSTRAINT `result_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `result_ibfk_3` FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`quiz_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `solution`
--
ALTER TABLE `solution`
  ADD CONSTRAINT `solution_ibfk_1` FOREIGN KEY (`solution_question_id`) REFERENCES `questions` (`question_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`class`) REFERENCES `class` (`class_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `teachers_ibfk_1` FOREIGN KEY (`department`) REFERENCES `departments` (`department_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
